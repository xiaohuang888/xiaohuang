#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
struct an{
    int l,r,add;
}piece[1001];
int first[1000001],last[1000001];
int n,q,x,y,z,i,cnt;
char ch;
void build(){
    int l=1,k=sqrt(n);
    while (l<=n){
        cnt++;
        piece[cnt].l=l;
        l+=k;
        piece[cnt].r=min(l-1,n);
        sort(last+piece[cnt].l,last+piece[cnt].r+1);
    }
}
int ef(int L,int R,int root,int tag){
    int mid,l=L,r=R,ans=1e9;
    while (l<=r){
        mid=l+r>>1;
        if (last[mid]+tag>=root){
            ans=min(ans,mid);
            r=mid-1;
        }else l=mid+1;
    }
    if (ans==1e9) return 0;
    return R-ans+1;
}
int querybl(int tag,int L,int R,int root){
    int ans=0;
    for (int i=L;i<=R;i++)
        if(first[i]+tag>=root) ans++;
    return ans;
}
void query(int L,int R,int root){
    int ans=0;
    for (int i=1;i<=cnt;i++){
        if (L<=piece[i].l&&piece[i].r<=R) ans+=ef(piece[i].l,piece[i].r,root,piece[i].add);
        else if (piece[i].l<=L&&L<=piece[i].r) ans+=querybl(piece[i].add,L,min(piece[i].r,R),root);
        else if (piece[i].l<=R&&R<=piece[i].r) ans+=querybl(piece[i].add,max(piece[i].l,L),R,root);
    }
    printf("%d\n",ans);
}
void changebl(int num,int L,int R,int root){
    for (int i=piece[num].l;i<=piece[num].r;i++){
        last[i]=first[i]+piece[i].add;
        if (L<=i&&i<=R) last[i]+=z;
    }
    sort(last+piece[num].l,last+piece[num].r+1);
}
void change(int L,int R,int root){
    for (int i=1;i<=cnt;i++){
        if (L<=piece[i].l&&piece[i].r<=R) piece[i].add+=root;
        else if (piece[i].l<=L&&L<=piece[i].r) changebl(i,L,piece[i].r,root);
        else if (piece[i].l<=R&&R<=piece[i].r) changebl(i,piece[i].l,R,root);
    }
}
int main(){
    scanf("%d%d",&n,&q);
    for (i=1;i<=n;i++) scanf("%d",&first[i]),last[i]=first[i];
    build();
    for (i=1;i<=q;i++){
        cin>>ch;
        scanf("%d%d%d",&x,&y,&z);
        if (ch=='A')query(x,y,z);else change(x,y,z);
    }
    return 0;
}
