#include<bits/stdc++.h>
using namespace std;
int lson[2000000],rson[2000000],a[2000000],n;
bool t;
int dfs(int l,int r,int s)
{
	if (l==-1&&r==-1) 
	  return 0;
    if (l==-1||r==-1&&l!=r)
    {
        t=true;
        return 0;
    } 
    if (a[l]!=a[r])
    {
        t=true;
        return 0;
    }
    return dfs(lson[l],rson[r],2)+dfs(rson[l],lson[r],2)+s;
}
int main()
{
	ios::sync_with_stdio(false);
	cin>>n;
	for (int i=1;i<=n;++i)
	  cin>>a[i];
	for (int i=1;i<=n;++i)
	  cin>>lson[i]>>rson[i];
	int res=1;
	for (int i=1;i<=n;++i)
	{
		t=false;
		int sum=dfs(lson[i],rson[i],3);
		if ((!t)&&(sum>res))
		  res=sum;
	}
	cout<<res<<endl;
	return 0;
}
