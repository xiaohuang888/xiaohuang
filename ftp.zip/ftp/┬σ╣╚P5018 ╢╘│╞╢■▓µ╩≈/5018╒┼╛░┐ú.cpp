#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
struct tree{
	int left,right;
}t[1000005];
int n,v[1000005];
queue<int> q;
int s,maxn=0;
bool f=false;
void dfs(int x,int y) {
	if(!f) return ; 
	if(v[x]!=v[y]) {
		f=false;
		return ;
	}
	s+=2;
	if((t[x].left!=-1)) {
		if((t[y].right!=-1)) dfs(t[x].left,t[y].right);
		else {
			f=false;
			return ;
		}
	}
	else if(t[y].right!=-1) {
		f=false;
		return ;
	}
	if((t[x].right!=-1)) {
		if((t[y].left!=-1)) dfs(t[x].right,t[y].left);
		else {
			f=false;
			return ;
		}
	}
	else if(t[y].left!=-1) {
		f=false;
		return ;
	}
	return ;
}
bool can_make(int k) {
	s=1,f=true;
	if((t[k].left==-1)&&(t[k].right==-1)) return true;
	if((t[k].left!=-1)&&(t[k].right!=-1)) {
		dfs(t[k].left,t[k].right);
		return f;
	}
	else return false;
}
int main() {
	scanf("%d",&n);
	for (int i=1;i<=n;++i) scanf("%d",&v[i]);
	for (int i=1;i<=n;++i) {
		scanf("%d%d",&t[i].left,&t[i].right);
	} 
	q.push(1);
	while(!q.empty()) {
		int u=q.front();
		q.pop();
		if((can_make(u))) {
			if(s>maxn) maxn=s;
		}
		if(t[u].left!=-1) q.push(t[u].left);
		if(t[u].right!=-1) q.push(t[u].right);
	} 
	printf("%d\n",maxn);
	return 0;
} 
