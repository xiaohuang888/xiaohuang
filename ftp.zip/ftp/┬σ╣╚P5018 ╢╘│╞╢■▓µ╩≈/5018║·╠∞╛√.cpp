#include<iostream>
#include<cstdio>
using namespace std;
int f[1000000];
int a[1000000];
int k[1000000][2];
int ans;
void mk(int i)
{
    if (f[i])
        return;
    if (k[i][0]!=-1)
        mk(k[i][0]),f[i]+=f[k[i][0]];
    if (k[i][1]!=-1)
        mk(k[i][1]),f[i]+=f[k[i][1]];
    f[i]++;
}
bool p(int i,int j)
{
    if (a[i]!=a[j])
        return false;
    bool res=true;
    if (k[i][0]!=-1&&k[j][1]!=-1)
    {
        res=p(k[i][0],k[j][1]);
        if (!res)
            return false;
    }
    else if (k[i][0]==-1&&k[j][1]==-1){}
    else return false;
    if (k[i][1]!=-1&&k[j][0]!=-1)
    {
        res=p(k[i][1],k[j][0]);
        if (!res)
            return false;
    }
    else if (k[i][1]==-1&&k[j][0]==-1){}
    else return false;
    return true;
}
bool dc(int i)
{
    if (k[i][0]==-1&&k[i][1]==-1)
        return true;
    if (p(i,i))
        return true;
    return false;
}
int main()
{
    int n;
    cin>>n;
    for (int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for (int i=1;i<=n;i++)
        scanf("%d%d",&k[i][0],&k[i][1]);
    for (int i=1;i<=n;i++)
        mk(i);
    for (int i=1;i<=n;i++)
    {
        if ((k[i][0]==-1&&k[i][1]!=-1)||(k[i][0]!=-1&&k[i][1]==-1)||(ans>=f[i]))
            continue;
        if (dc(i))
            ans=f[i];
    }
    cout<<ans<<endl;
    return 0;
}
