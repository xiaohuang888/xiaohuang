#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define Rint register int
using namespace std;
int a[10][50];
int rule[50];
bool vis[50],flag=1;
int jw[50];
int n;
bool judge() {
	int add=0;
	for(Rint i=n; i>=1; i--) {
		if(rule[a[1][i]]!=-1&&rule[a[2][i]]!=-1&&rule[a[3][i]]!=-1) {
			if(add==-1&&(rule[a[1][i]]+rule[a[2][i]])%n!=rule[a[3][i]]&&(rule[a[1][i]]+rule[a[2][i]]+1)%n!=rule[a[3][i]])
				return false;
			if(add!=-1) {
				if((rule[a[1][i]]+rule[a[2][i]]+add)%n==rule[a[3][i]]) add=(rule[a[1][i]]+rule[a[2][i]]+add)/n;
				else return false;
			}
		} else add=-1;
	}
	return true;
}
int work(int i,int y) {
	if(y==1) {
		if((rule[a[2][i]]!=-1)&&(rule[a[3][i]]!=-1)) {
			int cmp=(rule[a[3][i]]+n-rule[a[2][i]])%n;
			if(jw[i+1]==1) cmp=(cmp-1+n)%n;
			if(vis[cmp]==0)
				return cmp;
			else return -2;
		}
		return -1;
	} else if(y==2) {
		if((rule[a[1][i]]!=-1)&&(rule[a[3][i]]!=-1)) {
			int cmp=(rule[a[3][i]]+n-rule[a[1][i]])%n;
			if(jw[i+1]==1) cmp=(cmp-1+n)%n;
			if(vis[cmp]==0) return cmp;
			else return -2;
		}
		return -1;
	} else if(y==3) {
		if((rule[a[1][i]]!=-1)&&(rule[a[2][i]]!=-1)) {
			int cmp=(rule[a[1][i]]+rule[a[2][i]])%n;
			if(jw[i+1]==1) cmp=(cmp+1)%n;
			if(vis[cmp]==0)
				return cmp;
			else return -2;
		}
		return -1;
	}
}
void solve() {
	for(Rint i=n; i>=1; i--)
		if((rule[a[1][i]]!=-1)&&(rule[a[2][i]]!=-1)&&(jw[i+1]!=-1)) {
			if(rule[a[1][i]]+rule[a[2][i]]+jw[i+1]>=n)
				jw[i]=1;
			else jw[i]=0;
		} else return;
	return;
}
void dfs(int step,int x) {
	if(!judge()) return;
	solve();
	if(step==n)  {
		for(Rint i=1; i<=n; i++) printf("%d ",rule[i]);
		putchar('\n');
		flag=0;
		return;
	}
	for(Rint i=x; i>=1; i--) {
		for(Rint j=1; j<=3; j++)
			if(rule[a[j][i]]==-1) {
				int cmp=work(i,j);
				if(cmp==-1) {
					for(Rint k=n-1; k>=0; k--)
						if(vis[k]==0) {
							vis[k]=1;
							rule[a[j][i]]=k;
							dfs(step+1,i);
							if(flag==0) return;
							rule[a[j][i]]=-1;
							vis[k]=0;
						}
					return;
				} else if(cmp==-2) return;
				else {
					vis[cmp]=1;
					rule[a[j][i]]=cmp;
					dfs(step+1,i);
					rule[a[j][i]]=-1;
					vis[cmp]=0;
					return;
				}
			}
	}
}
int main() {
	string s1,s2,s3;
	memset(rule,-1,sizeof(rule));
	memset(jw,-1,sizeof(jw));
	scanf("%d\n",&n);
	jw[n+1]=0;
	cin>>s1>>s2>>s3;
	for(Rint i=0; i<n; i++) a[1][i+1]=s1[i]-'A'+1;
	for(Rint i=0; i<n; i++) a[2][i+1]=s2[i]-'A'+1;
	for(Rint i=0; i<n; i++) a[3][i+1]=s3[i]-'A'+1;
	dfs(0,n);
	return 0;
}
