#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
char o[3][27];
int n,w[27],sf[27];
bool yanzheng(){
	int jw=0;
	for(int i=n-1;i>=0;i--){
		if(w[o[0][i]-'A']!=-1&&w[o[1][i]-'A']!=-1){
			if(w[o[2][i]-'A']!=-1){
				if(jw==-1){
			if((w[o[0][i]-'A']+w[o[1][i]-'A'])%n!=w[o[2][i]-'A']&&(w[o[0][i]-'A']+w[o[1][i]-'A']+1)%n!=w[o[2][i]-'A'])return true;
			}
			else
			if((w[o[0][i]-'A']+w[o[1][i]-'A']+jw)%n!=w[o[2][i]-'A'])return true;
			}
			if(jw!=-1)
			jw=(w[o[0][i]-'A']+w[o[1][i]-'A']+jw)/n;
		}
		else
		jw=-1;
	}
	if(jw==1)
	return true;
	for(int i=0;i<n;i++)
	if(sf[i]==0)
	return false;
	for(int i=0;i<n;i++)
    printf("%d ",w[i]);
    exit(0);
}
void dfs(int q,int jw){
	if(yanzheng())
	return;
    if(o[0][q]==o[1][q]){
        if(w[o[1][q]-'A']==-1)
        for(int i=0;i<n;i++){
            if(sf[i]==0){
                sf[i]=1;
                w[o[1][q]-'A']=i;
                if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
                sf[i]=0;
                w[o[1][q]-'A']=-1;
            }
        }
        else{
        	 if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
        }
    }
    else{
        if(w[o[0][q]-'A']==-1&&w[o[1][q]-'A']==-1)
        for(int i=0;i<n;i++){
            if(sf[i]==0){
                sf[i]=1;
                w[o[0][q]-'A']=i;

                for(int j=0;j<n;j++){
                    if(sf[j]==0){
                        sf[j]=1;
                        w[o[1][q]-'A']=j;
                if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
                        sf[j]=0;
                        w[o[1][q]-'A']=-1;
                    }
                }
                w[o[0][q]-'A']=-1;
                sf[i]=0;
            }
        }
        if(w[o[0][q]-'A']==-1&&w[o[1][q]-'A']!=-1)
        for(int i=0;i<n;i++)
        {
            if(sf[i]==0)
            {
                sf[i]=1;
                w[o[0][q]-'A']=i;
                if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
                sf[i]=0;
                w[o[0][q]-'A']=-1;

            }
        }
        if(w[o[0][q]-'A']!=-1&&w[o[1][q]-'A']==-1)
        for(int i=0;i<n;i++)
        {
            if(sf[i]==0)
            {
                sf[i]=1;
                w[o[1][q]-'A']=i;
               if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
                sf[i]=0;
                w[o[1][q]-'A']=-1;
            }
        }
        if(w[o[0][q]-'A']!=-1&&w[o[1][q]-'A']!=-1)
        {
            if(sf[(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n]==0||w[o[2][q]-'A']!=-1){
               if(w[o[2][q]-'A']==-1||w[o[2][q]-'A']==(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n){
                	w[o[2][q]-'A']=(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)%n;
                	sf[w[o[2][q]-'A']]=1;
                	dfs(q-1,(w[o[0][q]-'A']+w[o[1][q]-'A']+jw)/n);
                	sf[w[o[2][q]-'A']]=0;
                	w[o[2][q]-'A']=-1;
                }
				}
        }
    }
}
int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        w[i]=-1;
    }
    for(int i=0;i<3;i++)
    cin>>o[i];
    dfs(n-1,0);
}
