#include <iostream>
#include <cstdio>
#define Rint register int
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&(ch!='-')) ch=getchar();
    if(ch=='-') w=-1;
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w; 
}
const int maxn=2e5+10;
struct Edge{
    int to,nxt;
}e[maxn];
int n,m,r,mod;
int head[maxn],w[maxn],wt[maxn],sum=0;
int a[maxn<<2],lazy[maxn<<2];
int son[maxn],top[maxn],siz[maxn],id[maxn],father[maxn],dep[maxn],cnt;
int res=0;
inline void addedge(int x,int y) {
    sum++;
    e[sum].to=y;
    e[sum].nxt=head[x];
    head[x]=sum;
}
inline void pushdown(int rt,int lenn) {
    lazy[rt<<1]+=lazy[rt];
    lazy[rt<<1|1]+=lazy[rt];
    a[rt<<1]+=(lazy[rt]*(lenn-(lenn>>1)));
    a[rt<<1|1]+=(lazy[rt]*(lenn>>1));
    a[rt<<1]%=mod;
    a[rt<<1|1]%=mod;
    lazy[rt]=0;
}
inline void build(int rt,int l,int r) {
	int mid=(l+r)>>1;
    if(l==r) {
        a[rt]=wt[l];
        a[rt]%=mod;
        return ;
    }
    build(rt<<1,l,mid);
    build(rt<<1|1,mid+1,r);
    a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
}
inline void query(int rt,int l,int r,int L,int R) {
	int mid=(l+r)>>1;
    if((L<=l)&&(r<=R)) {
        res+=a[rt];
        res%=mod;
        return ;
    }
    else {
        if(lazy[rt]) pushdown(rt,(r-l+1));
        if(L<=mid) query(rt<<1,l,mid,L,R);
        if(R>mid) query(rt<<1|1,mid+1,r,L,R);
    }
}
inline void update(int rt,int l,int r,int L,int R,int k) {
	int mid=(l+r)>>1;
    if((L<=l)&&(r<=R)) {
        lazy[rt]+=k;
        a[rt]+=(k*(r-l+1));
        return ;
    }
    else {
        if(lazy[rt]) pushdown(rt,(r-l+1));
        if(L<=mid) update(rt<<1,l,mid,L,R,k);
        if(R>mid) update(rt<<1|1,mid+1,r,L,R,k);
        a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
    }
}
inline int qrange(int x,int y) {
    int ans=0;
    while(top[x]!=top[y]) {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        res=0;
        query(1,1,n,id[top[x]],id[x]);
        ans+=res;
        ans%=mod;
        x=father[top[x]]; 
    }
    if(dep[x]>dep[y]) swap(x,y);
    res=0;
    query(1,1,n,id[x],id[y]);
    ans+=res;
    return ans%mod;
}
inline void updrange(int x,int y,int k) {
    k%=mod;
    while(top[x]!=top[y]) {
        if(dep[top[x]]<dep[top[y]]) swap(x,y);
        update(1,1,n,id[top[x]],id[x],k);
        x=father[top[x]]; 
    }
    if(dep[x]>dep[y]) swap(x,y);
    update(1,1,n,id[x],id[y],k);
    return ;
}

inline int qson(int x) {
    res=0;
    query(1,1,n,id[x],id[x]+siz[x]-1);
    return res%mod;
}

inline void updson(int x,int k) {
    update(1,1,n,id[x],id[x]+siz[x]-1,k);
    return ;
}

inline void dfs(int rt,int f,int deep) {
    dep[rt]=deep;
    father[rt]=f;
    siz[rt]=1;
    int maxson=-1;
    for (Rint i=head[rt];~i;i=e[i].nxt) {
        int y=e[i].to;
        if(y==f) continue;
        dfs(y,rt,deep+1);
        siz[rt]+=siz[y];
        if(siz[rt]>maxson) son[rt]=y,maxson=siz[rt];
    }
}

inline void solve(int rt,int topf) {
    id[rt]=++cnt;
    wt[cnt]=w[rt];
    top[rt]=topf;
    if(!son[rt]) return ;
    solve(son[rt],topf);
    for (Rint i=head[rt];~i;i=e[i].nxt) {
        int y=e[i].to;
        if((y==father[rt])||(y==son[rt])) continue;
        solve(y,y);
    }
}
int main() {
    read(n);read(m);read(r);read(mod);
    for (Rint i=1;i<=n+1;i++) head[i]=-1;
    for (Rint i=1;i<=n;++i) read(w[i]);
    for (Rint i=1;i<n;++i) {
        int a,b;
        read(a);read(b);
        addedge(a,b);
        addedge(b,a);
    }
    dfs(r,0,1);
    solve(r,r);
    build(1,1,n);
    while(m--){
        int k,x,y,z;
        read(k);
        if(k==1) {
            read(x);read(y);read(z);
            updrange(x,y,z);
        }
        else if(k==2) {
            read(x);read(y);
            printf("%d\n",qrange(x,y));
        }
        else if(k==3) {
            read(x);read(y);
            updson(x,y);
        }
        else {
            read(x);
            printf("%d\n",qson(x));
        }
    }
    return 0;
}
