#include<cstdio>
#include<algorithm>
#define N 100005
int n,m,r,p,cnt,x,y,z;
int cs_a[N],fa[N],dep[N],siz[N],son[N],top[N],id[N],no[N];
int cas;
int first[N];
struct NODE{
    int nxt,to;
}node[2*N];
struct tree{
    int l,r,sum,lazy;
}t[N*4];
using namespace std;
void add(int from,int to)
{
    node[++cnt].nxt=first[from];
    node[cnt].to=to;
    first[from]=cnt;
}
void dfs1(int now)
{
    dep[now]=dep[fa[now]]+1;
    siz[now]=1;
    for (int i=first[now];i;i=node[i].nxt)
    {
        int k=node[i].to;
        if (k==fa[now]) continue;
        fa[k]=now;
        dfs1(k);
        siz[now]+=siz[k];
        if (!son[now]||siz[son[now]]<siz[k]) son[now]=k;
    }
}
void dfs2(int now,int father)
{
    top[now]=father;
    id[now]=++cnt;
    no[cnt]=cs_a[now];
    if (son[now]) dfs2(son[now],father);
    for (int i=first[now];i;i=node[i].nxt)
    {
        int k=node[i].to;
        if (k==son[now]||k==fa[now]) continue;
        dfs2(k,k);
    }
}
void build(int root,int l,int r)
{
    t[root].l=l,t[root].r=r;
    if (l==r)
    {
        t[root].sum=no[l]%p;
        return;
    }
    int mid=(l+r)>>1;
    build(root*2,l,mid);
    build(root*2+1,mid+1,r);
    t[root].sum=(t[root*2].sum+t[root*2+1].sum)%p;
}
void js(int root,int l,int r,int d)
{
    t[root].sum=(t[root].sum+(r-l+1)*d)%p;
    t[root].lazy=(t[root].lazy+d)%p;
}
void push_down(int root,int l,int r)
{
    int mid=(l+r)/2;
    js(root*2,l,mid,t[root].lazy);
    js(root*2+1,mid+1,r,t[root].lazy);
    t[root].lazy=0;
}
void change(int root,int l,int r,int k)
{
    int ll=t[root].l,rr=t[root].r;
    if ((l<=ll)&&(rr<=r))
    {
        t[root].sum=(t[root].sum+(rr-ll+1)*k)%p;
        t[root].lazy=(t[root].lazy+k)%p;
        return;
    }
    int mid=(ll+rr)/2;
    push_down(root,ll,rr);
    if (l<=mid) change(root*2,l,r,k);
    if (r>mid) change(root*2+1,l,r,k);
    t[root].sum=(t[root*2].sum+t[root*2+1].sum)%p;
}
int find(int root,int l,int r)
{
    int ll=t[root].l,rr=t[root].r;
    if (ll>=l&&rr<=r) return t[root].sum;
    push_down(root,ll,rr);
    int s=0;
    int mid=(ll+rr)>>1;
    if (l<=mid) s=(s+find(root*2,l,r))%p;
    if (r>mid) s=(s+find(root*2+1,l,r))%p;
    return s;
}
void LCA_change(int x,int y,int z)
{
    z%=p;
    while (top[x]!=top[y])
    {
        if (dep[top[x]]<dep[top[y]]) swap(x,y);
        change(1,id[top[x]],id[x],z);
        x=fa[top[x]];
    }
    if (dep[x]>dep[y]) swap(x,y);
    change(1,id[x],id[y],z);
}
int LCA_sum(int x,int y)
{
    int s=0;
    while (top[x]!=top[y])
    {
        if (dep[top[x]]<dep[top[y]]) swap(x,y);
        s=(s+find(1,id[top[x]],id[x]))%p;
        x=fa[top[x]];
    }
    if (dep[x]>dep[y]) swap(x,y);
    s=(s+find(1,id[x],id[y]))%p;
    return s;
}
void tree_change(int x,int z)
{
    change(1,id[x],id[x]+siz[x]-1,z);
}
int tree_sum(int x)
{
    return find(1,id[x],id[x]+siz[x]-1);
}
int read();
int main()
{
    n=read(),m=read(),r=read(),p=read();
    for (int i=1;i<=n;i++) cs_a[i]=read();
    for (int i=1;i<n;i++)
    {
        x=read(),y=read();
        add(x,y);
        add(y,x);
    }
    dfs1(r);
    cnt=0;
    dfs2(r,0);
    build(1,1,cnt);
    for (int i=1;i<=m;i++)
    {
        cas=read();
        if (cas==1) 
        {
            x=read(),y=read(),z=read();
            LCA_change(x,y,z);
        } else
        if (cas==2)
        {
            x=read(),y=read();
            printf("%d\n",LCA_sum(x,y));
        } else
        if (cas==3)
        {
            x=read(),z=read();
            tree_change(x,z);
        } else
        {
            x=read();
            printf("%d\n",tree_sum(x));
        }
    }
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
