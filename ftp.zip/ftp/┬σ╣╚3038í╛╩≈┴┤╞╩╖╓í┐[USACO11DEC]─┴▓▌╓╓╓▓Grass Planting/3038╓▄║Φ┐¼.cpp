#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn = 100005, maxm = maxn << 1;
int first[maxm],nxt[maxm],v[maxm],fa[maxn],son[maxn],siz[maxn],deep[maxn],id[maxn],top[maxn];
int n,m,cnt,root,num;
struct tree
{
    int c[maxn];
    inline int lowbit(int k)
    {
        return k & (-k);
    }
    inline void add(int x, int k)
    {
        for (int i = x; i <= n; i += lowbit(i)) c[i] += k;
    }
    inline int sum(int x)
    {
        int ans = 0;
        for (int i = x; i; i -= lowbit(i)) ans += c[i];
        return ans;
    }
    inline void update(int l, int r, int k)
    {
        add(l, k), add(r + 1, -k);
    }
}BIT;
inline void addline(int x, int y)
{
    v[cnt] = y, nxt[cnt] = first[x], first[x] = cnt++;
}
int read();
inline void write(int x)
{
    if (x > 9)  write(x / 10);
    putchar(x % 10 + '0');
    return;
}
void dfs1(int x, int f, int d)
{
    fa[x] = f, deep[x] = d, siz[x] = 1;
    for (int i = first[x]; i != -1; i = nxt[i])
    {
        if (v[i] == f)  continue;
        dfs1(v[i], x, d + 1);
        siz[x] += siz[v[i]];
        if (siz[v[i]] > siz[son[x]])  son[x] = v[i];
    }
    return;
}
void dfs2(int x, int t)
{
    id[x] = ++num, top[x] = t;
    if (!son[x])    return;
    dfs2(son[x], t);
    for (int i = first[x]; i != -1; i = nxt[i])
        if (v[i] != fa[x] && v[i] != son[x])   dfs2(v[i], v[i]);
    return;
}
inline void add(int x, int y, int k)
{
    int tx = top[x], ty = top[y];
    while (tx != ty)
    {
        if (deep[tx] >= deep[ty]) BIT.update(id[tx], id[x], k), x = fa[tx], tx = top[x];
        else BIT.update(id[ty], id[y], k), y = fa[ty], ty = top[y];
    }
    if (x == y) return;
    if (id[x] <= id[y]) BIT.update(id[x] + 1, id[y], k);
    else BIT.update(id[y] + 1, id[x], k);
    return;
}
int main()
{
    memset(first, -1, sizeof(first));
    n = read(), m = read();
    for (int i = 1; i < n; i++)
    {
        int x = read(), y = read();
        addline(x, y), addline(y, x);
    }
    dfs1(1,0,1);
    dfs2(1,1);
    while (m--)
    {
        char c = getchar();
        int x, y;
        while (c != 'P' && c != 'Q')    c = getchar();
        x = read(), y = read();
        if (c == 'P') add(x, y, 1);
        if (c == 'Q') deep[x]>deep[y]?printf("%d\n",BIT.sum(id[x])):printf("%d\n",BIT.sum(id[y]));
    }
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
