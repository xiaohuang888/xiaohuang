//BY �ž��� 
#include<iostream>
#include<cstdio>
#include<queue>
#include<cstring>
using namespace std;
const int inf=1e9;
int d[(1<<20)+10],vis[(1<<20)+10];//SPFAʹ�õ����顣 
int s[2][110], t[2][110];
int n, m, w[110];
string s1, s2;
void spfa() {//��׼SPFA 
	int mas = (1<<n) - 1;
	queue <int> q;
	for(int i = 0; i < mas; i++) {
		vis[i] = 0;
		d[i] = inf;
	}
	vis[mas] = 1;
	d[mas] = 0;
	q.push(mas);
	bool flag=false;
	while(!q.empty()) {
		int u = q.front();
		q.pop();
		vis[u] = 0;
		for(int i = 0; i < m; i++) {
			if((u | s[1][i]) == u && ((u & s[0][i]) == u)) {
				int v = u;
				v = v | t[1][i];
				v = v & t[0][i];
				if(d[u] + w[i] < d[v]) {
					d[v] = d[u] + w[i];
					if(!vis[v]) {
						q.push(v);
						vis[v] = 1;
					}
				}
			}
		}
	}
	if(d[0] == inf) {//�����ǰ��Ŀ�����ȻΪ���ֵ��˵���޽� 
		printf("Bugs cannot be fixed.\n");
	} else {
		printf("Fastest sequence takes %d seconds.\n", d[0]);
	}
}
int main() {
	int T= 0;
	while(scanf("%d%d", &n, &m) != EOF && n) {
		memset(s, 0, sizeof(s));//��s��t����ֱ�����ʾ����ԭ����״̬�����ڵ�״̬ 
		memset(t, 0, sizeof(t));
		for(int i = 0; i < m; i++) {
			cin>>w[i]>>s1>>ks2;
			for(int j = 0; j < n; j++) {
				if(s1[j] == '+') s[1][i] += (1<<j);
				if(s1[j] != '-') s[0][i] += (1<<j);
				if(s2[j] == '+') t[1][i] += (1<<j);
				if(s2[j] != '-') t[0][i] += (1<<j);
			}
		}
		printf("Product %d\n", ++T);
		spfa();
		printf("\n");//ע����С�
		while(1); 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
