//BY�ž��� ���λ��Ҫ�����룬����Ը��� 
#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
const int N = 1010;
const double ppp = 1e-3;
const double inf = 1000000000.0;
using namespace std;
int vis[1005],head[1005],n,m,v1,v2,v3,num[1005],k,m1,T;
double dist[1005];
double max_edge;
bool pc;
char s[10010];
int E,tot=0;
struct edge {//�ڽӱ� 
	int from,to,next;
	double v;
} e[1000005]; 
void add(int x,int y,double z) {//�ڽӱ� 
	k++;
	e[k].from=x;
	e[k].to=y;
	e[k].v=z;
	e[k].next=head[x];
	head[x]=k;
	return ;
}
void spfa(int s,double aver)//sqfa������ bfs
{
    int u,v;
    queue<int>q;
    dist[s]=0;
    q.push(s);
    vis[s]=true;
    num[s]++; 
    while(!q.empty())
    {
        int u=q.front();
        q.pop();
        vis[u]=0;
        for(int i=head[u];~i;i=e[i].next)
        {
            int v=e[i].to;
            if(dist[u]+e[i].v-aver>dist[v])
            {
                dist[v]=dist[u]+e[i].v-aver;
            	if(dist[v]>max_edge) 
				{
					pc=true;
					return ;
				}
                if(!vis[v])
                {
                    vis[v]=1;
                    q.push(v);
                    num[v]++;
                    if(num[v]>=n)
                    {
                        pc=true;
                        return ;
                    }
                }
            }
        }
    }
    return ;
}
int flag[3010];
bool solve(double aver) {//�жϣ�averΪ��ǰ��ƽ������ 
	pc=false;
	memset(dist,0,sizeof(dist));
	memset(vis,0,sizeof(vis));
	memset(num,0,sizeof(num));
	for(int i=1;i<=tot;i++) spfa(i,aver);
	return pc;  
}
int main() {
	int n;
	while(scanf("%d",&n),n) {
		E=0;
		tot=0;
		max_edge=0;
		memset(head,-1,sizeof(head));
		fill(flag,flag+3000,0);
		for(int i=0; i<n; i++) {
			scanf("%s",s);
			int len=strlen(s);
			if(len>max_edge) max_edge=len;
			int a=(s[0]-'a')*26+s[1]-'a';
			int b=(s[len-2]-'a')*26+s[len-1]-'a';
			if(!flag[a])  flag[a]=++tot;
			int id1=flag[a];
			if(!flag[b])  flag[b]=++tot;
			int id2=flag[b];
			add(id1,id2,(double)(len));
		}
		max_edge*=n;
		double l=0,r=1000,best=-1,mid;
		while(l+ppp<=r) {//���ִ�ö�� 
			mid=(l+r)/2;
			if(solve(mid)) {
				best=mid;
				l=mid;
			} else r=mid;
		}
		while(1)
		if(best!=-1) printf("%.2lf\n",best);
		else printf("No solution.\n");
	}
	return 0;
}
