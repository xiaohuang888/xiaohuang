//BY ������ �ڽӾ���+����ʵ�ֳ�վ�ּ� 
#include<iostream>
#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;
int m,n,ans = 1;
int s[1010][1010]��
int visit[1010];
int c[1010];
int a[1010][1010];
int r[1010];
int image[1010][1010];
struct node
{
    int bian,ji;
};
int bfs()	//�����������ʵ�� 
{
    queue<node> q;
    for(int i=1; i<=n; i++)
        if(!r[i])
            q.push((node){i,1});
    do
    {
        node d = q.front();	//ȡ��ͷԪ�� 
        q.pop();		//�����˳����� 
        for(int i=1; i<=c[d.bian]; i++)
        {
            int p = a[d.bian][i];
            r[p]--;
            if(!r[p])
            {
                q.push((node){p,d.ji+1});	//������� 
                ans = max(ans,d.ji+1);
            }
        }
    }
	while(!q.empty());
}
int main()
{

    scanf("%d%d",&n,&m);
    for(int i=1; i<=m; i++)
    {
        scanf("%d",&s[i][0]);
        memset(visit,0,sizeof(visit));
        for(int j=1; j<=s[i][0]; j++)
        {
            scanf("%d",&s[i][j]);
            visit[s[i][j]] = 1;	//��������� 
        }
        for(int j=s[i][1]; j<=s[i][s[i][0]]; j++)
            if(!visit[j])
                for(int k=1; k<=s[i][0]; k++)
                    if(!image[j][s[i][k]])
                    {
                        c[j]++;
                        a[j][c[j]] = s[i][k];
                        r[s[i][k]]++;
                        image[j][s[i][k]] = 1;
                    }
    }
    bfs();
    printf("%d",ans);
    return 0;
}
