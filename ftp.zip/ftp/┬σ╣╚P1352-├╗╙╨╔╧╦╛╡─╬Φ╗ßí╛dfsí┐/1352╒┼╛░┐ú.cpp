// luogu-judger-enable-o2
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x){
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-')ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(isdigit(ch))x=(x<<3)+(x<<1)+(ch^'0'),ch=getchar();
    x=x*w;
}
#define Rint register int
struct Edge{
	int to,nxt;
}e[100005];
int n,w[100005];
int head[100005],f[100005][2];
bool vis[100005];
int root,sum=0;
void addedge(int x,int y) {
	sum++;
	e[sum].to=y;
	e[sum].nxt=head[x];
	head[x]=sum;
}
void dfs(int x) {
	f[x][0]=0;f[x][1]=w[x];
	for(Rint i=head[x];~i;i=e[i].nxt) {
		int v=e[i].to;
		dfs(v);
		f[x][0]+=max(f[v][0],f[v][1]);
		f[x][1]+=f[v][0];
	}
	return ;
}
int main() {
	read(n);
	for (Rint i=1;i<=n+1;++i) head[i]=-1;
	for (Rint i=1;i<=n;++i) read(w[i]);
	for (Rint i=1;i<n;++i) {
		int a,b;
		read(a);read(b);
		addedge(b,a);
		vis[a]=true;
	}
	for (Rint i=1;i<=n;++i) {
		if(!vis[i]) {
			root=i;
			break;
		}
	}
	dfs(root);
	printf("%d\n",max(f[root][0],f[root][1]));
	return 0;
}
