#include<cstdio>
#include<cstring>
#include<cmath>
int T,flag[10000005],x;
int js(int n)
{
	int rzt=n;
	for (int i=2; i<=sqrt(n); i++)
		if (n%i==0)
		{
			rzt=rzt/i*(i-1);
			while (n%i==0) n/=i;
		}
	if (n>1) rzt=rzt/n*(n-1);
	return rzt;
}
int quick(int x,int y,int m)
{
    int sum=1;
    for (;y;y>>=1,x=1ll*x*x%m)
        if (y%2) sum=1ll*sum*x%m;
    return sum%m;
}
int answer(int p)
{
	if (flag[p]!=-1) return flag[p];
	int phi=js(p);
	return flag[p]=quick(2,answer(phi)+phi,p);
}
int main()
{
	scanf("%d",&T);
	memset(flag,-1,sizeof(flag));
	flag[1]=0;
	while (T--) scanf("%d",&x),printf("%d\n",answer(x));
	return 0;
}
