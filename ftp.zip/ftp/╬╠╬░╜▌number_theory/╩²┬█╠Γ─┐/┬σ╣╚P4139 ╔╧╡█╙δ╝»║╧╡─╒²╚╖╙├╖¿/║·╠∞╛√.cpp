#include<bits/stdc++.h>
#define MaxN 10000000
#define RL register long long
#define Rint register int
inline long long Quick_pow(long long x,long long y,long long mod) {
	RL ans=1;
	for (;y;x=(x*x)%mod,y>>=1)
		ans=(y&1)?((ans*x)%mod):(ans);
	return ans;
}
int phi[MaxN+123],prime[MaxN+123],tot,n,p;
inline void Seek_Phi(int n) {
	phi[1]=1;
	for (Rint i=2; i<=n; i++) {
		if (!phi[i]) {
			prime[++tot]=i;
			phi[i]=i-1;
		}
		for (Rint j=1; j<=tot; j++) {
			Rint nxt=i*prime[j];
			if (nxt>n)break;
			if (!(i%prime[j]))
				phi[i*prime[j]]=phi[i]*prime[j];
			else phi[i*prime[j]]=phi[i]*(prime[j]-1);
		}
	}
}
int solve(int mod) {
	return (mod==1)?(0):(Quick_pow(2,solve(phi[mod])+phi[mod],mod));
}
int main() {
	Seek_Phi(MaxN);
	scanf("%d",&n);
	for(Rint i=1; i<=n; i++)
		scanf("%d",&p),printf("%d\n",solve(p));
	return 0;
}
