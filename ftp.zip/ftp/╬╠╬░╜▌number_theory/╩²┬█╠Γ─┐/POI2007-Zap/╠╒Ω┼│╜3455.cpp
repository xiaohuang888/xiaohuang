#include<bits/stdc++.h>
//#define int long long
#define Maxl 60045
#define Maxn 100005
using namespace std;
int tot,prime[Maxl],check[Maxl],phi[Maxl],m,n,mu[Maxl];
int sum[Maxl],T;
signed main(){
	mu[1] = 1;
	check[1] = 1;
	for (int i = 2; i <= Maxl; i++)
	{
		if (!check[i])
		{
		  prime[tot++] = i;
		  mu[i] = -1;
	    }
		for (int j = 0; j < tot; j++)
		{
			if (i * prime[j] > Maxl)
			  break;
		    check[i * prime[j]] = 1;
			if (i % prime[j] == 0)
			  break;  else
			mu[i * prime[j]] = -mu[i];
		}
	}
	for (int i = 1; i <= Maxl; i++)
	  sum[i] = sum[i - 1] + mu[i];
    scanf("%d",&T);
    while (T--)
    {
       int a,b,d;
	   scanf("%d%d%d",&a,&b,&d);
	   int ans = 0;
	   int l = 1,r = 0;
	   while (l <= min(a,b))
	   {
	   	 r = min(a / (a / l),b / (b / l));
	   	 ans += (a / (l * d)) * (b / (l * d)) * (sum[r] - sum[l - 1]);	   	 
	     l = r + 1;
	   }
	   printf("%d\n",ans);
	}
	return 0;
} 
