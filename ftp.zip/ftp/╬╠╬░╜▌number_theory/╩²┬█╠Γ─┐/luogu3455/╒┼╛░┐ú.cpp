#include <iostream>
#include <cstdio>
#include <cstring>
#define Temp template<typename T>
#define Rint register int
using namespace std;
typedef long long ll;
const int maxn=6e4+10;
Temp inline void read(T &x) {
	x=0;
	T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
bool vis[maxn];
int prime[maxn],mu[maxn],sum[maxn],tot,q;
inline void init_(int n) {
	mu[1]=1;
	for(int i=2; i<=n; i++) {
		if(!vis[i]) {
			mu[i]=-1;
			prime[++tot]=i;
		}
		for(int j=1; j<=tot&&i*prime[j]<=n; j++) {
			vis[i*prime[j]]=1;
			if(i%prime[j]==0) break;
			else mu[i*prime[j]]=-mu[i];
		}
	}
	for(int i=1; i<=n; i++) sum[i]=sum[i-1]+mu[i];
}
inline int cal(int a,int b,int d) {
	int ans;
	ans=0;
	for(int l=1,r; l<=min(a,b); l=r+1) {
		r=min(a/(a/l),b/(b/l));
		ans+=(a/(l*d))*(b/(l*d))*(sum[r]-sum[l-1]);
	}
	return ans;
}
int main() {
	read(q);
	init_(50000);
	while(q--) {
		int a,b,d;
		read(a);
		read(b);
		read(d);
		int ans;
		ans=0;
		for(int l=1,r; l<=min(a,b); l=r+1) {
			r=min(a/(a/l),b/(b/l));
			ans+=(a/(l*d))*(b/(l*d))*(sum[r]-sum[l-1]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
