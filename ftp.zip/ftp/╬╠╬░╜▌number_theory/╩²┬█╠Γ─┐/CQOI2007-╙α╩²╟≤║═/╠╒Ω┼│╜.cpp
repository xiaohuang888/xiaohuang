#include<bits/stdc++.h>
using namespace std;
long long n,k,l,r,ans;
int main(){
	scanf("%lld%lld",&n,&k);
	l = 1;
	while (l <= n)
	{
		if (k / l != 0)
		  r = min(k / (k / l),n);else
		r = n;
		ans += (l + r) * (r - l + 1) / 2 * (k / l);
		l = r + 1; 
	}
	printf("%lld",n * k - ans);
	return 0;
}
