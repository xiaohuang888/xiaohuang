#include<cstdio>
#include<algorithm>
using namespace std;
long long n,m,sum,i,j;
int main(){
    scanf("%lld%lld",&n,&m);
    for(i=1;i<=n;i=j+1) {
        if(m/i!=0) j=min(m/(m/i),n); else j=n;
        sum-=(m/i)*(j-i+1)*(i+j)/2;
    }
    printf("%lld",sum+n*m);
    return 0;
}
