/*
        n
ans=n*m-��i*(k/i)
       i=1
t=k/i;
*/

#include<bits/stdc++.h>
using namespace std;
long long sum;
long long n,m;
int main()
{
    cin>>n>>m;
    long long r=0;
    sum=n*m;
    for(int i=1;i<=n;i=r+1)
    {
        long long t=m/i;
        if(t!=0) r=min(m/t,n);
        if(t==0) r=n;
        sum-=t*(r-i+1)*(r+i)/2;
    }
    cout<<sum<<endl;
    return 0;
}
 
