#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,i,a,ans;
	cin>>n;
	cin>>a;
	if(a<0)
	a=-a;
	ans=a;
	for(i=2;i<=n;i++)
	{
		cin>>a;
		if(a<0)
		a=-a;
		ans=__gcd(ans,a);
	}
	cout<<ans;
}
