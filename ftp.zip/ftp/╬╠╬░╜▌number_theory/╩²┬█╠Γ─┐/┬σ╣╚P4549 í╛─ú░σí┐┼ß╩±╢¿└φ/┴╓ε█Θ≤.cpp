#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,i,a[21],ans;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>a[i];
	ans=a[1];
	for(i=2;i<=n;i++)
	ans=__gcd(ans,abs(a[i]));
	cout<<ans;
}
