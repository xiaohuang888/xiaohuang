#include <cstdio>
#include <algorithm>
using namespace std;
int n,ans,x;
int main()
{
	scanf("%d",&n);
	for(int i=1; i<=n; i++)
	{
		scanf("%d",&x);
		if(x<0) x=-x;
		ans=__gcd(ans,x);
	}
	printf("%d\n",ans);
}
