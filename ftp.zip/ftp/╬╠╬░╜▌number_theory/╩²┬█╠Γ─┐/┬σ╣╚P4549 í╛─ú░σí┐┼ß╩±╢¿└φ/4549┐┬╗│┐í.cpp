#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,x,y;
int gcd(int a,int b)
{
	int c;
	while(b!=0)
	{
		c=a%b;
		a=b;
		b=c;
	}
	return a;
}
int main()
{
	scanf("%d",&n);
	scanf("%d",&x);
	n--;
	for(int i=0;i<n;i++)
	{
		scanf("%d",&y);
		x=gcd(abs(x),abs(y));
	}
	printf("%d",x);
}
