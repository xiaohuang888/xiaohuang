#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL p,b,m;
LL pow(LL a,LL b,int m)
{
	a%=m;
	if(b==0)
	return 1%m;
	if(b&1)
	return (LL) pow(a,b-1,m)*a%m;
	else 
	{
		int t=pow(a,b/2,m);
		return (LL) t*t%m;
		   }       
}
int main()
{
	cin>>p>>b>>m;
	cout<<p<<"^"<<b<<" mod "<<m<<"="<<pow(p,b,m);
	return 0;
}
