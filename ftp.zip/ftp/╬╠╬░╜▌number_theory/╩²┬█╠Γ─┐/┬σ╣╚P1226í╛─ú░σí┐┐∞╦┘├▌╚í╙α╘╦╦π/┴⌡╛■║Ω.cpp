#include<iostream>
using namespace std;
int main()
{
    long long a,b,n,ans=1;
    cin>>a>>b>>n;
    cout<<a<<"^"<<b<<" mod "<<n<<"=";
    while(b)
    {
        if(b%2==1)
        ans=ans*a%n;
        a=a*a%n;
        b/=2;
    }
    cout<<ans%n;
}
