#include<bits/stdc++.h>
#define L long
using namespace std;
L L quick_pow(L L x,L L y,L L p)
{
	L L ans=1;
	while (y)
	{
		if (y&1)
			ans=(ans*x)%p;
		x=(x*x)%p;
		y>>=1;
	}
	return ans;
}
int main()
{
	L L x,y,p;
	scanf("%lld%lld%lld",&x,&y,&p);
	printf("%lld^%lld mod %lld=%lld\n",x,y,p,quick_pow(x,y,p));
	return 0;
}
