#include<iostream>
#include <cstdio>
using namespace std;
long long b,a,p,k,ans=1,c;
int main() {
	scanf("%d%d%d",&b,&p,&k);
	if(p==0) {
		printf("%d^%d mod %d=%d\n",b,p,k,b%k);
		return 0;
	}
	a=b;
	c=p;
	while(p) {
		if(p&1)
			ans=ans*b%k;
		b=b*b%k;
		p=p>>1;
	}
	printf("%d^%d mod %d=%d\n",a,c,k,ans);
	return 0;
}
