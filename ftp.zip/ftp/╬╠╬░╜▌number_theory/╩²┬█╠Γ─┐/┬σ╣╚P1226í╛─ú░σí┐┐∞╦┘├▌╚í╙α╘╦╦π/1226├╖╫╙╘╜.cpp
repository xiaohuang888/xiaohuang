#include<iostream>
using namespace std;
long long qmod(long long b,long long p,long long k)
{
	long long num=0;
	if(p==0)return 1;
	num=(qmod(b,p/2,k)%k);
	if(p%2==0)return num*num%k;
    else return (num*num%k)*(b%k)%k;
}
int main()
{
	long long b,p,k,ans=0;
	cin>>b>>p>>k;
	ans=qmod(b,p,k)%k;
	cout<<b<<'^'<<p<<" mod "<<k<<'='<<ans;
}
