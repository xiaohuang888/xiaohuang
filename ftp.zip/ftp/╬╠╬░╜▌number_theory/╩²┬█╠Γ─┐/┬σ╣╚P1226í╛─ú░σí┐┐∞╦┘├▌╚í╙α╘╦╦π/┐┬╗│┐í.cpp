#include<iostream>
#include<cstdio>
using namespace std;
long long b,p,k;
long long mi(long long x,long long y,long long z)
{
	if(y==0)
	return 1;
	if(y%2==1)
	return (mi(x,y-1,z)*x)%z;
	else
	{
		long long a=mi(x,y/2,z);
		return a*a%z;
	}
}
int main()
{
    scanf("%lld%lld%lld",&b,&p,&k);
    printf("%lld^%lld mod %lld=",b,p,k);
    if(k!=1)
    printf("%lld",mi(b,p,k));
	else
	printf("0");
}
