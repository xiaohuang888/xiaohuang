#include <cstdio>
using namespace std;
int main(){
	int b,p,k,ans;
	scanf("%d%d%d",& b,& p,& k);
	printf("%d^%d mod %d=",b,p,k);
	if(p == 0){
		printf("%d\n",b % k);
		return 0;
	}
	b %= k;
	ans = 1;
	while(p){
		if(p & 1)
			ans = ans * b % k;
		b = b*b%k;
		p >>= 1;
	}
	printf("%d\n",ans);
	return 0;
}
