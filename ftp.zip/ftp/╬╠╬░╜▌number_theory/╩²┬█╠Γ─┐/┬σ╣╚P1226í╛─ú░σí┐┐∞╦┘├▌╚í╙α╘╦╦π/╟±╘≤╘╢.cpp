#include<iostream>
#define ll long long
using namespace std;
ll f_pow(ll a,ll b,ll m)
{
    if(b==0)return 1;
    if(b%2==0)
    {
        ll t=f_pow(a,b/2,m)%m;
        return t*t%m;
    }
    ll t=f_pow(a,b/2,m)%m;
    return t*t%m*a%m;
}
int main()
{
    ll a,b,m;
    cin>>a>>b>>m;
    cout<<a<<'^'<<b<<" mod "<<m<<'='<<f_pow(a,b,m)%m;
}
