#include<iostream>
#include<cmath>
using namespace std;
bool zs(int n)
{
    int i;
    if(n==1||n==0)return false;
    if(n==2)return true;
    if(n!=2&&n%2==0)return false;
    for(i=3;i<=sqrt(n);i=i+2)
    {
        if(n%i==0)return false;
    }
    return true;
}
int main()
{
    int n,m,a;
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>a;
        if(zs(a))cout<<"Yes\n";
        else cout<<"No\n";
    }
}
