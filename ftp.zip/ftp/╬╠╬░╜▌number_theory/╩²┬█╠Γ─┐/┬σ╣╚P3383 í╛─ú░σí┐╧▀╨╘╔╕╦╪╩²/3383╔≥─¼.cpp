#include<bits/stdc++.h>
using namespace std;
bool kkksc03(long long x)
{
    if(x==2) return 1;
    if(x==1||x==0) return 0;
    long long h=sqrt(x);
    for(long long i=2;i<=h;i++)
    {
        if(x%i==0) return 0;
    }
    return 1;
}
int main()
{
    long long int n,m;
    cin>>n>>m;
    while(m--)
    {
        long long k;
        cin>>k;
        if(kkksc03(k)) cout<<"Yes"<<endl;
        else cout<<"No"<<endl;
    }
    return 0;
}
