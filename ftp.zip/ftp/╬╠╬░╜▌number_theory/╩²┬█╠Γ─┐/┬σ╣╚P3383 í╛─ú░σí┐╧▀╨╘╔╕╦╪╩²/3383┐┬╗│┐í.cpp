#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long l,p,r;
int as[10000000],orz[100000];
bool zs(long k)
{
    for(long i=2;i<=sqrt(k);i++)
    {
        if(k%i==0)
        return false;
    }
    return true;
}
int main()
{
    as[1]=1;
    as[2]=0;
    scanf("%ld%ld",&l,&p);
    for(int i=0;i<p;i++)
    {
        scanf("%ld",&r);
        if(as[r]==0)
        {
            if(zs(r))
            {
                int q=2;
                while(q*r<=l)
                {
                    as[q*r]=1;
                    q++;
                }
                orz[i]=1;
            }
        }
    }
    for(int i=0;i<p;i++)
    {
        if(orz[i]==1)
        printf("Yes\n");
        else
        printf("No\n");
    }
}
