#include<iostream>
using namespace std;
int prime[10000001];
int check[10000001];
int tot,n,m,x;
int main()
{
	cin>>n>>m;
	for (int i=2; i<=n; i++)
	{
		if (!check[i])
			prime[++tot]=i;
		for (int j=1; j<=tot; j++)
		{
			if (i*prime[j]>n)
				break;
			check[i*prime[j]]=true;
			if (i%prime[j]==0)
				break;
		}
	}
	for (int i=1;i<=m;i++)
		cin>>x,cout<<(check[x]?"No":"Yes")<<endl;
}
