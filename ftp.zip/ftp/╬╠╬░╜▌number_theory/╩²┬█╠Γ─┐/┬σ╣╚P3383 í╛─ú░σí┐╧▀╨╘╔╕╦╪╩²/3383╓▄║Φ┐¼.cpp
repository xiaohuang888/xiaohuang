#include<stdio.h>
#include<string.h>
int n,m,x,cnt,prime[10000001];
bool vis[10000001];
using namespace std;
int main()
{
	vis[1]=1;
	scanf("%d%d",&n,&m);
	for (int i=2; i<=n; i++)
	{
		if (!vis[i]) prime[cnt++] = i;
		for (int j=0; j<cnt&&i*prime[j]<=n; j++)
		{
			vis[i*prime[j]]=1;
			if(i%prime[j]==0) break;
		}
	}
	for (int i=1; i<=m; i++)
	{
		scanf("%d",&x);
		if (!vis[x]) printf("Yes\n");
		else printf("No\n");
	}
	return 0;
}
