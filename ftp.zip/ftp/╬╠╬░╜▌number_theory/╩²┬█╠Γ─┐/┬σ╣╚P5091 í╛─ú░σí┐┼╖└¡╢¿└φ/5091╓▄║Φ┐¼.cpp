#include <cstdio>
long long a,m,rzt=1;
long long s,flag;
long long quick(long long a, long long b)
{
	if (b==1) return a;
	long long s=1;
	if (b%2==1) s=(s*a)%m;
	long long t=quick(a,b/2);
	s=(s*t%m*t)%m;
	return s;
}
int main()
{
	scanf("%lld%lld",&a,&m);
	a%=m;
	int mm=m;
	for (int i=2; i*i<=mm; i++)
	{
		if (mm%i) continue;
		rzt*=i-1;
		mm/=i;
		while (mm%i==0) rzt*=i,mm/=i;
	}
	if (mm>1) rzt*=mm-1;
	char ch=getchar();
	while (ch<'0'||ch>'9') ch=getchar();
	s=s*10+ch-48;
	while (1)
	{
		ch=getchar();
		if (ch<'0'||ch>'9') break;
		s=s*10+ch-48;
		if (s>=rzt) flag=1,s%=rzt;
	}
	if (s>=rzt) flag=1,s%=rzt;
	if (flag) s+=rzt;
	printf("%lld\n", quick(a,s));
	return 0;
}
