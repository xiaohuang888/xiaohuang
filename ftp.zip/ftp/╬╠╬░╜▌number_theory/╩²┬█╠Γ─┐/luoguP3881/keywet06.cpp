/*
    By keywet06
    Code-key: slow
*/
#include <cstdio>
// @#file insert begin filename[UnsigndIntFastRead.hpp] from[:/hpp/]
/*
    By keywet06
    Use include:
        cstdio (stdio.h)
    Use function:
        NULL
*/
inline unsigned int UnsignedIntFastRead()
{
    unsigned int UnsignedIntFastRead_x, UnsignedIntFastRead_y;
    UnsignedIntFastRead_y = getchar();
    while (UnsignedIntFastRead_y < '0' || '9' < UnsignedIntFastRead_y)
    {
        UnsignedIntFastRead_y = getchar();
    }
    UnsignedIntFastRead_x = UnsignedIntFastRead_y - '0';
    UnsignedIntFastRead_y = getchar();
    while ('0' <= UnsignedIntFastRead_y && UnsignedIntFastRead_y <= '9')
    {
        UnsignedIntFastRead_x = UnsignedIntFastRead_x * 10 + UnsignedIntFastRead_y - '0';
        UnsignedIntFastRead_y = getchar();
    }
    return UnsignedIntFastRead_x;
}
// @#file insert end
#include <cstdio>
long long n, p;
long long a[3000005];
int main()
{
    n = UnsignedIntFastRead();
    p = UnsignedIntFastRead();
    a[1] = 1;
    puts("1");
    for (int i = 2; i <= n; ++i)
    {
        a[i] = - a[p % i] * (p / i);
        a[i] %= p;
        if (a[i])
        {
            a[i] += p;
        }
        printf("%d\n", a[i]);
    }
    return 0;
}