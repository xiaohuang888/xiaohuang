#include<bits/stdc++.h>
//#define int long long
#define Maxl 10000007
#define Maxn 100005
using namespace std;
int tot,prime[Maxl],check[Maxl],phi[Maxl],m;
int PowerMod(long long a, int n, int mod,int c = 1) {for (; n; n >>= 1, a = a * a % mod) if (n & 1) c = c * a % mod; return c;}
int dfs(int x)
{
	if (x == 1) return 0;
	return PowerMod(2,dfs(phi[x]) + phi[x],x);
}
signed main(){
	for (int i = 2; i <= Maxl; i++)
	{
		if (!check[i])
		{
		  prime[tot++] = i;
		  phi[i] = i - 1;
	    }
		for (int j = 0; j < tot; j++)
		{
			if (i * prime[j] > Maxl)
			  break;
		    check[i * prime[j]] = 1;
			if (i % prime[j] == 0)
			{
			  phi[i * prime[j]] = phi[i] * prime[j];
			  break; 
		    } else
		    phi[i * prime[j]] = phi[i] * (prime[j] - 1);  
		}
	}
	scanf("%d",&m);
	while (m--)
	{
		int p;
		scanf("%d",&p);
		printf("%d\n",dfs(p));
	}
} 
