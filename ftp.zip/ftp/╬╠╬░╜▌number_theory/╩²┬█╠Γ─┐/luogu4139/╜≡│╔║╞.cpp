#include<bits/stdc++.h>
#define int long long
using namespace std;

int T,primenumber,phi[10000005],prime[90000000],mindiv[90000000];
long long p;

void LetsPhi(){
	phi[1]=1;
	for(int i=2;i<=10000000;i++){
		if(!mindiv[i]){
			prime[primenumber++]=i;
			//mindiv[i]=i;
			phi[i]=i-1;
		}
		for(int j=0;j<primenumber;j++){
			long long nxt=i*prime[j];
			if(nxt>10000000)
				break;
			mindiv[nxt] = 1;
			if(i % prime[j] == 0)
			{
				phi[nxt]=phi[i]*prime[j];break;}else
				phi[nxt]=phi[i]*(prime[j]-1);
		}
	}
}

long long fp(int x,int y,int mo){
	if(y==0)
		return 1;
	if(y&1)
		return (fp(x*x%mo,y/2,mo)%mo*x)%mo;else
		return fp(x*x%mo,y/2,mo)%mo;
		
}

long long solve(int p){
	if(p==1)
		return 0;
	return fp(2,solve(phi[p])+phi[p],p);
}

main(){
	LetsPhi();
	scanf("%lld",&T);
	while(T--){
		scanf("%lld",&p);
		printf("%lld\n",solve(p));
	}
	return 0;
}
