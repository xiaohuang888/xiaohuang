#include<cstdio>
#include<iostream>
using namespace std;
int quick_pow(long long a,int n,int mod){
    long long ans=1;
    while(n){
        if(n&1)
            ans=ans*a%mod;
        a=a*a%mod;
        n>>=1;
    }
    return ans;
}
int phi[10000010],prime[10000010],tot,n;
void init(){
    phi[1]=1;
    for(int i=2;i<=10000000;i++){
        if(!phi[i]){
            prime[++tot]=i;
            phi[i]=i-1;
        }
        for(int j=1;j<=tot;j++){
            if(i*prime[j]>10000000)
                break;
            if(!(i%prime[j])){
                phi[i*prime[j]]=phi[i]*prime[j];
                break;
            }
            else phi[i*prime[j]]=phi[i]*(prime[j]-1);
        }
    }
}
int solve(int mod){
    if(mod==1)
        return 0;
    return quick_pow(2,solve(phi[mod])+phi[mod],mod);
}
int main(){
    init();
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        int p;
        scanf("%d",&p);
        printf("%d\n",solve(p));
    }
    return 0;
}
