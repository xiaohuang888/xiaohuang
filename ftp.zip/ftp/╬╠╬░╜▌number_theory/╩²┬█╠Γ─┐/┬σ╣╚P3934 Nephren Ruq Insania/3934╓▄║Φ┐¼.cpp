#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 500005
#define M 20000005
#define inf 500001
#define max_rzt 20000000
#define ll long long
#define lson (root<<1)
#define rson (root<<1|1)
using namespace std;
int n,m,x,phi[M],zs[M],cnt,opt,l,r,rzt;
ll c[N],a[N];
ll sumv[N<<2],lazy[N<<2],tree[N<<2];
bool flag[M];
int las[N];
inline int read()
{
	int f=1,x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}
int pd(int x,ll p,int rzt)
{
	int ans=1;
	for(; p; p>>=1,x=1LL*x*x%rzt)if(p&1)ans=1LL*ans*x%rzt;
	return ans;
}
void rzt_zhk()
{
	phi[1]=1;
	for(int i=2; i<=max_rzt; i++)
	{
		if(!flag[i])zs[++cnt]=i,phi[i]=i-1;
		for(int j=1; j<=cnt; j++)
		{
			int t=i*zs[j];
			if(t>max_rzt)break;
			flag[t]=1;
			if(i%zs[j]==0)
			{
				phi[t]=phi[i]*zs[j];
				break;
			}
			phi[t]=phi[i]*(zs[j]-1);
		}
	}
}
void pushup(int root)
{
	sumv[root]=sumv[lson]+sumv[rson];
	tree[root]=min(tree[lson],tree[rson]);
}
void build(int root,int l,int r)
{
	tree[root]=inf;
	if(l==r)
	{
		sumv[root]=a[l];
		if(a[l]==1)tree[root]=l;
		return;
	}
	int mid=(l+r)>>1;
	build(lson,l,mid);
	build(rson,mid+1,r);
	pushup(root);
}
void pushdown(int root,int l,int r)
{
	if(!lazy[root])return;
	int mid=(l+r)>>1;
	lazy[lson]+=lazy[root];
	lazy[rson]+=lazy[root];
	sumv[lson]+=lazy[root]*1LL*(mid-l+1);
	sumv[rson]+=lazy[root]*1LL*(r-mid);
	tree[lson]=inf;
	tree[rson]=inf;
	lazy[root]=0;
}
void change(int root,int l,int r,int q,int v)
{
	if(l==r)
	{
		sumv[root]=v;
		return;
	}
	int mid=(l+r)>>1;
	pushdown(root,l,r);
	if(q<=mid)change(lson,l,mid,q,v);
	else change(rson,mid+1,r,q,v);
	pushup(root);
}
inline void rzt_change(int root,int l,int r,int ql,int qr,int v)
{
	if(ql<=l&&r<=qr)
	{
		lazy[root]+=v;
		sumv[root]+=1LL*(r-l+1)*v;
		tree[root]=inf;
		return;
	}
	int mid=(l+r)>>1;
	pushdown(root,l,r);
	if(ql<=mid)rzt_change(lson,l,mid,ql,qr,v);
	if(qr>mid)rzt_change(rson,mid+1,r,ql,qr,v);
	pushup(root);
}
ll find(int root,int l,int r,int q)
{
	if(l==r)return sumv[root];
	int mid=(l+r)>>1;
	pushdown(root,l,r);
	if(q<=mid)return find(lson,l,mid,q);
	else return find(rson,mid+1,r,q);
}
ll find_ans(int q)
{
	if(las[q]==m)return a[q];
	las[q]=m;
	return a[q]=find(1,1,n,q);
}
int queryfst(int root,int l,int r,int ql,int qr)
{
	if(ql<=l&&r<=qr)return tree[root];
	int mid=(l+r)>>1;
	pushdown(root,l,r);
	int ans=inf;
	if(ql<=mid)ans=min(ans,queryfst(lson,l,mid,ql,qr));
	if(qr>mid)ans=min(ans,queryfst(rson,mid+1,r,ql,qr));
	return ans;
}
ll answer(int l,int r,int rzt)
{
	if(find_ans(l)%rzt==0)return 0;
	if(rzt==1)return 1;
	if(l==r)return find_ans(l)%rzt+(find_ans(l)>=rzt)*rzt;
	int f=min(r,l+5);
	for(int i=l+1; i<=f; i++)if(find_ans(i)==1)
		{
			f=i;
			break;
		}
	ll last=find_ans(f),q=0;
	for(int i=f-1; i>=l+1; i--)
	{
		q=last,last=1;
		while(q--)
		{
			last*=find_ans(i);
			if(last>=phi[rzt])return pd(find_ans(l)%rzt,answer(l+1,r,phi[rzt])+phi[rzt],rzt);
		}
	}
	return pd(find_ans(l)%rzt,last,rzt);
}
int main()
{
	rzt_zhk();
	memset(las,-1,sizeof(las));
	n=read();
	m=read();
	for(int i=1; i<=n; i++)a[i]=read();
	build(1,1,n);
	while(m--)
	{
		int opt=read(),l=read(),r=read(),rzt=read();
		if (opt==1) rzt_change(1,1,n,l,r,rzt);
		else printf("%lld\n",(answer(l,r,rzt))%rzt);
	}
}
