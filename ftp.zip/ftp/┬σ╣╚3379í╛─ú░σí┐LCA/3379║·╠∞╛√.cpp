#include<bits/stdc++.h>
#define MaxE 1200001
#define MaxN 1200001
#define MaxK 25
using namespace std;
int n,m,root;
int cnt;
int edge[MaxE];
int nxt[MaxE];
int fst[MaxN];
int deep[MaxN];
int fa[MaxN][MaxK];
int lg[MaxN];
void build(int x,int y)
{
    edge[++cnt]=y;
    nxt[cnt]=fst[x];
    fst[x]=cnt;
}
void doit(int me,int myfa)
{
    deep[me]=deep[myfa]+1;
    fa[me][0]=myfa;
    for (int i=1; (1<<i)<=deep[me]; i++)
        fa[me][i]=fa[fa[me][i-1]][i-1];
    for (int i=fst[me]; ~i; i=nxt[i])
        if (edge[i]!=myfa)
            doit(edge[i],me);
}
void init()
{
    for (int i=1; i<MaxN; i++)
        lg[i]=lg[i-1]+(1<<lg[i-1]==i),fst[i]=-1;
    scanf("%d%d%d",&n,&m,&root);
    for (int i=1; i<n; i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        build(x,y),build(y,x);
    }
    doit(root,0);
}
int queryLCA(int x,int y)
{
    if (deep[x]<deep[y])
        swap(x,y);
    while (deep[x]>deep[y])
        x=fa[x][lg[deep[x]-deep[y]]-1];
    if (x==y)
        return x;
    for (int k=lg[deep[x]]-1; k>=0; k--)
        if (fa[x][k]!=fa[y][k])
            x=fa[x][k],y=fa[y][k];
    return fa[x][0];
}
int main()
{
    init();
    while (m--)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        printf("%d\n",queryLCA(x,y));
    }
    return 0;
}

