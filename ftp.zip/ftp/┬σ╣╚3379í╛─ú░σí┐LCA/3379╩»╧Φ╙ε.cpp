#include<cstdio>
#include<cstring>
#define MAXN 500010
struct a{
	int to,next;
}e[MAXN*2];
int h[MAXN],deep[MAXN],f[MAXN][20];
int n,m,i,j,root,cnt;
void JB(int u,int v){
	e[cnt].to=v;
	e[cnt].next=h[u];
	h[u]=cnt++;
}
void JT(int root,int father){
	deep[root]=deep[father]+1;
	f[root][0]=father;
	for (int i=1;(1<<i)<=deep[root];i++) f[root][i]=f[f[root][i-1]][i-1];
	for (int i=h[root];i!=-1;i=e[i].next){
		int v=e[i].to;
		if (v!=father) JT(v,root);
	}
}
void swap(int &a,int &b){
	a^=b;b^=a;a^=b;
}
int LCA(int a,int b){
	if(deep[a]>deep[b]) swap(a,b);
	for(int i=19;i>=0;i--){
		if (deep[a]<=deep[b]-(1<<i))
		     b=f[b][i];
	}
	if (a==b) return a;
	for(int i=19;i>=0;i--){
		if (f[a][i]==f[b][i])
		    continue;
		else
		    a=f[a][i],b=f[b][i];
	}
	return f[a][0];
}
int main(){
	memset(h,-1,sizeof(h));
	scanf("%d%d%d",&n,&m,&root);
	for(i=1;i<n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		JB(a,b);
		JB(b,a);
	}
	JT(root,0);
	for(i=1;i<=m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		printf("%d\n",LCA(a,b));
	}
}
