#include<cstdio>
#define N 500005
int n,m,s,cnt,x,y;
int first[N],first1[N],id[2*N],ans[N],father[N];
struct Node{
    int nxt,to;
}node[2*N],node1[2*N];
bool flag[N];
using namespace std;
int read();
void add(int from,int to)
{
    node[++cnt].nxt=first[from];
    first[from]=cnt;
    node[cnt].to=to;
}
void add1(int from,int to,int x)
{
    node1[++cnt].nxt=first1[from];
    first1[from]=cnt;
    node1[cnt].to=to;
    id[cnt]=x;
}
int find(int x)
{
    if (father[x]==x) return x;
    father[x]=find(father[x]);
    return father[x];
}
void hb(int x,int y)
{
    int f_x=find(x),f_y=find(y);
    if (f_x!=f_y) father[f_x]=father[f_y];
}
void LCA(int x)
{
    flag[x]=1;
    for (int i=first1[x];i;i=node1[i].nxt)
    {
        int to=node1[i].to;
        if (flag[to]) ans[id[i]]=find(to);
    }
    for (int i=first[x];i;i=node[i].nxt)
    {
        int to=node[i].to;
        if (!flag[to])
        {
            LCA(to);
            hb(to,x);
        }
    }
}
int main()
{
    n=read(),m=read(),s=read();
    for (int i=1;i<n;i++)
    {
        x=read(),y=read();
        add(x,y);
        add(y,x);
    }
    cnt=0;
    for (int i=1;i<=m;i++)
    {
        x=read(),y=read();
        add1(x,y,i);
        add1(y,x,i);
    }
    for (int i=0;i<=n;i++) father[i]=i;
    LCA(s);
    for (int i=1;i<=m;i++) printf("%d\n",ans[i]);
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
