#include<cstdio>
#include<cmath>
#include<algorithm>
#define N 500005
int n,m,s,cnt,x,y;
int first[N],fa[N],dep[N],son[N],siz[N],top[N];
struct Node{
    int nxt,to;
}node[2*N];
using namespace std;
int read();
void add(int from,int to)
{
    node[++cnt].nxt=first[from];
    node[cnt].to=to;
    first[from]=cnt;
}
void dfs1(int now)
{
    dep[now]=dep[fa[now]]+1;
    siz[now]=1;
    for (int i=first[now];i;i=node[i].nxt)
    {
        int k=node[i].to;
        if (k==fa[now]) continue;
        fa[k]=now;
        dfs1(k);
        siz[now]+=siz[k];
        if (!son[now]||siz[son[now]]<siz[k]) son[now]=k;
    }
}
void dfs2(int now,int father)
{
    top[now]=father;
    if (son[now]) dfs2(son[now],father);
    for (int i=first[now];i;i=node[i].nxt)
    {
        int k=node[i].to;
        if (k!=son[now]&&k!=fa[now]) dfs2(k,k);
    }
}
int main()
{
    n=read(),m=read(),s=read();
    for (int i=1;i<n;i++)
    {
        x=read(),y=read();
        add(x,y);
        add(y,x);
    }
    dfs1(s);
    dfs2(s,s);
    for (int i=1;i<=m;i++)
    {
        x=read(),y=read();
        while (top[x]!=top[y])
        {
            if (dep[top[x]]>=dep[top[y]]) x=fa[top[x]]; else y=fa[top[y]];
        }
        printf("%d\n",dep[x]<dep[y]?x:y);
    }
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
