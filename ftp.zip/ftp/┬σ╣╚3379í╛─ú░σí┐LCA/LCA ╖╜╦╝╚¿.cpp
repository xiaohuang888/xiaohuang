//by ��˼Ȩ 
#include<bits/stdc++.h>
using namespace std;
const int MAXN=5*1e5+9;
struct record {
	int u,v;
} edge[MAXN*2];
int n,m,S,x,y,head[MAXN],dep[MAXN],f[MAXN][21],cnt;
void add(int x,int y) {
	edge[cnt].u=head[x];
	edge[cnt].v=y;
	head[x]=cnt++;
}
void DFS(int u,int father) {
	dep[u]=dep[father]+1;
	f[u][0]=father;
	for (int i=1; (1<<i)<=dep[u]; i++)
		f[u][i]=f[f[u][i-1]][i-1];
	for (int i=head[u]; i!=-1; i=edge[i].u) {
		int v=edge[i].v;
		if (v!=father) DFS(v,u);
	}
}
int LCA(int x,int y) {
	if(dep[x]>dep[y]) swap(x,y);
	for(int i=19; i>=0; i--) {
		if (dep[x]<=dep[y]-(1<<i))
			y=f[y][i];
	}
	if (x==y) return x;
	for(int i=19; i>=0; i--) {
		if (f[x][i]!=f[y][i])
			x=f[x][i],y=f[y][i];
	}
	return f[x][0];
}
int main() {
	memset(head,-1,sizeof(head));
	scanf("%d%d%d",&n,&m,&S);
	for (int i=1; i<n; i++) {
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	DFS(S,0);
	while (m--) {
		scanf("%d%d",&x,&y);
		printf("%d\n",LCA(x,y));
	}
	return 0;
}
