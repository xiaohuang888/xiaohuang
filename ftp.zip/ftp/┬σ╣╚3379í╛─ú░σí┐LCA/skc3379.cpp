#ifndef INC_GRAPH_SKC
#define INC_GRAPH_SKC
#include<cstring>
namespace skc
{
	#ifndef TYPEDEF_STANDARD_SKC
	#define TYPEDEF_STANDARD_SKC
	typedef unsigned int standard;
	#endif
	template<standard vertex_,standard edge_,typename weight_=int>
	class graph
	{
		private:
			standard top;
			struct EDGE
			{
				weight_ w;
				standard to,next;
			};
		public:
			EDGE e[edge_];
			standard head[vertex_+1];
			graph()
			{
				memset(head,255,sizeof(head));
				top=0;
			}
			void add(standard source,standard target,weight_ w)
			{
				e[top].to=target;
				e[top].w=w;
				e[top].next=head[source];
				head[source]=top;
				top++;
			}
	};
}
#endif
#include<cstdio>
using namespace std;
using namespace skc;
graph<500000,1000000> g;
int father[20][500001],deep[500001];
bool vis[500001];
void dfs(int rt)
{
	vis[rt]=1;
	int i;
	for(i=g.head[rt];i!=-1;i=g.e[i].next)
	{
		if(vis[g.e[i].to]) continue;
		father[0][g.e[i].to]=rt;
		dfs(g.e[i].to);
	}
}
int ff(int rt,int d)
{
	int temp=1<<19,rv=rt,i=19;
	while(temp)
	{
		if(d&temp) rv=father[i][rv];
		temp>>=1;
		i--;
	}
	return rv;
}
int main()
{
	int n,m,s;
	scanf("%d%d%d",&n,&m,&s);
	int i,x,y;
	for(i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		g.add(x,y,0);
		g.add(y,x,0);
	}
	dfs(s);
	int j;
	for(i=1;i<=19;i++)
	{
		for(j=1;j<=500000;j++)
		{
			father[i][j]=father[i-1][father[i-1][j]];
		}
	}
	int rt,d,t1,t2,min_;
	for(j=1;j<=500000;j++)
	{
		rt=j;
		d=0;
		for(i=19;i>=0;i--)
		{
			if(father[i][rt]==0) continue;
			d=d+(1<<i);
			rt=father[i][rt];
		}
		deep[j]=d;
	}
	for(i=0;i<m;i++)
	{
		scanf("%d%d",&x,&y);
		if(deep[x]>deep[y])
		{
			x=ff(x,deep[x]-deep[y]);
		}
		if(deep[x]<deep[y])
		{
			y=ff(y,deep[y]-deep[x]);
		}
		min_=2147483647;
		for(j=19;j>=0;j--)
		{
			if(father[j][x]==0) continue;
			if(father[j][x]!=father[j][y])
			{
				x=father[j][x];
				y=father[j][y];
			}
		}
		if(x!=y) x=father[0][x];
		printf("%d\n",x);
	}
	return 0;
}

