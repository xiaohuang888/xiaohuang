#include<cstdio>
#include<cmath>
#include<algorithm>
#define N 500005
int n,m,s,cnt,x,y;
int first[N],f[N][25],dep[N];
struct Node{
    int nxt,to;
}node[2*N];
using namespace std;
int read();
void add(int from,int to)
{
    node[++cnt].nxt=first[from];
    node[cnt].to=to;
    first[from]=cnt;
}
void dfs(int now,int father,int deep)
{
    f[now][0]=father;
    dep[now]=deep;
    for (int i=first[now];i;i=node[i].nxt)
    {
        int to=node[i].to;
        if (to!=father) dfs(to,now,deep+1);
    }
}
int LCA(int x,int y)
{
    if (dep[x]<dep[y]) swap(x,y);
    if (dep[x]>dep[y])
        for (int i=log(n)/log(2);i>=0;i--)
            if (dep[f[x][i]]>=dep[y]) x=f[x][i];
    if (x==y) return x;
    for (int i=log(n)/log(2);i>=0;i--)
      if (f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
    return f[x][0];
}
int main()
{
    n=read(),m=read(),s=read();
    for (int i=1;i<n;i++)
    {
        x=read(),y=read();
        add(x,y);
        add(y,x);
    }
    dfs(s,0,1);
    for (int j=1;j<=log(n)/log(2);j++)
      for (int i=1;i<=n;i++)
        f[i][j]=f[f[i][j-1]][j-1];	
    for (int i=1;i<=m;i++)
    {
        x=read(),y=read();
        printf("%d\n",LCA(x,y));
    }
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
