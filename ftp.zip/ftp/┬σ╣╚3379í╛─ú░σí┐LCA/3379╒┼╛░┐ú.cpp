#include <iostream>
#include <cstdio>
#define Temp template<typename T>
#define Rint register int
using namespace std;
Temp inline void read(T &x) {
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
const int maxn=1e6+10;
struct Edge{
	int to,nxt;
}e[maxn];
int n,m,st;
int deep[maxn],f[maxn/2][22],s[maxn],head[maxn],cnt=0;
inline void addedge(int x,int y) {
	++cnt;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
inline void dfs(int x,int fa) {
	deep[x]=deep[fa]+1;
	f[x][0]=fa;
	for (Rint i=1;(1<<i)<=deep[x];++i) {
		f[x][i]=f[f[x][i-1]][i-1];
	}
	for (Rint i=head[x];~i;i=e[i].nxt) {
		int v=e[i].to;
		if(v!=fa) dfs(v,x);
	}
	return ;
}
inline int lca(int x,int y) {
	if(deep[x]<deep[y]) swap(x,y);
	while(deep[x]>deep[y]) x=f[x][s[deep[x]-deep[y]]-1];
	if(x==y) return x;
	for (Rint k=s[deep[x]]-1;k>=0;--k)
		if(f[x][k]!=f[y][k])
			x=f[x][k],y=f[y][k];
	return f[x][0];
}
int main() {
	read(n);read(m);read(st);
	for (Rint i=1;i<=n+1;++i) head[i]=-1;
	for (Rint i=1;i<n;++i) {
		int a,b;
		read(a);read(b);
		addedge(a,b);
		addedge(b,a);
	}
	dfs(st,0);
	for (Rint i=1;i<=n;++i) s[i]=s[i-1]+((1<<s[i-1])==i);
	for (Rint i=1;i<=m;++i) {
		int a,b;
		read(a);read(b);
		printf("%d\n",lca(a,b));
	}
	return 0;
}
