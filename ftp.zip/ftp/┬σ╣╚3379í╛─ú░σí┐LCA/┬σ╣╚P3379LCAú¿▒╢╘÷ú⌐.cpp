#include <cstdio>
#include <cstring>
#include <algorithm>
#define max_edge (max_node-1)
#define max_node 2000000
#define log_max_node 200
using namespace std;
int dep[max_node+1],par[max_node+1][log_max_node+1],p[max_node+1];
int log_[log_max_node+1];
template <typename T> inline void read(T & x) {
    x = 0;
    char c = getchar();
    while('0' > c || c > '9')
        c = getchar();
    while('0' <= c && c <= '9'){
        x = (x<<1)+(x<<3)+(c ^ 48);
        c = getchar();
    }
}
struct node {
    int v,nxt;
} edge[max_edge+1];
int head[max_node+1];
int cnt;
inline void build() {
    memset(head,-1,sizeof(head));
    cnt = 0;
}
inline void insert(int u,int v) {
    cnt ++;
    edge[cnt].nxt = head[u];
    head[u] = cnt;
    edge[cnt].v = v;
}
void dfs(int x){
    register int i;
    dep[x] = dep[par[x][0]] + 1;
    for(i = 1; i <= log_[dep[x]]; i ++)
        par[x][i] = par[par[x][i-1]][i-1];
    for(i = head[x]; ~i; i = edge[i].nxt){
        if(edge[i].v == par[x][0])
            continue;
        par[edge[i].v][0] = x;
        dfs(edge[i].v);
    }
}
void init(int rt,int n){
    register int i;
    for(i = 1; i <= n; i ++)
        log_[i] = log_[i-1] + ((1 << (log_[i-1]+1)) == i);
    dep[0] = 0;
    par[rt][0] = 0;
    dfs(rt);
}
int lca(int x,int y){
    if(dep[x] > dep[y])
        swap(x,y);
    while(dep[x] < dep[y])
        y = par[y][log_[dep[y]-dep[x]]];
    if(x == y)
        return x;
    register int i;
    for(i = log_[dep[x]-1]; ~i; i --)
        if(par[x][i] != par[y][i])
            x = par[x][i],y = par[y][i];
    return par[x][0];
}
int main() {
    register int n,m,s,u,v,i;
    read(n),read(m),read(s);
    build();
    for(i = 1; i < n; i ++){
        read(u),read(v);
        insert(u,v);
        insert(v,u);
    }
    init(s,n);
    for(i = 1; i <= m; i ++){
        read(u),read(v);
        printf("%d\n",lca(u,v));
    }
    return 0;
}
