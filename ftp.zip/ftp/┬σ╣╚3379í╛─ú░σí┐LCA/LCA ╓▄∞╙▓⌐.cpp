#include<iostream>
#include<cstdio>
using namespace std;
long long a[40];
int f[1000740][90],b[1000740][90],l[1000740],dep[1000740];
int n,m,s,x,y,i,j;
void work(int x,int y){
	l[y]++;
	b[y][l[y]]=x;
}
int read(){
	int x=0,mk=1;
	char ch=getchar();
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		mk=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*mk;
}
void dfs(int u,int v){
	dep[u]=dep[v]+1;
	f[u][0]=v;
	for(int i=1;i<=20;i++)
		f[u][i]=f[f[u][i-1]][i-1];
	for(int i=1;i<=l[u];i++)
		if(b[u][i]!=v){
			dfs(b[u][i],u);
		}
}
int lca(int x,int y){
	if(dep[x]<dep[y])
		swap(x,y);
	int p=dep[x]-dep[y];
	for(int i=20;i>=0;i--){
		if(p>a[i]){
			p=p-a[i];
			x=f[x][i];
		}
	}
	if(x==y){
		return x;
	}
	if(p==1){
		x=f[x][0];
	}
	for(int i=20;i>=0;i--){
		if(f[x][i]!=f[y][i]){
			x=f[x][i];
			y=f[y][i];
		}
	}
	if(x==y){
		return x;
	}else{
		return f[x][0];
	}
}
int main(){
	n=read();m=read();s=read();
	a[0]=1;
	for(int i=1;i<=20;i++)
		a[i]=a[i-1]*2;
	for(int i=1;i<=n-1;i++){
		x=read();
		y=read();
		work(x,y);
		work(y,x);
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=20;j++)
			f[i][j]=0;
	dfs(s,0);
	for(int i=1;i<=m;i++){
		x=read();
		y=read();
		printf("%d\n",lca(x,y));
	}
	return 0;
}
