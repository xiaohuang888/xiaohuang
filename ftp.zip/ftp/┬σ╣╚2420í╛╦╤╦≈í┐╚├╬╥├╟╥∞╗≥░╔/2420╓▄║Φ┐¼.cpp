#include<cstdio>
#define N 100005
int n,m,x,y,z,cnt;
int first[N],yh[N];
struct Node{
	int nxt,to,w;
}node[2*N];
using namespace std;
int read();
void add(int from,int to,int kkksc03)
{
	node[++cnt].nxt=first[from];
	node[cnt].to=to;
	first[from]=cnt;
	node[cnt].w=kkksc03;
}
void dfs(int now,int father,int chen_zhe)
{
	yh[now]=yh[father]^chen_zhe;
	for (int i=first[now];i;i=node[i].nxt)
	{
		int to=node[i].to;
		if (to!=father) dfs(to,now,node[i].w);
	}
}
int main()
{
	n=read();
	for (int i=1;i<n;i++)
	{
		x=read(),y=read(),z=read();
		add(x,y,z);
		add(y,x,z);
	}
	dfs(1,0,0);
	m=read();
	for (int i=1;i<=m;i++)
	{
		x=read(),y=read();
		printf("%d\n",yh[x]^yh[y]);
	}
	return 0;
}
inline int read()
{
	int f=1,x=0;
	char ch=getchar();
	while (ch<'0'||ch>'9')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0'&&ch<='9')
	{
		x=x*10+ch-48;
		ch=getchar();
	}
	return f*x;
}
