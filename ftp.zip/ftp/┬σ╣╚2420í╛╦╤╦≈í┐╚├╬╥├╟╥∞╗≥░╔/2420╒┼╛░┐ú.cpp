#include <iostream>
#include <cstdio>
#include <cstring>
#define Rint register int
#define Temp template<typename T>
Temp inline void read(T &x) {
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
const int maxn=1e5+10;
struct Edge{
	int to,nxt,v;
}e[maxn<<1];
int n,q;
int head[maxn],ans[maxn],cnt=0;
inline void addedge(int x,int y,int z) {
	++cnt;
	e[cnt].v=z;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
inline void dfs(int rt,int father,int res) {
	ans[rt]=ans[father]^res;
	for (int i=head[rt];~i;i=e[i].nxt) {
		int v=e[i].to;
		if(v!=father) dfs(v,rt,e[i].v);
	}
}
int main() {
	read(n);
	memset(head,-1,sizeof(head));
	for (Rint i=1;i<n;++i) {
		int a,b,c;
		read(a);read(b);read(c);
		addedge(a,b,c);
		addedge(b,a,c);
	}
	dfs(1,0,0);
	read(q);
	for (Rint i=1;i<=q;++i) {
		int a,b;
		read(a);read(b);
		printf("%d\n",ans[a]^ans[b]);
	}
	return 0;
}
