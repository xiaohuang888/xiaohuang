#include<bits/stdc++.h>
#define int long long
using namespace std;
const long long inf = 66666666233;
int block,sum,Ans[3000005],p[3000005],n,m,Add[3000005];
int a[3000005];
void work(int as,int bs,int x)
{
	int st = 0;
	for (int i = as; i <= bs; i++)
	  st += a[i];
	Ans[x] = st;
	//COp[x] = st;
}
signed main(){
	scanf("%lld",&n);
	block = (int)sqrt(n);
	sum = n / block;
	if (n % block) sum++;
	for (int i = 1; i <= n; i++)
	{
		scanf("%lld",&a[i]);
		p[i] = (i - 1) / block + 1;
	}
	for (int i = 1; i <= sum; i++)
	   work((i - 1) * block + 1,i * block,i);
	for (int i = 1; i <= n; i++)
	{
		int x,y,st = 0,op,k;
		scanf("%lld",&op);
		if (op == 1)
		{
		  scanf("%lld%lld%lld",&x,&y,&k);
		  for (int j = x; j <= y; j)
		  if ((j - 1) % block || (p[j] * block > y))
	  	  {	 
			    st +=  Add[p[j]] + a[j];
			    j++;
		  } else
	      {
			  st += Ans[p[j]] + Add[p[j]] * ((p[j] * block) - ((p[j] - 1) * block + 1) + 1);
			  j += block;
		  }
		  //if (p[x] == p[y])
		    //st -= a[x] + a[y] + Add[p[x]] + Add[p[y]];
		  printf("%lld\n",st % (k + 1));
	   } else
	   {
	   	  scanf("%lld%lld%lld",&x,&y,&k);
	   	  for (int j = x; j <= y; j)
		  if ((j - 1) % block || (p[j] * block > y))
	  	  {	 
			    a[j] += k;
			    Ans[p[j]] += k;
			    j++;
		  } else
	      {	  
			  Add[p[j]] += k;	
			  j += block;
		  }
	   }
	}
	return 0;
} 
