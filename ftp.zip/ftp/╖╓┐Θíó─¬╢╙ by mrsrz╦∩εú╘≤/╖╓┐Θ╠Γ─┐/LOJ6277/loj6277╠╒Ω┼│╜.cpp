#include<bits/stdc++.h>
#define int long long
using namespace std;
int block,sum,Ans[50005],p[50005],n,m,Add[50005];
int a[50005];
inline void work(int as,int bs,int x)
{
	int st = 0;
	for (int i = as; i <= bs; i++)
	  st += a[i];
	Ans[x] = st;
	//COp[x] = st;
}
inline int read(){
   int s=0,w=1;
   char ch=getchar();
   while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
   while(ch>='0'&&ch<='9') s=s*10+ch-'0',ch=getchar();
   return s*w;
}
void print(int x)
{
    if(x>=10)print(x/10);
    putchar(x%10+'0');
}
signed main(){
	scanf("%lld",&n);
	block = (int)sqrt(n);
	sum = n / block;
	if (n % block) sum++;
	for (int i = 1; i <= n; i++)
	{
		//scanf("%lld",&a[i]);
		a[i] = read();
		p[i] = (i - 1) / block + 1;
	}
	for (int i = 1; i <= sum; i++)
	   work((i - 1) * block + 1,i * block,i);
	for (int i = 1; i <= n; i++)
	{
		int x,y,st = 0,op,k,mp,io;
		op = read();
		if (op == 1)
		{
		  mp = read();
		  x = read();
		  io = read();
		  printf("%lld\n",a[x] + Add[p[x]]);
	   } else
	   {
	   	  x = read();
	   	  y = read();
	   	  k = read();
	   	  for (int j = x; j <= min(p[x] * block,y); j++)
	   	    a[j] += k;
	   	  if (p[x] != p[y])
	   	    for (int j = (p[y] - 1) * block + 1; j <= y; j++)
	   	      a[j] += k;
		   for (int j = p[x] + 1; j <= p[y] - 1; j++)
		     Add[j] += k;
	   }
	}
	return 0;
} 
