#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,blo;
int v[50003],part[50003*2],place[50003];
int read(){
	char ch=getchar();
	int x=0,mk=1;
	while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-'){
		mk=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x;
}
void add(int l,int r,int c){
	for(int i=l;i<=min(r,(place[l]*blo));i++)
		v[i]+=c;
	if(place[l]!=place[r])
		for(int i=(place[r]-1)*blo+1;i<=r;i++)
			v[i]+=c;
	for(int i=place[l]+1;i<place[r];i++)
		part[i]+=c;
}
int main(){
	n=read();blo=sqrt(n);
	for(int i=1;i<=n;i++)
		v[i]=read();
	for(int i=1;i<=n;i++)
		place[i]=(i-1)/blo+1;
	for(int i=1;i<=n;i++){
		int p,l,r,c;
		p=read();
		l=read();
		r=read();
		c=read();
		if(p==0)add(l,r,c);
		else printf("%d\n",v[r]+part[place[r]]);
	}
}
