#include<bits/stdc++.h>
#define int long long
using namespace std;
int block,sum,Ans[50005],p[50005],n,m,Add[50005],tag[500005];
int a[50005];
inline void work(int as,int bs,int x)
{
	int st = 0;
	for (int i = as; i <= bs; i++)
	  st += a[i];
	Add[x] += st;
	//COp[x] = st;
}
inline int read(){
   int s=0,w=1;
   char ch=getchar();
   while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
   while(ch>='0'&&ch<='9') s=s*10+ch-'0',ch=getchar();
   return s*w;
}
void push_down(int x){
    Add[x] = 0;
    int flag = 1;
    for(int i = (x - 1) * block + 1; i <= min(n,x * block); i++){
        a[i] = (int)sqrt(a[i]);
        Add[x] += a[i];
        if(a[i] != 1) flag = 0;
    }
    tag[x] = flag;
}
signed main(){
	scanf("%lld",&n);
	block = (int)sqrt(n);
	sum = n / block;
	if (n % block) sum++;
	for (int i = 1; i <= n; i++)
	{
		a[i] = read();
		p[i] = (i - 1) / block + 1;
	}
	for (int i = 1; i <= sum; i++)
	   work((i - 1) * block + 1,i * block,i);
	for (int i = 1; i <= n; i++)
	{
		int x,y,st = 0,op,k,mp,io;
		op = read();
		if (op == 1)
		{
		  x = read();
		  y = read();
		  mp = read();
		  for (int j = x; j <= min(p[x] * block,y); j++)
	   	    st += a[j];
	   	  if (p[x] != p[y])
	   	  for (int j = (p[y] - 1) * block + 1; j <= y; j++)
	   	     st += a[j];
		  for (int j = p[x] + 1; j <= p[y] - 1; j++)
		     st += Add[j];
		  printf("%d\n",st);
	   } else
	   {
	   	  x = read();
	   	  y = read();
	   	  k = read();
	   	  for (int j = x; j <= min(p[x] * block,y); j++)
	   	  {
	   	  	int uy = a[j];
	   	    a[j] = (int)sqrt(a[j]);
	   	    Add[p[j]] -= uy - a[j];
	     }
	   	  if (p[x] != p[y])
	   	    for (int j = (p[y] - 1) * block + 1; j <= y; j++)
	   	       {
	   	  	     int uy = a[j];
	   	    	 a[j] = (int)sqrt(a[j]);
	   	   		 Add[p[j]] -= uy - a[j];
	     	   }
		   for (int j = p[x] + 1; j <= p[y] - 1; j++)
		   if (tag[j] == 0) push_down(j);
	  }
	}
	return 0;
} 
