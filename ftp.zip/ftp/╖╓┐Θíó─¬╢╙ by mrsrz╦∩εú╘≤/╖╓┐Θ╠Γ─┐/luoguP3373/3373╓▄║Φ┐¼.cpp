#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
#define N 100005
int n,m;
long long mod,sum[N],qj_c[N],qj_j[N],k,ans,p,a[N];
int belong[100005],l[100005],r[100005];
void reset(int );
int main()
{
	scanf("%d%d%lld",&n,&m,&p);
	mod=sqrt(n);
	for(int i=1; i<=n; i++) belong[i]=i/mod;
	for(int i=n; i>=1; i--) l[belong[i]]=i;
	for(int i=1; i<=n; i++) r[belong[i]]=i;
	for(int i=1; i<=n; i++) scanf("%lld",&a[i]);
	for(int i=1; i<=n; i++) sum[belong[i]]+=a[i];
	for(int i=belong[1]; i<=belong[n]; i++) qj_c[i]=1;
	for(int i=1; i<=m; i++)
	{
		int opt,x,y;
		scanf("%d%d%d",&opt,&x,&y);
		if(opt==1)
		{
			scanf("%lld",&k);
			reset(belong[x]);
			int flag=min(y,r[belong[x]]);
			for(int j=x; j<=flag; j++)
				sum[belong[x]]+=(k-1)*a[j]%p,a[j]*=k,a[j]%=p;
			if(belong[x]!=belong[y])
			{
				reset(belong[y]);
				for(int j=y; j>=l[belong[y]]; j--)
					sum[belong[y]]+=(k-1)*a[j]%p,a[j]=a[j]*k%p;
			}
			for(int j=belong[x]+1; j<=belong[y]-1; j++)
				qj_c[j]*=k,qj_c[j]%=p,qj_j[j]*=k,qj_j[j]%=p,sum[j]*=k,sum[j]%=p;
		}
		if(opt==2)
		{
			scanf("%lld",&k);
			reset(belong[x]);
			sum[belong[x]]=(sum[belong[x]]+(min(y,r[belong[x]])-x+1)*k)%p;
			int flag=min(y,r[belong[x]]);
			for(int j=x; j<=flag; j++) a[j]+=k;
			if(belong[x]!=belong[y])
			{
				reset(belong[y]);
				sum[belong[y]]=(sum[belong[y]]+((y-l[belong[y]]+1)*k))%p;
				for(int j=y; j>=l[belong[y]]; j--)
					a[j]+=k;
				for(int j=belong[x]+1; j<=belong[y]-1; j++)
					qj_j[j]+=k,sum[j]=(sum[j]+mod*k)%p;
			}
		}
		if(opt==3)
		{
			ans=0;
			int flag=min(y,r[belong[x]]);
			for(int j=x; j<=flag; j++)
				ans+=(a[j]*qj_c[belong[x]]+qj_j[belong[x]])%p;
			if(belong[x]!=belong[y])
			{
				for(int j=y; j>=l[belong[y]]; j--)
					ans+=(a[j]*qj_c[belong[y]]+qj_j[belong[y]])%p;
				for(int j=belong[x]+1; j<=belong[y]-1; j++)
					ans+=sum[j];
			}
			printf("%lld\n",ans%p);
		}
	}
	return 0;
}
inline void reset(int x)
{
	for(int i=l[x]; i<=r[x]; i++)
		a[i]=(a[i]*qj_c[x]+qj_j[x])%p;
	qj_c[x]=1,qj_j[x]=0;
}
