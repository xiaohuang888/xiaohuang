#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define LL long long 
#define maxn 50005
using namespace std;
int n,m,rzt_id[maxn],c[maxn];
LL t[maxn],ans;
struct node
{
	int l,r,id;
	LL a,b;
} a[maxn];
bool cmp(const node&a,const node&b)
{
	if(rzt_id[a.l]==rzt_id[b.l])
		return a.r<b.r;
	return a.l<b.l;
}
bool cmp_rzt(const node&a,const node&b)
{
	return a.id<b.id;
}
void change(int p,int add)
{
	ans-=t[c[p]]*t[c[p]];
	t[c[p]]+=add;
	ans+=t[c[p]]*t[c[p]];
}
int main()
{
	scanf("%d%d",&n,&m);
	for(int i=1; i<=n; i++)
		scanf("%d",&c[i]);
	int len=sqrt(n);
	for(int i=1; i<=n; i++)
		rzt_id[i]=(i-1)/len+1;
	for(int i=1; i<=m; i++)
	{
		scanf("%d%d",&a[i].l,&a[i].r);
		a[i].id=i;
	}
	sort(a+1,a+m+1,cmp);
	for(int i=1,l=1,r=0; i<=m; i++)
	{
		for(; r<a[i].r; r++)
			change(r+1,1);
		for(; r>a[i].r; r--)
			change(r,-1);
		for(; l<a[i].l; l++)
			change(l,-1);
		for(; l>a[i].l; l--)
			change(l-1,1);
		if(a[i].l==a[i].r)
		{
			a[i].a=0;
			a[i].b=1;
			continue;
		}
		a[i].a=ans-(a[i].r-a[i].l+1);
		a[i].b=(a[i].r-a[i].l+1)*1LL*(a[i].r-a[i].l);
		LL gcd=__gcd(a[i].a,a[i].b);
		a[i].a/=gcd;
		a[i].b/=gcd;
	}
	sort(a+1,a+m+1,cmp_rzt);
	for(int i=1; i<=m; i++)
		printf("%lld/%lld\n",a[i].a,a[i].b);
	return 0;
}
