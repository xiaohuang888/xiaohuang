#include<bits/stdc++.h>
using namespace std;
int n,m,at[1000005],c[1000005],les[1000005];
int lowbit(int x)
{
	return x & (-x);
}
void change_point(int x,int y)
{
	for(; x <= n; x += lowbit(x))
	  c[x] += y; 
} 
int be_QAQ(int x)
{
	int ans = 0; 
	for (; x; x -= lowbit(x))
	  ans += c[x];
	return ans;
}
void init(){
	les[4] = 1;
    les[7] = 1;
    les[44] = 1;
    les[47] = 1;
    les[74] = 1;
    les[77] = 1;
    les[444] = 1;
    les[447] = 1;
    les[474] = 1;
    les[477] = 1;
    les[744] = 1;
    les[747] = 1;
    les[774] = 1;
    les[777] = 1;
    les[4444] = 1;
    les[4447] = 1;
    les[4474] = 1;
    les[4477] = 1;
    les[4744] = 1;
    les[4747] = 1;
    les[4774] = 1;
    les[4777] = 1;
    les[7444] = 1;
    les[7447] = 1;
    les[7477] = 1;
    les[7474] = 1;
    les[7744] = 1;
    les[7747] = 1;
    les[7774] = 1;
    les[7777] = 1;
}
int main(){
	init();
	scanf("%d%d",&n,&m);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d",&at[i]);
		if (les[at[i]])
		  change_point(i,1);
	}
	for (int i = 1; i <= m; i++)
	{
		int a,b,c;
		char op[50];
		scanf("\n%s",op);
		if (op[0] == 'a')
		{
			scanf("%d%d%d",&a,&b,&c);
			for (int j = a; j <= b; j++)
			if (!les[at[j] + c] && les[at[j]])
			  at[j] += c,change_point(j,-1);else
			if (les[at[j] + c] && !les[at[j]])
			  at[j] += c,change_point(j,1);else
			at[j] += c;
		} else
		{
			scanf("%d%d",&a,&b);
			printf("%d\n",be_QAQ(b) - be_QAQ(a - 1));
		}
	}
	return 0;
} 
