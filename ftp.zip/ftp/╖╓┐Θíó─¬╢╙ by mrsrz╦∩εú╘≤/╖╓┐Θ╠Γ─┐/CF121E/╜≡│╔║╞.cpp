//hao911 is dead at everyone srz's problems.
//so,he want to learn the habits about make code for fsq.
#include<bits/stdc++.h>
using namespace std;

const int flag[]={4,7,44,47,74,77,444,447,474,744,477,747,774,777,4444,4447,4474,4744,7444,4477,4747,7447,4774,7474,7744,4777,7477,7747,7774,7777};

int n,m,a[110000],tot,into[110000],bl,tag[400];
int bin[330][110000],num[110000],l,r,key;
int bz;
char str[10];

int main(){
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    bl=sqrt(n)*4;
    for(int i=1;i<=n;i++)
        into[i]=i/bl;
    tot=into[n];
    for(int i=1;i<=n;i++)
        bin[into[i]][a[i]]++;
    for(int i=0;i<30;i++)
        num[flag[i]]=true;
    for(int i=1;i<=m;i++){
        scanf("%s%d%d",str,&l,&r);
        if(str[0]=='a'){
            scanf("%d",&key);
            for(;l%bl!=0&&l<=r;l++){
                bin[into[l]][a[l]]--;
                bin[into[l]][a[l]+key]++;
                a[l]+=key;
            }
            for(;(r+1)%bl!=0&&l<=r;r--){
                bin[into[r]][a[r]]--;
                bin[into[r]][a[r]+key]++;
                a[r]+=key;
            }
            for(;l<=r;l+=bl)
                tag[into[l]]+=key;
        }
        else{
            int ans=0;
            for(;l%bl!=0&&l<=r;l++){
                if(num[a[l]+tag[into[l]]])
                    ans++;
            }
            bz=into[r];
            for(;(r+1)%bl!=0&&l<=r;r--){
                if(num[a[r]+tag[into[r]]])
                    ans++;
            }
            for(;l<=r;l+=bl)
                for(int k=0;k<30;k++)
                    if(tag[into[l]]<=flag[k])
                		ans+=bin[l/bl][flag[k]-tag[into[l]]];
            printf("%d\n",ans);
        }
    }
    return 0;
}
