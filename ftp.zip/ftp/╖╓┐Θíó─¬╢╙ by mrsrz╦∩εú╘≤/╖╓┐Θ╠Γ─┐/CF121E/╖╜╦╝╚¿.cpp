// hello I'am fsq
#include<bits/stdc++.h>
using namespace std;
const int f[30] = {4,7,44,47,74,77,444,447,474,477,744,747,774,777,4444,4447,4474,4477,4744,4747,4774,4777,7444,7447,7474,7477,7744,7747,7774,7777};
int sum[320][100009],add[320],n,m,block,belong[100009],a[100009],ans,num[10009],x,y,d;
char opt[10];
int main() {
	scanf("%d%d",&n,&m);
	block=sqrt(n)*4;
	for (int i=1; i<=n; i++)
		belong[i]=i/block;
	for (int i=1; i<=n; i++) {
		scanf("%d",&a[i]);
		sum[belong[i]][a[i]]++;
	}
	for (int i=0; i<30; i++)
		num[f[i]]=1;
	while (m--) {
		scanf("%s%d%d",opt,&x,&y);
		if (opt[0]=='a') {
			scanf("%d",&d);
			for (; x%block!=0 && x<=y; x++)
				sum[belong[x]][a[x]]--,sum[belong[x]][a[x]+d]++,a[x]+=d;
			for (; (y+1)%block!=0 && x<=y; y--)
				sum[belong[y]][a[y]]--,sum[belong[y]][a[y]+d]++,a[y]+=d;
			for (; x<=y; x+=block)
				add[belong[x]]+=d;
		} else {
			ans=0;
			for (; x%block!=0 && x<=y; x++)
				ans+=num[a[x]+add[belong[x]]];
			for (; (y+1)%block!=0 && y>=x; y--)
				ans+=num[a[y]+add[belong[y]]];
			for (; x<=y; x+=block) {
				for (int i=0; i<30; i++)
					if (f[i]-add[belong[x]]>=0)
						ans+=sum[x/block][f[i]-add[belong[x]]];
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}

