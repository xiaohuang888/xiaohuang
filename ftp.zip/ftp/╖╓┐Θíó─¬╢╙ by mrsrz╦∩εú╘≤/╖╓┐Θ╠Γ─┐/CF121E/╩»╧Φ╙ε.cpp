#include<cstdio>
#define change(x,y,z) num[x][y]--,num[x][y+=z]++
const int maxn=1e5+1;
const int cnt=110;
const int k=1585;
const int number[30]={4, 7, 44, 47, 74, 77, 444, 447, 474, 477, 744, 747, 774, 777, 4444, 4447, 4474, 4477, 4744, 4747, 4774, 4777, 7444, 7447, 7474, 7477, 7744, 7747, 7774, 7777};
int l[cnt],r[cnt],tag[cnt],num[cnt][maxn],x,y,d;
int a[maxn],belong[maxn];
int n,m,i;
bool get[10001];
char opt[10];
inline int read()
{
    char c=getchar();int x=0,f=1;
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0',c=getchar();}
    return x*f;
}
void add(int x,int y,int z){
    int ll=belong[x],rr=belong[y];
    if (ll==rr){
        for (int i=x;i<=y;i++) change(ll,a[i],z);
    }
    else {
        for (int i=x;i<=r[ll];i++) change(ll,a[i],z);
        for (int i=ll+1;i<rr;i++) tag[i]+=z;
        for (int i=l[rr];i<=y;i++) change(rr,a[i],z);
    }
}
void query(int x,int y){
    int ans=0;
    int ll=belong[x],rr=belong[y];
    if (ll==rr){
        for (int i=x;i<=y;i++) ans+=get[a[i]+tag[ll]];
    }
    else {
        for (int i=x;i<=r[ll];i++) ans+=get[a[i]+tag[ll]];
        for (int i=ll+1;i<rr;i++)
            for (int j=0;j<30;j++) if (tag[i]<=number[j]) ans+=num[i][number[j]-tag[i]];
        for (int i=l[rr];i<=y;i++) ans+=get[a[i]+tag[rr]];
    }
    printf("%d\n",ans);
}
int main(){
    n=read();m=read();
    for (i=1;i<=n;i++){
        a[i]=read();
        belong[i]=i/k+1;
        num[belong[i]][a[i]]++;
    }
    int b=belong[n];
    for (i=1;i<=b;i++) l[i]=(i-1)*k,r[i]=i*k-1;
    for (i=0;i<30;i++) get[number[i]]=1;
    l[1]=1;r[b]=n;
    for (i=1;i<=m;i++){
        scanf("%s",opt);
        x=read();y=read();
        if (*opt=='a'){
            d=read();
            add(x,y,d);
        }
        else query(x,y);
    }
    return 0;
}
