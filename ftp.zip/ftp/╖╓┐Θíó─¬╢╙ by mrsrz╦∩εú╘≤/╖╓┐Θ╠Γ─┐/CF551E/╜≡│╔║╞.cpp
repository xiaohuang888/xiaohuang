//ǿ��Ҫ���ž���ͬѧ����дע�;Ͳ�Ҫ����⡣������ͬѧ�� 
#include<bits/stdc++.h>
using namespace std;
struct node{
    long long val,id;
}a[600000];

long long n,q,l,r,key,opt,bl,tot; 
long long L[750],R[750],into[600000],tag[750];

bool cmp(node xx,node yy){
    if(xx.val<yy.val)
        return true;
    if(xx.val>yy.val)
        return false;
    if(xx.id<yy.id)
        return true;
    return false;
}

int main(){
    scanf("%d%d",&n,&q);
    for(int i=0;i<n;i++){
        scanf("%d",&a[i].val);
        a[i].id=i;
    }
    bl=sqrt(n);
    for(int i=0;i<n;i++){
        into[i]=i/bl;
    }
    tot=into[n-1];
    for(int i=0;i<n;i++){
        R[into[i]]=i;
    }
    for(int i=n-1;i>=0;i--){
        L[into[i]]=i;
    }
    for(int i=0;i<=tot;i++)
        sort(a+L[i],a+R[i]+1,cmp);
    while(q--){
        scanf("%d",&opt);
        if(opt==1){
            scanf("%d%d%d",&l,&r,&key);
            l--;
            r--;
            for(int i=0;i<=tot;i++)
                if(L[i]>=l&&R[i]<=r)
                    tag[i]+=key;else
                    if(L[i]>r||R[i]<l)
                        continue;else
                    {
                        for(int j=L[i];j<=R[i];j++)
                            if(a[j].id>=l&&a[j].id<=r)
                                a[j].val+=key;
                        sort(a+L[i],a+R[i]+1,cmp);
                    }
        }else
        {
            scanf("%d",&key);
            long long num1=1000000000,num2=-1; 
            for(int i=0;i<=tot;i++){
                long long keyy=key-tag[i];
                long long l1=L[i],r1=R[i],mid;
                while(l1<r1){ 
                    mid=(l1+r1)>>1;
                    if(a[mid].val<keyy)
                        l1=mid+1;else
                        r1=mid;
                }
                if(a[r1].val==keyy)
                    num1=min(num1,a[r1].id);
                l1=L[i],r1=R[i];
                while(l1<r1){
                    mid=(l1+r1+1)>>1;
                    if(a[mid].val>keyy)
                        r1=mid-1;else
                        l1=mid;
                }
                if(a[r1].val==keyy)
                    num2=max(num2,a[r1].id);
            }
            if(num1==1000000000||num2==-1)
                printf("-1\n");else
                printf("%lld\n",num2-num1);
        }
    }
    return 0;
}
