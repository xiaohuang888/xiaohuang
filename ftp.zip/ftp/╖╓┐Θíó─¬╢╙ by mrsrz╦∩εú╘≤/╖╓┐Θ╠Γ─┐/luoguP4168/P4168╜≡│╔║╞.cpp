#include<bits/stdc++.h>
using namespace std;

int n,m,a[50000],b[50000],s[50000],c[300][50000];
int L[300],R[300],into[50000],bl,f[300][300];
int tot,pos,maxid,maxsum,x;
int l,r,cmp1,cmp2,bin[50000];
int num1,num2,val;

int main(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	
	int bl=sqrt(n);
	for(int i=0;i<n;i++)
		into[i]=i/bl;
	for(int i=n-1;i>=0;i--)
		L[into[i]]=i;
	for(int i=0;i<n;i++)
		R[into[i]]=i;
	tot=into[n-1]+1;
	
	sort(b,b+n);
	pos=1;
	s[pos]=b[0];
	for(int i=1;i<n;i++)
		if(b[i]!=b[i-1]){
			pos++;
			s[pos]=b[i];
		}
	for(int i=0;i<n;i++){
		int low=1,high=pos,mid,id;
    	while(low<=high){
    		if(s[low]==a[i]){
    			id=low;break;
    		}
    		if(s[high]==a[i]){
				id=high;break;
			}
   		 	mid=low+(high-low)/2;
    		if(s[mid]==a[i]){
    	 		id=mid;break;
    	 	}
    	 	if(s[mid]<a[i])
    	 		low=mid+1;else
    	  		high=mid-1;
    	}
    	a[i]=id;
	}
	
	for(int i=0;i<n;i++)
		c[into[i]][a[i]]++;
		
	for(int i=0;i<tot;i++){
		maxsum=0;
		maxid=0;
		for(int j=L[i];j<=R[i];j++){
			if(c[i][a[j]]>maxsum||(c[i][a[j]]==maxsum&&maxid>a[j])){
				maxsum=c[i][a[j]];
				maxid=a[j];
			}
		}
		f[i][i]=maxid;
	}
	for(int i=1;i<tot;i++){
		for(int j=1;j<=pos;j++)
			c[i][j]+=c[i-1][j];
	}
	for(int i=0;i<tot;i++)
		for(int k=i+1;k<tot;k++){
			maxsum=0;
			maxid=0;
			for(int j=L[k];j<=R[k];j++){
				if(i!=0)
					val=c[k][a[j]]-c[i-1][a[j]];else
					val=c[k][a[j]];
				if(val>maxsum||(val==maxsum&&maxid>a[j])){
					maxsum=val;
					maxid=a[j];
				}
			}
			if(i!=0)
				val=c[k][f[i][k-1]]-c[i-1][f[i][k-1]];else
				val=c[k][f[i][k-1]];
			if(val>maxsum||(val==maxsum&&maxid>f[i][k-1])){
				maxsum=val;
				maxid=f[i][k-1];
			}	
			f[i][k]=maxid;
		}
	
	x=0;
	while(m--){
		scanf("%d%d",&l,&r);
		l=(l+x-1)%n+1;l--;
		r=(r+x-1)%n+1;r--;
		if(l>r)
			swap(l,r);
		cmp1=l;cmp2=r;
		for(;l%bl!=0&&l<=r;l++)
			bin[a[l]]++;
		for(;(r+1)%bl!=0&&l<=r;r--)
			bin[a[r]]++;
		maxsum=0;
		maxid=0;
		if(l>r){
			l=cmp1;r=cmp2;
			for(;l%bl!=0&&l<=r;l++)
				if(bin[a[l]]>maxsum||(bin[a[l]]==maxsum&&maxid>a[l])){
					maxsum=bin[a[l]];
					maxid=a[l];
				}
			for(;(r+1)%bl!=0&&l<=r;r--)
				if(bin[a[r]]>maxsum||(bin[a[r]]==maxsum&&maxid>a[r])){
					maxsum=bin[a[r]];
					maxid=a[r];
				}
		}else
		{
			num1=into[l];num2=into[r];
			l=cmp1;r=cmp2;
			for(;l%bl!=0&&l<=r;l++){
				if(num1!=0)
					val=bin[a[l]]+c[num2][a[l]]-c[num1-1][a[l]];else
					val=bin[a[l]]+c[num2][a[l]];
				if(val>maxsum||(val==maxsum&&maxid>a[l])){
					maxsum=val;
					maxid=a[l];
				}
			}
			for(;(r+1)%bl!=0&&l<=r;r--){
				if(num1!=0)
					val=bin[a[r]]+c[num2][a[r]]-c[num1-1][a[r]];else
					val=bin[a[r]]+c[num2][a[r]];
				if(val>maxsum||(val==maxsum&&maxid>a[r])){
					maxsum=val;
					maxid=a[r];
				}
			}
			if(num1!=0)
				val=bin[f[num1][num2]]+c[num2][f[num1][num2]]-c[num1-1][f[num1][num2]];else
				val=bin[f[num1][num2]]+c[num2][f[num1][num2]];
			if(val>maxsum||(val==maxsum&&maxid>f[num1][num2])){
				maxsum=val;
				maxid=f[num1][num2];
			}
		}
		printf("%d\n",s[maxid]);
		x=s[maxid];
		l=cmp1;r=cmp2;
		for(;l%bl!=0&&l<=r;l++)
			bin[a[l]]--;
		for(;(r+1)%bl!=0&&l<=r;r--)
			bin[a[r]]--;
	}
	
	return 0;
}
