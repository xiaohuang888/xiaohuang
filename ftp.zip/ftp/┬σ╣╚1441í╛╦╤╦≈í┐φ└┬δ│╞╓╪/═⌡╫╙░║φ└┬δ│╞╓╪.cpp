#include<cstdio>
#include<cstring>
#include<algorithm>
#define maxn 25
#define maxm 2005
using namespace std;
int n,m,a[maxn],Ans;
bool t[maxn],f[maxm];
void dp(){
    memset(f,0,sizeof(f));
    f[0]=1;
    int ans=0,s=0;
    for(int i=0;i<n;i++){
        if(t[i])	continue;
        for(int j=s;j>=0;j--)	
            if(f[j]&&!f[j+a[i]]) f[j+a[i]]=1,ans++;
        s+=a[i];
    }
    Ans=max(ans,Ans);
}
void dfs(int s,int now){

    if(now>m) return;
    if(s==n){
        if(now==m)dp();
        return;
    }
    dfs(s+1,now);t[s]=1;
    dfs(s+1,now+1);t[s]=0; 
} 
int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    dfs(0,0);
    printf("%d\n",Ans);
    return 0;
}