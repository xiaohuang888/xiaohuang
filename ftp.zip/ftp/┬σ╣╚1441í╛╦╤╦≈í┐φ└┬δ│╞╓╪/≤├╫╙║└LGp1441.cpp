#include<iostream>
#include<cstring>
using namespace std;
int n,m,s,ans,mmax,xb,w[21];
bool b[21],f[2001];
void dfs(int step,int qs){
	if (step==m+1){
		memset(f,false,sizeof(f));
//		cout<<f[1];
		f[0]=true;
		ans=0;
		for (int i=1;i<=xb;++i){
			if (!b[i]){
				for (int j=s;j>=w[i];--j){
					if (f[j-w[i]]&&!f[j]){
						++ans;
						f[j]=true;
					}
				}
			}
		}
		if (ans>mmax){
			mmax=ans;
		}
	}
	for (int i=qs+1;i<=n;++i){
		b[i]=true;
		dfs(step+1,i);
		b[i]=false;
	}
}
int main(){
	cin>>n>>m;
	for (int i=1;i<=n;++i){
		cin>>w[i];
		s+=w[i];
	}
	xb=n;
	dfs(1,0);
	cout<<mmax;
}
