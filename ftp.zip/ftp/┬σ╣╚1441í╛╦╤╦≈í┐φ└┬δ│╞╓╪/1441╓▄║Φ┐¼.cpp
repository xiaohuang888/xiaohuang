#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=22;
const int maxm=2010;
int n,m,a[maxn],ans,tot,s;
bool flag[maxn],f[maxm];
void dp()
{
	memset(f,0,sizeof(f));
	f[0]=true;
	ans=0;
	tot=0;
	for(int i=0; i<n; i++)
	{
		if (flag[i]) continue;
		for (int j=tot; j>=0; j--) if (f[j]&&!f[j+a[i]]) f[j+a[i]]=1,ans++;
		tot+=a[i];
	}
	s=max(ans,s);
}
void dfs(int c,int now)
{
	if (now>m) return;
	if (c==n)
	{
		if (now==m) dp();
		return;
	}
	dfs(c+1,now);
	flag[c]=1;
	dfs(c+1,now+1);
	flag[c]=0;
}
int main()
{
	scanf("%d%d",&n,&m);
	for (int i=0; i<n; i++) scanf("%d",a+i);
	dfs(0,0);
	printf("%d\n",s);
	return 0;
}
