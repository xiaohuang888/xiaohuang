#include<iostream>
#include<cstdio>
using namespace std;
int dp[3010],yn[21],fm[21],n,m,ans,x,bx;
void dfs(int o){
	if(x==m){
		for(int i=0;i<2500;i++)
		dp[i]=0;
		dp[0]=1;
		int q=0,w=0;
		for(int i=0;i<n;i++){
			if(yn[i]==0)
			{
				for(int j=w;j>=0;j--){
					if(dp[j]==1&&dp[j+fm[i]]==0){
						dp[j+fm[i]]=1;
						q++;
					}
				}
				w+=fm[i];
			}
		}
		ans=max(ans,q);
		return;
	}
	if(n-bx<m)return;
	bx++;
	dfs(o+1);
	bx--;
	x++;
	yn[o]=1;
	dfs(o+1);
	yn[o]=0;
	x--;
	return;
}
int main(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&fm[i]);
	}
	dfs(0);
	printf("%d",ans);
}
