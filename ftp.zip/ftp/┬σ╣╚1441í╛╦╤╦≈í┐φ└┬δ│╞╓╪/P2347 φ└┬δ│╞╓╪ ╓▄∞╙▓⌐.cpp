#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,a[30],b[30],xb=1,f[2010],ans=0;
void dp(){
    memset(f,0,sizeof(f));
    f[0]=1;
    for(int i=1;i<=n;i++){
        if(!b[i]){
            for(int j=2000;j>=a[i];j--){
                if(f[j-a[i]]&&!f[j])
                    f[j]=1;
            }
        }
    }
    int cnt=0;
    for(int i=1;i<=2000;i++){
        if(f[i]) cnt++;
    }
    ans=max(ans,cnt);
}
void dfs(int c){
    if(c==m) {
        dp();
        return;
    }
    for(int i=xb;i<=n;i++){
        if(!b[i]){
            b[i]=1;
            xb=i+1;
            dfs(c+1);
            b[i]=0;
        }
    }
}
int main(){
   	cin>>n>>m;
    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    sort(a+1,a+n+1);
    dfs(0);
    printf("%d\n",ans);
    return 0;
} 
