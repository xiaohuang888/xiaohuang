#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,a[25],ans,tot,sum;
bool flag[25],f[2020];
void dp() {
	memset(f,0,sizeof f);
	f[0]=true;
	ans=0;
	tot=0;
	for(int i=0; i<n; i++) {
		if(flag[i])continue;
		for(int j=tot; j>=0; j--)if(f[j]&&!f[j+a[i]]) {
				f[j+a[i]]=true,ans++;
			}
		tot+=a[i];
	}
	sum=max(ans,sum);
}
void dfs(int x,int y) {
	if(y>m)return;
	if(x==n) {
		if(y==m)dp();
		return;
	}
	dfs(x+1,y);
	flag[x]=true;
	dfs(x+1,y+1);
	flag[x]=false;
}
int main() {
	scanf("%d%d",&n,&m);
	for(int i=0; i<n; i++)scanf("%d",a+i);
	dfs(0,0);
	printf("%d\n",sum);
	return 0;
}
