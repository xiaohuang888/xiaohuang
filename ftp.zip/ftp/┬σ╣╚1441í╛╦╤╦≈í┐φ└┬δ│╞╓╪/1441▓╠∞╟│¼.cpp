#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int zl[3010],yby[21],a[21],n,m,ans,by=0,y=0;
void dfs(int o)
{
	int tot=0,zz=0,i,j;
	if(by==m)
	{
		memset(zl,0,sizeof(zl));
		zl[0]=1;
		for(i=1;i<=n;i++)
		{
			if(!yby[i])
			{
				for(j=zz;j>=0;j--)
				{
					if(zl[j]==1&&!zl[j+a[i]])
					{
						zl[j+a[i]]=1;
						tot++;
					}
				}
				zz+=a[i];
			}
		}
		ans=max(ans,tot);
		return;
	}
	if(o>n)
	return;
	dfs(o+1);
	by++;
	yby[o]=1;
	dfs(o+1);
	yby[o]=0;
	by--;
	return;
}
int main()
{
	int i;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	dfs(1);
	cout<<ans<<endl;
}
