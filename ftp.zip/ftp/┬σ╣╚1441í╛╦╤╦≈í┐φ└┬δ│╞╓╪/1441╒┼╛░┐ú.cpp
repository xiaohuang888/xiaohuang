#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,m,a[205],ans=0;
bool f[20005],vis[205];
void dfs(int c,int qs) {
	if(c==(m+1)) {
		int sum=0;
		for (int i=1;i<=n;++i) 
			if(!vis[i]) sum+=a[i];
		memset(f,false,sizeof(f));
		f[0]=true;
		for (int i=1;i<=n;++i)
			if(!vis[i])
				for (int j=sum;j>=a[i];--j)
					f[j]=f[j]||f[j-a[i]];
		int res=0;
		for (int i=1;i<=sum;++i) if(f[i]) res++;
		if(res>ans) ans=res;
		return ;
	}
	for (int i=qs+1;i<=n;++i) {
		vis[i]=true;
		dfs(c+1,i);
		vis[i]=false;
	}
	return ;
}
int main() {
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i) scanf("%d",&a[i]);
	dfs(1,0);
	printf("%d\n",ans);
}
