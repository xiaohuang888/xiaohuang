#include<bits/stdc++.h>
using namespace std;
int vis[22],a[22],f[2222],n,m,ans,mx,s,i,j;
void fac() {
    for (int i=1; i<=n; i++)
        for (s+=a[i],j=s; j>=a[i] && !vis[i]; f[j]=f[j]|f[j-a[i]],j--);
    for (int i=1; i<=s; mx+=f[i],i++);
}
void justry(int last,int cs) {
    if (cs==m) memset(f,0,sizeof(f)),f[0]=1,mx=0,s=0,j,fac(),ans=max(ans,mx);
    for (int i=last; i<=n && cs<m; vis[i]=1,justry(i+1,cs+1),vis[i]=0,i++);
}
int main() {
    for (scanf("%d%d",&n,&m),i=1; i<=n; scanf("%d",&a[i]),i++);
    justry(1,0),printf("%d\n",ans);
}
