#include<bits/stdc++.h>
using namespace std;
int n;
int l;
int a[100];
int lmark;
int vis[100];
bool cmp(int x,int y){
	return x>y; 
}
int dfs(int num,int len){
	if(num==0&&len==0)
		return 1;
	if(len==0)
		len=l;
 	int mark=1;
 	if(len!=l)
 		mark=lmark+1;
	for(int i=mark;i<=n;i++){
		if(vis[i]==0&&a[i]<=len){
			if(i>1)
				if(vis[i-1]==0&&a[i]==a[i-1])
					continue;
			vis[i]=1;
			lmark=i;
			if(dfs(num-1,len-a[i]))
				return 1;
			else{
				vis[i]=0;
				if(len==a[i]||len==l)
					return 0;
			}
		}
	}
	return 0;
}
int main(){
	int cnt;
	scanf("%d",&cnt);
		int sum=0;
		for(int i=1;i<=cnt;i++){
			int x;
			scanf("%d",&x);
			if(x>50)
				continue;
			a[++n]=x;
			sum+=a[n];
		}
		int ans=0;
		sort(a+1,a+1+n,cmp);
		for(l=a[1];l<=sum/2;l++){
 			if(sum%l)
		 		continue;
			memset(vis,0,sizeof(vis));
			lmark=1;
			if(dfs(n,l)){
				ans=l;
				break;
			}
		}
		if(ans)
			printf("%d\n",ans);
		else
			printf("%d\n",sum);	
	return 0;
}
