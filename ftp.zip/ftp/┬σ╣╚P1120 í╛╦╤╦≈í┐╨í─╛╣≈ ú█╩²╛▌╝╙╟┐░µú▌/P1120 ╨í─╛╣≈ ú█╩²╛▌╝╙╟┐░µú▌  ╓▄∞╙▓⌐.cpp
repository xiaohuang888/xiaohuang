#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
bool t,b[100];
int n,a[100],c,s,lmark,x,xb;
bool cmp(int a,int b){
	return a>b;
}
int dfs(int m,int r){
	if(m==0&&r==0){
		return 1;
	}
	if(r==0) r=c;
	int mark=1;
	if(r!=c) mark=lmark+1;
		for(int i=mark;i<=n;i++){
			if(!b[i] && a[i]<=r){
				if(i>1){
					if(b[i-1]==false && a[i]==a[i-1]) continue;
				}
				b[i]=true;
				lmark=i;
				if(dfs(m-1,r-a[i]))
					return 1; 
				else {
					b[i]=false;
					if(r==a[i] || r==c){
						return 0;
					}
				}
			}
		}
	return 0;
}
int main(){
		cin>>n;
		s=0;
		for(int i=1;i<=n;i++){
			cin>>x;
			if(x>50)
                      continue;
                  a[++xb]=x;
                   s+=a[xb];
		}
		n=xb;
		sort(a+1,a+n+1,cmp);
		int ans=0;
		for(int i=a[1];i<=s/2;i++){
			if(s%i==0){
				lmark=1;
				c=i;
				memset(b,0,sizeof(b));
				if(dfs(n,i)){
					ans=i;
					break;
				}
			}
		}
		if(ans) cout<<ans<<endl;
		else cout<<s<<endl;
	return 0;
}
