#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int sf[70],s[70],n,mugun,guolv,maxs=0,zong,ger,q,yi,next[70];
void print(){
	printf("%d",q);
	exit(0);
}
void dfs(int o,int sheng){
	if(sheng==0){
		if(ger==0)print();
		for(int i=n-1;i>=0;i--)
		if(s[i]==0){
			s[i]=1;
			ger--;
			dfs(i,q-sf[i]);
			ger++;
			s[i]=0;
			break;
		}
	}
	for(int i=o-1;i>=0;i--){
		if(s[i]==0&&sf[i]<=sheng){
			s[i]=1;
			ger--;
			dfs(i,sheng-sf[i]);
			ger++;
			s[i]=0;
			if(sheng==sf[i]||sheng==q)return;
			i=next[i];
		}
	}
}
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&sf[i-guolv]);
		if(sf[i-guolv]>50)
		guolv++;
		else{
			maxs=max(maxs,sf[i-guolv]);
			zong+=sf[i-guolv];
		}
	}
	n-=guolv;
	sort(sf,sf+n);
	next[0]=0;
    for(int i=1;i<n;i++){
        if(sf[i]==sf[i-1]) next[i]=next[i-1];
        else next[i]=i;
    }
	for(q=maxs;q<=zong/2;q++){
		if(zong%q==0){
			ger=n-1;
			s[n-1]=1;
			dfs(n-1,q-sf[n-1]);
			s[n-1]=0;
		}
	}
	printf("%d",zong);
}
