#include <iostream>
#include <cstdio>
#include <algorithm>
#define Rint register int
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x) {
	x=0;
	T w=1,ch=getchar();
	while(!isdigit(ch)&&(ch!='-')) ch=getchar();
	if(ch=='-') w=-1;
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
const int maxnn=105;
int n,a[maxnn],res=0,maxn,max1;
bool cmp(int x,int y) {
	return x>y;
}
bool vis[maxnn];
inline void dfs(int ans,int sum,int mb,int nt) {
	if(sum*mb==maxn) {
		printf("%d\n",mb);
		exit(0);
	}
	if(ans==mb) {
		dfs(0,sum+1,mb,1);
		return;
	}
	if((mb-ans)<a[res]) return ;
	for(Rint i=nt; i<=res; i++)
		if(!vis[i] && ans+a[i]<=mb) {
			vis[i]=true;
			dfs(ans+a[i],sum,mb,i+1);
			vis[i]=false;
			if((ans+a[i]==mb)||(ans==0)) break;
			while(a[i]==a[i+1]) ++i;
		}
}
int main() {
	read(n);
	for(Rint i=1; i<=n; i++) {
		int x;
		read(x);
		if(x<=50) {
			a[++res]=x;
			maxn+=a[res];
			max1=max(a[res],max1);
		}
	}
	sort(a+1,a+res+1,cmp);
	for(Rint i=max1; i<=maxn/2; i++) if(maxn%i==0) dfs(0,0,i,1);
	printf("%d\n",maxn);
	return 0;
}
