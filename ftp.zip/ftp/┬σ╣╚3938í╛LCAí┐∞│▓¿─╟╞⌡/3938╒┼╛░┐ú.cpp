#include <iostream>
#include <cstdio>
#include <algorithm>
#define Rint register int
#define Temp template<typename T> 
using namespace std;
typedef long long ll;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-') ch=getchar();
    if(ch=='-') w=-1,ch=getchar();
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w;
}
ll n,x,y;
ll f[1005];
inline void solve(ll a,ll b) {
	if(a<b) swap(a,b);
	if(a==b) {
		printf("%lld\n",a);
		return ;
	}
	int fi=lower_bound(f,f+62,a)-f;
	solve(b,a-f[fi-1]);
}
int main() {
	read(n);
	f[0]=1;f[1]=1;
	for (int i=2;i<=61;++i) f[i]=f[i-1]+f[i-2];
	while(n--) {
		read(x);
		read(y);
		solve(x,y);
	}
	return 0;
}
