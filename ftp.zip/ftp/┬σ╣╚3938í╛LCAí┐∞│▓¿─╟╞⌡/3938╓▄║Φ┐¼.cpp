#include <cstdio>
#include<algorithm>
using namespace std;
long long f[61]={0,1};
long long a,b;
int n,x,y;
void ans()
{
	while (f[y]>=b) y--;
	b=b-f[y];
}
int main()
{
	for (int i=2; i<=60; i++) f[i]=f[i-1]+f[i-2];
	scanf("%d",&n);
	while (n--)
	{
		scanf("%lld%lld",&a,&b);
		x=60,y=60;
		while (a!=b)
		{
			if (a>b) swap(a,b),swap(x,y);
			ans();
		}
		printf("%lld\n",a);
	}
	return 0;
}
