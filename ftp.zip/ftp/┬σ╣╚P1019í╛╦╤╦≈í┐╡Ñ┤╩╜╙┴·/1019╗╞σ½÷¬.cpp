#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<string>

using namespace std;

const int INF=0x3f3f3f3f;
int n, Max, now, k, vis[25];
string s[25];
inline void dfs(int t)
{
    if (now>Max) Max=now;
    for (int i=1; i<=n; i++)
        if (vis[i]<2) {
            for (int j=0; j<=s[t].length(); j++)
                if (s[i][0]==s[t][j]) {
                    int len1=0, len2=j;
                    while (s[i][len1]==s[t][len2] && len2<=s[t].length()) {
                        len1++;
                        len2++;
                    }
                    if (len2>=s[t].length()) {
                        now+=s[i].length()-len1;
                        vis[i]++;
                        dfs(i);
                        vis[i]--;
                        now-=s[i].length()-len1;
                    }
                }
        }
    }
int main() {
    scanf("%d",&n);
    for (int i=1; i<=n; i++) 
        cin>>s[i];
    cin>>s[0];
    Max=-INF;
    now=1;
    dfs(0);
    printf("%d\n",Max);
    return 0;
}