#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
using namespace std;
string s[20];
int vis[20],maxn=0,n;
int com(string s1,string s2) {
	for(int i=1;i<min(s1.length(),s2.length());i++) {
		int flag=1;
		for(int j=0;j<i;j++)
			if(s1[s1.length()-i+j]!=s2[j]) flag=0;
		if(flag) return i;
	}
	return 0;
}
void dfs(string ss, int len) {
	maxn=max(len,maxn);
	for(int i=0;i<n;i++) {
		if(vis[i]>=2)continue;
		int c=com(ss,s[i]);
		if(c>0) {
			vis[i]++;
			dfs(s[i],len+s[i].length()-c);
			vis[i]--;
		}
	}
}
int main()
{
	scanf("%d",&n);
	for(int i = 0; i <= n; i++) {
		vis[i] = 0;
		cin>>s[i];
	}
	dfs(' '+s[n], 1);
	printf("%d\n",maxn);
	return 0;
}
