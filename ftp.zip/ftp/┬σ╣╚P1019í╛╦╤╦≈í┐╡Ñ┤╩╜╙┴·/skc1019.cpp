#include<iostream>
#include<string>
#include<iomanip>
#include<vector>
#include<algorithm>
#include<math.h>
#include<cstring>
#include<functional>
#include<fstream>
#include<sstream>
using namespace std;
int chains_string(string s1,string s2)
{
    int i,j;
    for(i=s1.size()-1;i>0;i--)
    {
        if(s1[i]==s2[0])
        {
            for(j=i;j<s1.size();j++)
            {
                if(s1[j]!=s2[j-i]) break;
                if(j==s1.size()-1) return s2.size()-s1.size()+i;
            }
        }
    }
    return -1;
}
int n,vis[50],longest=0,length=1;
string s[50];
char ch;
void dfs(int x)
{
    int w,i;
    if(length>longest) longest=length;
    for(i=1;i<=n*2;i++)
    {
        if(vis[i]) continue;
        w=chains_string(s[x],s[i]);
        if(w==-1) continue;
        vis[i]=1;
        length+=w;
        dfs(i);
        vis[i]=0;
        length-=w;
    }
}
int main()
{
    int i;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>s[i*2-1];
        s[i*2]=s[i*2-1];
    }
    cin>>ch;
 	s[0]="$a";
    s[0][1]=ch;
    dfs(0);
    cout<<longest<<endl;
    return 0;
}
