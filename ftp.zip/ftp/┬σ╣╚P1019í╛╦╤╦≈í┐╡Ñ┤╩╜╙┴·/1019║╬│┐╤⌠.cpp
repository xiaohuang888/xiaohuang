#include<bits/stdc++.h>
#include<algorithm>
#include<cstring>
using namespace std;
char str[101][106],st;
int a[101],n,t=0,mmax=0,l[101],n2;
void dfs(int x,int y)
{
	if(t>mmax)
		mmax=t;
	for(int i=1;i<=n2;++i)
	{
		if(x==1)
		{
			if(str[i][0]!=st)
				continue;
			l[i]=1;
			t+=a[i];
			dfs(x+1,i);
			l[i]=0;
			t-=a[i];
		}
		if(l[i]==1)
			continue;
		int c=1,k=a[y]-1;
		char d[1001]={'\0'},e[1001]={'\0'};
		while(c<=a[i]&&c<a[y])
		{
			strncpy(d,str[i],c);
			strncpy(e,&str[y][k--],c);
			if(strcmp(d,e)==0)
			{
				t+=a[i]-c;
				l[i]=1;
				dfs(x+1,i);
				t-=a[i]-c;
				l[i]=0;
				break;
			}
			++c;
		}
	}
}
int main()
{
	//freopen("solitaire.in","r",stdin);
	//freopen("solitaire.out","w",stdout);
	cin>>n;
	n2=2*n;
	for(int i=1;i<=n;++i)
	{
		cin>>str[i];
		a[i]=strlen(str[i]);
	}
	for(int i=n+1;i<=n2;++i)
	{
		strcpy(str[i],str[i-n]);
		a[i]=a[i-n];
	}
	cin>>st;
	dfs(1,0);
	cout<<mmax<<endl;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
