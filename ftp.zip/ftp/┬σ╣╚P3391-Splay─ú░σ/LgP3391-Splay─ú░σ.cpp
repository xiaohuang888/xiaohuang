#include <iostream>
#include <cstdio>
#define Rint register int
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-') ch=getchar();
    if(ch=='-') w=-1,ch=getchar();
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w;
}
const int maxn=1e5+10;
int n,m;
int father[maxn],ch[maxn][2],siz[maxn],laz[maxn],rt;
inline void pushup(int x) {
    siz[x]=siz[ch[x][0]]+siz[ch[x][1]]+1;
}
void pushdown(int x) {
    if(laz[x]) {
        swap(ch[x][0],ch[x][1]);
        laz[ch[x][0]]^=1;laz[ch[x][1]]^=1;laz[x]=0;
    }
}
void rot(int x,int &k) {
    int y=father[x],z=father[y],kind;
    if(ch[y][0]==x) kind=1;
    else kind=0;
    if(y==k) k=x;
    else {
        if(ch[z][0]==y) ch[z][0]=x;
        else ch[z][1]=x;
    }
    ch[y][kind^1]=ch[x][kind];father[ch[y][kind^1]]=y;
    ch[x][kind]=y;father[y]=x;father[x]=z;
    pushup(x);
	pushup(y);
}
void splay(int x,int &k) {
    while(x!=k) {
        int y=father[x],z=father[y];
        if(y!=k) {
            if((ch[y][0]==x)^(ch[z][0]==y)) rot(x,k);
            else rot(y,k);
        }
        rot(x,k);
    }
}
void build(int l,int r,int f) {
    if(l>r) return ;
    int mid=(l+r)>>1;
    if(mid<f) ch[f][0]=mid;
    else ch[f][1]=mid;
    father[mid]=f;
    siz[mid]=1;
    if(l==r) return ;
    build(l,mid-1,mid);
	build(mid+1,r,mid);
    pushup(mid);
}

int find_(int x,int k) {
    pushdown(x);int s=siz[ch[x][0]];
    if(k==s+1) return x;
    if(k<=s) return find_(ch[x][0],k);
    else return find_(ch[x][1],k-s-1);
}

void work(int l,int r) {
    int x=find_(rt,l),y=find_(rt,r+2);
    splay(x,rt);splay(y,ch[x][1]); 
	int z=ch[y][0];
    laz[z]^=1;
}

int main() {
    read(n);read(m);
    rt=(n+3)>>1;
	build(1,n+2,rt);
    for (int i=1;i<=m;++i) {
        int a,b;
        read(a);read(b);
        work(a,b);
    }
    for (int i=2;i<=n+1;++i) printf("%d ",find_(rt,i)-1);
    return 0;
}
