#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define MAXN 100005

using namespace std;

typedef long long LL;
const int N=100005;
int n, now, ls[N], rs[N], dis[N], head[N], cnt;
LL m, C[N], L[N], sum[N], sz[N], ans;
struct edge {
    int to, next;
} a[N];
inline void addedge(int u,int v) {
    a[++cnt]=(edge){v,head[u]};
    head[u]=cnt;
}
inline int merge(int x,int y) {
    if (!x || !y) return x+y;
    if (C[x]<C[y]) swap(x, y);
    rs[x]=merge(rs[x],y);
    if (dis[ls[x]]<dis[rs[x]]) swap(ls[x],rs[x]);
    dis[x]=dis[rs[x]]+1;
    return x;
}
inline int Delete(int x) {
    return merge(ls[x],rs[x]);
}
inline int dfs(int u) {
    int x=u, y;
    sum[u]=C[u];
    sz[u]=1;
    for (int e=head[u]; e; e=a[e].next) {
        int v=a[e].to;
        y=dfs(v);
        x=merge(x,y);
        sum[u]+=sum[v];
        sz[u]+=sz[v];
    }
    while (sum[u]>m) {
        sum[u]-=C[x];
        sz[u]--;
        x=Delete(x);
    }
    ans=max(ans,L[u]*sz[u]);
    return x;
}
int  main() {
    scanf("%d%lld",&n, &m);
    for (int i=1; i<=n; i++) {
        int u;
        scanf("%d",&u);
        if (!u) now=i; else addedge(u,i);
        scanf("%lld%lld",&C[i], &L[i]);
    }
    dfs(now);
    printf("%lld\n",ans);
    return 0;
}