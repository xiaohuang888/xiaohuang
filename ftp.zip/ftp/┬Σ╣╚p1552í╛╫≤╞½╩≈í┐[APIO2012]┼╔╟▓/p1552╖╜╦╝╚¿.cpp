//by ��˼Ȩ
#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
struct record {
    int u,v;
} edge[maxn<<1];
long long m,sum[maxn],ans,c[maxn];
int n,lead[maxn],f[maxn],size[maxn],r[maxn<<2],l[maxn<<2],dis[maxn<<2],head[maxn],cnt,x;
inline void Edgeadd(int x,int y) {
    edge[++cnt].u=head[x];
    edge[cnt].v=y;
    head[x]=cnt;
}
inline int merge(int x,int y) {
    if (x==0||y==0)
        return x+y;
    if (c[x]<c[y]||(c[x]==c[y]&&x<y))
        swap(x,y);
    r[x]=merge(r[x],y);
    if (dis[l[x]]<dis[r[x]])
        swap(l[x],r[x]);
    dis[x]=dis[r[x]]+1;
    return x;
}
inline void dfs(int u) {
    sum[u]=c[u];
    size[u]=1;
    f[u]=u;
    for (int i=head[u]; ~i; i=edge[i].u) {
        int v=edge[i].v;
        dfs(v);
        sum[u]+=sum[v];
        size[u]+=size[v];
        f[u]=merge(f[u],f[v]);
    }
    while (sum[u]>m&&size[u]>0) {
        sum[u]-=c[f[u]];
        f[u]=merge(l[f[u]],r[f[u]]);
        size[u]--;
    }
    ans=max(ans,(long long)lead[u]*size[u]);
}
int main() {
    scanf("%d%lld",&n,&m);
    dis[0]=-1;
    for (int i=0; i<=n; i++)
        head[i]=-1;
    for (int i=1; i<=n; i++) {
        scanf("%d%lld%d",&x,&c[i],&lead[i]);
        Edgeadd(x,i);
    }
    dfs(1);
    printf("%lld\n",ans);
    return 0;
}

