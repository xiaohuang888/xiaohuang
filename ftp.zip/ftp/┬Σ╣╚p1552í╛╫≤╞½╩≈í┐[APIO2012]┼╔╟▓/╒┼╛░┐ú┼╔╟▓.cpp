#include <iostream>
#include <cstdio>
#define Rint register int
#define Temp template<typename T>
using namespace std;
typedef long long ll;
Temp inline void read(T &x) {
	x=0;T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
const int maxn=1e5+10;
struct Edge{
	int nxt,to;
}e[maxn<<1];
ll m,sum[maxn],ans=0,v[maxn];
int n,lead[maxn],f[maxn],b[maxn],siz[maxn],r[maxn<<2],l[maxn<<2],dis[maxn<<2];
int head[maxn],cnt=0;
inline void addedge(int x,int y) {
	cnt++;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
inline int merge(int x,int y) {
	if((x==0)||(y==0)) return x+y;
	if((v[x]<v[y])||((v[x]==v[y])&&(x<y))) swap(x,y);
	r[x]=merge(r[x],y);
	f[r[x]]=x;
	if((dis[l[x]])<(dis[r[x]])) swap(l[x],r[x]);
	dis[x]=dis[r[x]]+1;
	return x;
}
inline void pop(int x) {
	v[x]=-1;
	f[l[x]]=f[r[x]]=0;
	merge(l[x],r[x]);
}
inline void dfs(int u) {
	b[u]=u;siz[u]=1;sum[u]=v[u];
	for (Rint i=head[u];~i;i=e[i].nxt) {
		int v=e[i].to;
		dfs(v);
		siz[u]+=siz[v];
		sum[u]+=sum[v];
		b[u]=merge(b[u],b[v]);
	}
	while((sum[u]>m)&&(siz[u]>0)) {
		sum[u]-=v[b[u]];
		b[u]=merge(l[b[u]],r[b[u]]);
		siz[u]--;
	}
	ans=max(ans,(ll)lead[u]*siz[u]);
}
int main() {
	read(n);read(m);
	dis[0]=-1;
	for (int i=0;i<=n;++i) head[i]=-1;
	for (int i=1;i<=n;++i) {
		int k;
		read(k);addedge(k,i);
		read(v[i]);read(lead[i]);
	}
	dfs(1);
	printf("%lld\n",ans);
	return 0;
}
