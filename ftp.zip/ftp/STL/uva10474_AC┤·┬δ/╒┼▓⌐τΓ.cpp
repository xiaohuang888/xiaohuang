#include<bits/stdc++.h>
using namespace std;
int a[10001],m,n,x,j=1;
int main()
{
	while(1)
	{
		
	cin>>n>>m;
	if(n==0&&m==0) return 0;
		for(int i=1;i<=n;i++)
		cin>>a[i];
		sort(a+1,a+1+n);
		cout<<"CASE# "<<j<<":"<<endl;
		while(m--)
		{
			cin>>x;
			int p = lower_bound(a, a+n, x) - a; 
			if(a[p] == x) cout<<x<<" found at "<<p<<endl;
			else cout<<x<<" not found"<<endl;
		}
		
		j++;
	}
	return 0;
}
