#include<cstdio>
#include<algorithm>
#include<cstring>
int cas,n,m,x,a[10005],flag[10005];
using namespace std;
int read();
int main()
{
    while (1)
    {
        n=read(),m=read();
        if (n==0&&m==0) break;
        printf("CASE# %d:\n",++cas);
        for (int i=1;i<=n;i++) a[i]=read();
        sort(a+1,a+n+1);
        for (int i=1;i<=n;i++) if (!flag[a[i]]) flag[a[i]]=i;
        for (int i=1;i<=m;i++)
        {
            x=read();
            if (flag[x]) printf("%d found at %d\n",x,flag[x]); else printf("%d not found\n",x);
        }
        memset(flag,0,sizeof(flag));
    }
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
