#include<bits/stdc++.h>
using namespace std;
int n,m,a[100001],t; 
int main()
{
    while(cin>>n>>m)
	{
        if(!(n+m))return 0;
        t++;
        printf("CASE# %d:\n",t);
        for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
        sort(a+1,a+n+1);
        int p;
        a[0]=-1e9;
        for(int j=1;j<=m;j++)
		{
            cin>>p;
            if(a[n]<p)
			{
                cout<<p<<" not found"<<endl;
                continue;
            }
            for(int k=1;k<=n;k++)
			{
                if(a[k]==p)
				{
                    cout<<p<<" found at "<<k<<endl;
                    break;
                }
                if(a[k]>p)
				{
                    cout<<p<<" not found"<<endl;
                    break;
                }
            } 
        }
    }
}

