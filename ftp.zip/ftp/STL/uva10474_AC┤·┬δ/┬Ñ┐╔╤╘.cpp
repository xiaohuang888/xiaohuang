#include<cstdio>
#include<set>
using namespace std;
int main(){
	set<int>s;
	int n,q,t=0;
	while(1){
		scanf("%d%d",&n,&q);
		if(!n&&!q)return 0;
		printf("CASE# %d:\n",++t);
		while(n--){
			int x;
			scanf("%d",&x);
			s.insert(x);
		}
		while(q--){
			int x;
			scanf("%d",&x);
			if(!s.count(x))printf("%d not found\n",x);
			else printf("%d found at %d\n",x,*(s.find(x)));
		}
	}
}
