#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	int i,j,k=1,l,m,n,a[100001],ans=0;
	while(cin>>n>>m)
	{
		if(n+m==0)
		return 0;
		cout<<"CASE# "<<k<<":"<<endl;
		k++;
		for(i=1;i<=n;i++)
		cin>>a[i];
		sort(a+1,a+1+n);
		for(j=1;j<=m;j++)
		{
			cin>>l;
			if(a[n]<l||l<a[1])
			{
				cout<<l<<" not found"<<endl;
				continue;
			}
			for(i=1;i<=n;i++)
			{
				if(a[i]==l)
				{
				cout<<l<<" found at "<<i<<endl;
				break;
				}
				if(a[i]>l)
				{
					cout<<l<<" not found"<<endl;
					break;
				}				
			}
		}
	}
}
