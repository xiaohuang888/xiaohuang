#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,i,a[10001],q,num=1,qq;
	while(true)
	{
		cin>>n>>q;
		if(n==q&&q==0)exit(0);
		for(i=1;i<=n;i++)
		cin>>a[i];
		cout<<"CASE# "<<num<<':'<<endl;
		sort(a+1,a+n+1);
		for(i=1;i<=q;i++)
		{
			cin>>qq;
			int f=lower_bound(a+1,a+n+1,qq)-a;
			if(a[f]==qq)
			cout<<qq<<" found at "<<f<<endl;
			else
			cout<<qq<<" not found"<<endl;
		}
		num++;
	}
}
