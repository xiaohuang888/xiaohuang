#include<cstdio>
#include<algorithm>
using namespace std;
int a[10010];
int i,n,m,j,mid,cnt;
int main(){
	scanf("%d%d",&n,&m);
	while (n!=0){
		cnt++;
		printf("CASE# %d:\n",cnt);
		for (i=0;i<n;i++) scanf("%d",&a[i]);
		sort(a,a+n);
		for (i=0;i<m;i++){
			scanf("%d",&j);
			for (mid=0;mid<n;mid++)
			     if(j==a[mid]){
			     	printf("%d found at %d\n",j,mid+1);
			     	break;
				 }
			if (j!=a[mid]) printf("%d not found\n",j);
		}
		scanf("%d%d",&n,&m);
	}
}
