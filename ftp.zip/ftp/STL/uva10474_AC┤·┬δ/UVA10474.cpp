#include<cstdio>
#include<algorithm>
using namespace std;
int main() {
	int n,q;
	bool flag=0;
	int a[10005],b[10005],sum=0;
	while(scanf("%d %d",&n,&q)) {
		if(n==0||q==0) return 0;
		for(int i=1; i<=n; i++) {
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		for(int i=1; i<=q; i++) {
			scanf("%d",&b[i]);
		}
		printf("CASE# ");
		printf("%d",++sum);
		printf(":\n");
		for(int i=1; i<=q; i++) {
			for(int j=1; j<=n; j++) {
				if(a[j]==b[i]) {
					printf("%d ",b[i]);
					printf("found at ");
					printf("%d\n",j);
					flag=1;
					break;
				}
			}
			if(flag==0) {
				printf("%d ",b[i]);
				printf("not found\n");
			}
			flag=0;
		}
	}
	return 0;
}
