#include<iostream>
#include<algorithm>
using namespace std;
int a[10010];
int main()
{
	int n,q,i,js=0;
	while(1)
	{
		js++;
		cin>>n>>q;
		if(n==0&&q==0)break;
		cout<<"CASE# "<<js<<":\n";
		for(i=1;i<=n;i++)cin>>a[i];
		sort(a+1,a+n+1);
		for(i=1;i<=q;i++)
		{
			int l=1,r=n,mid=(l+r)/2,x;bool f=0;
			cin>>x;
			while(l<=r)
			{
				mid=(l+r)/2;
				if(a[mid]==x)
				{
					f=1;
					break;
				}
				if(a[mid]>x)r=mid-1;
				else l=mid+1;
			}
			if(f)
			{
				while(a[mid]==x)mid--;
				cout<<x<<" found at "<<mid+1<<endl;
			}
			else cout<<x<<" not found\n";
		}

	}
}
