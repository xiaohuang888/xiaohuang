#include<cstdio>
#include<algorithm>
using namespace std;
#define maxn 10001
int main()
{
	int n,q,ques,casenum,ans;
	int a[maxn];
	while(scanf("%d%d",&n,&q)==2&&n)
	{
		printf("CASE# %d:\n",++casenum);
		for(register int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		while(q--)
		{
			scanf("%d",&ques);
			ans=lower_bound(a+1,a+n+1,ques)-a;
			if(a[ans]==ques)
				printf("%d found at %d\n",ques,ans);
			else
				printf("%d not found\n",ques);
		}
	}
	return 0;
}
