#include <cstdio>
#include <algorithm>
int n, q, c, x, y;
int a[1000005];
// #Files UnsignedIntFastRead.cpp
/*
    By keywet06
    Use include:
        cstdio (stdio.h)
    Use function:
        NULL
*/
inline unsigned int UnsignedIntFastRead()
{
    unsigned int UnsignedIntFastRead_x, UnsignedIntFastRead_y;
    UnsignedIntFastRead_y = getchar();
    while (UnsignedIntFastRead_y < '0' || '9' < UnsignedIntFastRead_y)
    {
        UnsignedIntFastRead_y = getchar();
    }
    UnsignedIntFastRead_x = UnsignedIntFastRead_y - '0';
    UnsignedIntFastRead_y = getchar();
    while ('0' <= UnsignedIntFastRead_y && UnsignedIntFastRead_y <= '9')
    {
        UnsignedIntFastRead_x = UnsignedIntFastRead_x * 10 + UnsignedIntFastRead_y - '0';
        UnsignedIntFastRead_y = getchar();
    }
    return UnsignedIntFastRead_x;
}
// #Files end
int main()
{
	while (1)
	{
		n = UnsignedIntFastRead();
		q = UnsignedIntFastRead();
		if (!(n + q))
		{
			return 0;
		}
		printf("CASE# %d:\n", ++c);
		for (int i = 0; i < n; ++i)
		{
			a[i] = UnsignedIntFastRead();
		}
		std::sort(a, a + n);
		for (int i = 0; i < q; ++i)
		{
			x = UnsignedIntFastRead();
			y = std::lower_bound(a, a + n, x) - a;
			if (x == a[y])
			{
				printf("%d found at %d\n", x, y + 1);
			}
			else
			{
				printf("%d not found\n", x);
			}
		}
	}
}
