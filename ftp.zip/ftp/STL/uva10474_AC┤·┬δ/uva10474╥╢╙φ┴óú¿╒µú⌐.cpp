#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a[100000],n,m,k,sum,x,l=1;
	while(scanf("%d%d",&n,&m)==2&&n)
	{
		printf("CASE# %d:\n",l);
		for(k=0;k<n;k++)
		scanf("%d",&a[k]);
		sort(a,a+n);
		for(k=0;k<m;k++)
		{
			scanf("%d",&x);
			sum=lower_bound(a,a+n,x)-a;
			if(a[sum]==x)
			printf("%d found at %d\n",x,sum+1);
			else
			printf("%d not found\n",x);
		}
		l++;
	}
}
