#include<iostream>
#include<algorithm>
using namespace std;
int cnt;
int main(){
	while(1){
		int n,q;
		int a[10010];
	    cin>>n>>q;
	    if(n==0&&q==0)
	        return 0;
	    cnt++;
	    cout<<"CASE# "<<cnt<<":"<<endl;
	    for(int i=1;i<=n;i++){
	    	cin>>a[i];
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=q;i++){
			int k;
			cin>>k;
			int key=lower_bound(a+1,a+n+1,k)-a;
			if (a[key]==k){
				cout<<k<<" found at "<<key<<endl;
			}else
			{
				cout<<k<<" not found"<<endl;
			}
		}
    }
}
