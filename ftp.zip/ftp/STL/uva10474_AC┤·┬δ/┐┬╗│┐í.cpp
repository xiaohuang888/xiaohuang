#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[10010],n,q,x,t=0;
int cha(int l,int r)
{
	while(l<r)
	{
		int mid=(l+r)/2;
		if(a[mid]<x)l=mid+1;
		else r=mid;
	}
	return l;
}
int main()
{
	scanf("%d%d",&n,&q);
	while(n!=0&&q!=0)
	{
		t++;
		printf("CASE# %d:\n",t);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		for(int i=0;i<q;i++)
		{
			scanf("%d",&x);
			int b=cha(1,n);
			if(a[b]==x)
			printf("%d found at %d\n",x,b);
			else
			printf("%d not found\n",x);
		}
		scanf("%d%d",&n,&q);
	}
}
