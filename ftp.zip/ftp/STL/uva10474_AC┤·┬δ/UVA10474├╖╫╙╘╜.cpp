#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,q,i,num=0,a[10001]={0},l,r,mid,x;
	bool mzy,mao=true;
	while(mao)
	{
		num++;
		cin>>n>>q;
		if(n==0&&q==0)return 0;
		cout<<"CASE# "<<num<<":"<<endl;
		for(i=1;i<=n;i++)
		cin>>a[i];
		sort(a+1,a+n+1);
		for(i=1;i<=q;i++)
		{
			l=1;
			r=n;
			mid=(l+r)/2;
			mzy=false;
			cin>>x;
			while(l<=r)
			{
				mid=(l+r)/2;
				if(a[mid]==x)
				{
					mzy=true;
					break;
				}
				if(a[mid]>x)
				r=mid-1;
				else l=mid+1;
			}
			if(mzy)
			{
				while(a[mid]==x)
				mid--;
				cout<<x<<" found at "<<mid+1<<endl;
			}
			else cout<<x<<" not found"<<endl;
		}
	}
	return 0;
}
