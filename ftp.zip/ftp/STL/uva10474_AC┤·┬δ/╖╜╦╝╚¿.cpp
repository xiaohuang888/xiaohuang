#include<bits/stdc++.h>
using namespace std;
int n,m,x,i,a[10009],cnt;
int main() {
#define fsq;
	while (1) {
		cout<<"CASE# "<<++cnt<<":"<<endl;
		scanf("%d%d",&n,&m);
		if (n==0&&m==0)
			return 0;
		for (int i=1; i<=n; i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		while (m--) {
			scanf("%d",&x);
			for (int i=1; i<=n; i++) {
				if (a[i]==x) {
					cout<<a[i]<<" found at "<<i<<endl;
					break;
				}
				if (a[i]>x) {
					cout<<x<<" not found"<<endl;
					break;
				}
			}
		}
	}
	return 0;
}
