#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>

using namespace std;

int n, Q, a[10005];
bool cmp(int a, int b) {
    return a<b;
}
int main() {
    int cas=0;
    scanf("%d%d",&n, &Q);
    while (n!=0 && Q!=0) {
        printf("CASE# %d:\n",++cas);
        for (int i=1; i<=n; i++)
            scanf("%d",&a[i]);
        sort(a+1,a+n+1,cmp);
        for (int i=1; i<=Q; i++) {
            int x;
            scanf("%d",&x);
            int s=lower_bound(a+1,a+n+1,x)-a;
            if (a[s]==x) printf("%d found at %d\n",x, s); else
            if (a[s]!=x) printf("%d not found\n",x);
        }
        scanf("%d%d",&n, &Q);
    }
    return 0;
}