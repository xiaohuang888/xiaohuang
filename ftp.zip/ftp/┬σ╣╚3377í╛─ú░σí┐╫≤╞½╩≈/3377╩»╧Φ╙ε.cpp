#include<cstdio>
const int maxn=100010;
int n,m,i,j,x,y,k;
int val[maxn],L[maxn],R[maxn],f[maxn],dis[maxn];
void swap(int &x,int &y){
	int t=x;
	x=y;
	y=t;
}
int merge(int x,int y)
{
	if (x==0||y==0)
	 return x+y;
	if (val[x]>val[y]||(val[x]==val[y] && x>y))
	 swap(x,y);
	R[x]=merge(R[x],y);
	f[R[x]]=x;
	if (dis[L[x]]<dis[R[x]])
	 swap(L[x],R[x]);
	dis[x]=dis[R[x]]+1;
	return x;
}
int find(int x)
{
	while (f[x]) x=f[x];
	return x;
}
void pop(int x)
{
	val[x]=-1;
	f[L[x]]=f[R[x]]=0;
	merge(L[x],R[x]);
}
int main(){
	scanf("%d%d",&n,&m);
	for (i=1;i<=n;i++){
		scanf("%d",&val[i]);
	}
	for (i=1;i<=m;i++){
		scanf("%d%d",&k,&x);
		if (k==1){
			scanf("%d",&y);
			if (val[x]==-1||val[y]==-1)
			 continue;
			if (x==y)
			 continue;
			int fx=find(x),fy=find(y);
			merge(fx,fy);
		}
		else
		{
			if (val[x]==-1)
			 printf("%d\n",-1);
			else
			{
				int fx=find(x);
				printf("%d\n",val[fx]);
				pop(fx);
			}
		}
	}
	return 0;
}