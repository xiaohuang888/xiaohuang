#include <algorithm>
#include <cstdio>
#include <map>
using namespace std;
template <class T> struct leftist_tree {
    T key;
    int dis;
    leftist_tree * l,* r,* p;
    leftist_tree() {
        l=NULL,r=NULL,p=NULL;
        dis = 0;
    }
    leftist_tree(T _key) {
        l=NULL,r=NULL,p=NULL;
        dis = 0;
        key = _key;
    }
};
template <class T> struct leftist_tree_functions {
    leftist_tree<T> * merge(leftist_tree<T> * x,leftist_tree<T> * y) {
        if(!x)
            return y;
        if(!y)
            return x;
        if(x->key > y->key)
            swap(x,y);
        y->p = x;
        x->r = merge(x->r,y);
        if(! x->r)
            return x;
        if(! x->l){
            swap(x->l,x->r);
            return x;
        }
        if(x->r->dis > x->l->dis)
            swap(x->l,x->r);
        x->dis = x->r->dis + 1;
        return x;
    }
};
struct note{
    int key,pos;
    friend bool operator >(note x,note y){
        if(x.key == y.key)
            return x.pos > y.pos;
        return x.key > y.key;
    }
};
leftist_tree_functions <note> func;
leftist_tree <note> hp[100001];
map <int,bool> vis;
int main() {
    int n,i,m,op,x,y;
    leftist_tree<note> * _x,* _y;
    scanf("%d%d",& n,& m);
    for(i = 1; i <= n; i ++){
        scanf("%d",& hp[i].key.key);
        hp[i].key.pos = i;
    }
    for(i = 1; i <= n; i ++)
        vis[int(&hp[i]-hp)] = 1;
    for(i = 1; i <= m; i ++) {
        scanf("%d",& op);
        if(op == 1) {
            scanf("%d%d",& x,& y);
            _x = & hp[x];
            while(_x->p)
                _x = _x->p;
            _y = & hp[y];
            while(_y->p)
                _y = _y->p;
            if(!vis[int(_x-hp)] || !vis[int(_y-hp)])
                continue;
            if(_x == _y)
                continue;
            func.merge(_x,_y);
        } else {
            scanf("%d",& x);
            _x = & hp[x];
            if(!vis[int(_x-hp)]) {
                puts("-1");
                continue;
            }
            while(_x->p)
                _x = _x->p;
            printf("%d\n",_x->key.key);
            vis[int(_x-hp)]=0;
            if(_x->l)
                _x->l->p = NULL;
            if(_x->r)
                _x->r->p = NULL;
            func.merge(_x->l,_x->r);
        }
    }
    return 0;
}
