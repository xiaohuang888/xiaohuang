//by ��˼Ȩ 
#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+9;
int f[MAXN],a[MAXN],l[MAXN],r[MAXN],dis[MAXN],n,m,k,x,y,fx,fy;
int merge(int x,int y) {
	if (x==0||y==0)
		return x+y;
	if (a[x]>a[y]||(a[x]==a[y]&&x>y))
		swap(x,y);
	r[x]=merge(r[x],y);
	f[r[x]]=x;
	if (dis[l[x]]<dis[r[x]])
		swap(l[x],r[x]);
	dis[x]=dis[r[x]];
	return x;
}
int find(int x) {
	while (f[x]) x=f[x];
	return x;
}
void add(int x) {
	a[x]=-1;
	f[l[x]]=f[r[x]]=0;
	merge(l[x],r[x]);
}
int main() {
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++)
		scanf("%d",&a[i]);
	dis[0]=-1;
	for (int i=0; i<m; i++) {
		scanf("%d",&k);
		if (k==1) {
			scanf("%d%d",&x,&y);
			if (a[x]!=-1&&a[y]!=-1) {
				fx=find(x);
				fy=find(y);
				if (fx!=fy)
					merge(fx,fy);
			}
		} else {
			scanf("%d",&x);
			if (a[x]==-1)
				printf("%d\n",a[x]);
			else {
				fx=find(x);
				printf("%d\n",a[fx]);
				add(fx);
			}
		}
	}
	return 0;
}
