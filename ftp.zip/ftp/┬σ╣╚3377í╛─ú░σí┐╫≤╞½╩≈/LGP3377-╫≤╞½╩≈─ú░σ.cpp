#include <iostream>
#include <cstdio>
#define Rint register int
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&ch!='-') ch=getchar();
    if(ch=='-') w=-1,ch=getchar();
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w;
}
const int maxn=1e5+10;
int dist[maxn],father[maxn],r[maxn],l[maxn],n,m,v[maxn];
int merge(int x,int y) {
    if(x==0||y==0) return x+y;
    if((v[x]>v[y])||((v[x]==v[y])&&(x>y))) swap(x,y);
    r[x]=merge(r[x],y);
    father[r[x]]=x;
    if(dist[l[x]]<dist[r[x]]) swap(l[x],r[x]);
    dist[x]=dist[r[x]]+1;
    return x;
}
int getf(int x) {
    while(father[x]) x=father[x];
    return x;
}
void pop(int x) {
    v[x]=-1;
    father[l[x]]=0;
	father[r[x]]=0;
    merge(l[x],r[x]);
}
int main() {
    read(n);read(m);
    dist[0]=-1;
    for (Rint i=1;i<=n;++i) read(v[i]);
    for (Rint i=1;i<=m;++i) {
        int x,y,k;
        read(k);
        if(k==1) {
            read(x);read(y);
            if(v[x]==-1||v[y]==-1) continue;
            if(x==y) continue;
            int fx=getf(x),fy=getf(y);
            merge(fx,fy);
        }
        else {
            read(x);
            if(v[x]==-1) puts("-1");
            else {
                y=getf(x);
                printf("%d\n",v[y]);
                pop(y);
            }
        }
    }
    return 0;
}
