#include<cstdio>
#include<algorithm>
#define N 100005
using namespace std;
struct tree{
	int left,right;
}tree[N];
int f[N],w[N],dis[N],n,m;
int read(){
	int x=0;
	char ch=getchar();
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch&15);
		ch=getchar();
	}
	return x;
}
int find(int x){
	for (;f[x];x=f[x]);
	return x;
}
int merge(int u,int v){
	if (u==0||v==0) return u+v;
	if (w[u]>w[v]||(w[u]==w[v])&&(u>v)) swap(u,v);
	tree[u].right=merge(tree[u].right,v);
	f[tree[u].right]=u;
	if (dis[tree[u].left]<dis[tree[u].right]) swap(tree[u].left,tree[u].right);
	dis[u]=dis[tree[u].right]+1;
	return u;
}
void pop(int u){
	w[u]=-1;
	f[tree[u].left]=f[tree[u].right]=0;
	merge(tree[u].left,tree[u].right);
}
int main(){
	n=read();m=read();
	dis[0]=-1;
	for (int i=1;i<=n;i++) w[i]=read();
	for (int i=1;i<=m;i++){
		int opt=read();
		if (opt==1){
			int u=read(),v=read();
			if (!~w[u]||!~w[v]) continue;
			int x=find(u),y=find(v);
			if (x!=y) merge(x,y);
		}else{
			int u=read();
			if (!~w[u]) printf("-1\n");else{
				int x=find(u);
				printf("%d\n",w[x]);
				pop(x);
			}
			
		}
	}
	return 0;
}