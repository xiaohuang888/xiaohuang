#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define MAXN 100005

using namespace std;

int n, m, val[MAXN], dis[MAXN], f[MAXN], ch[MAXN][2];
inline int merge(int x, int y) {
    if (!x || !y) return x+y;
    if (val[x]>val[y] || (val[x]==val[y] && x>y)) swap(x, y);
    ch[x][1]=merge(ch[x][1], y);
    f[ch[x][1]]=x;
    if (dis[ch[x][0]]<dis[ch[x][1]]) swap(ch[x][0], ch[x][1]);
    dis[x]=dis[ch[x][1]]+1;
    return x;
}
inline int getfather(int x) {
    while (f[x]) x=f[x];
    return x;
}
inline void pop(int x) {
    val[x]=-1;
    f[ch[x][0]]=0;
    f[ch[x][1]]=0;
    merge(ch[x][0],ch[x][1]);
}
int main() {
    scanf("%d%d",&n, &m);
    dis[0]=-1;
    for (int i=1; i<=n; i++)
        scanf("%d",&val[i]);
    for (int i=1; i<=m; i++) {
        int com;
        scanf("%d",&com);
        if (com==1) {
            int x, y;
            scanf("%d%d",&x, &y);
            if (val[x]==-1 || val[y]==-1) continue;
            if (x==y) continue;
            int fatherx=getfather(x), fathery=getfather(y);
            merge(fatherx, fathery);
        }
        else {
            int x;
            scanf("%d",&x);
            if (val[x]==-1) printf("-1\n"); else {
                int y=getfather(x);
                printf("%d\n",val[y]);
                pop(y);
            }
        }
    }
    return 0;
}