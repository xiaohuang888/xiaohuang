#include<cstdio>
const int N=100000;
int ch[N][2],val[N],dis[N],f[N],n,m;
inline void swap(int&a,int&b){
	register int c=a;
	a=b;
	b=c;
}
inline int read(){
	register int x=0;
	register char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=x*10+c-48,c=getchar();
	return x;
}
inline int merge(int x,int y)
{
    if (x==0 || y==0)
        return x+y;
    if (val[x]>val[y] || (val[x]==val[y] && x>y))
        swap(x,y);
    ch[x][1]=merge(ch[x][1],y);
    f[ch[x][1]]=x;
    if (dis[ch[x][0]]<dis[ch[x][1]])
        swap(ch[x][0],ch[x][1]);
    dis[x]=dis[ch[x][1]]+1;
    return x;
}
inline int getf(int x)
{
    while(f[x]) x=f[x];
    return x;
}
inline void pop(int x)
{
    val[x]=-1;
    f[ch[x][0]]=f[ch[x][1]]=0;
    merge(ch[x][0],ch[x][1]);
}
inline void print(int x){
	if(!x)return;
	print(x/10);
	putchar(x%10+'0');
}
inline void write(int x){
	if(!x){
		putchar('0');
		return;
	}
	if(x<0){
		putchar('-');
	}
	print(x);
	putchar('\n');
}
int main()
{
    n=read(),m=read();
    dis[0]=-1;
    for (int i=1;i<=n;i++)
        val[i]=read();
    for (int i=1;i<=m;i++)
    {
        int com=read();
        if (com==1)
        {
            int x=read(),y=read();
            if (val[x]==-1 || val[y]==-1)
                continue;
            if (x==y)
                continue;
            int fx=getf(x),fy=getf(y);
            merge(fx,fy);
        }
        else
        {
            int x=read();
            if (val[x]==-1)
                putchar('-'),putchar('1'),putchar('\n');
            else
            {
                int y=getf(x);
                write(val[y]);
                pop(y);
            }
        }
    }
}
