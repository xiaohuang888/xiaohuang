//1'am fsq
#include<bits/stdc++.h>
#define Fsqint register int
#define Temp template<typename T>
using namespace std;
const int MAXN=200005;
struct A {
	int u,v;
} edge[MAXN<<1];
struct B {
	int u,v;
} Edge[MAXN<<1];
int l[MAXN],r[MAXN],c[MAXN],f[MAXN],head[MAXN<<1],h[MAXN<<1],n,Maxid,Max,cnt;
bool vis[MAXN];
Temp inline void read(T &x) {
	x=0;
	T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
inline void add(int x,int y) {
	edge[cnt].u=h[x];
	edge[cnt].v=y;
	h[x]=cnt++;
}
inline void EdgeAdd(int x,int y) {
	Edge[cnt].u=head[x];
	Edge[cnt].v=y;
	head[x]=cnt++;
}
inline int find(int x) {
	if (x!=f[x])
		f[x]=find(f[x]);
	return f[x];
}
inline void Add(int x,int y) {
	int x1=find(x);
	int y1=find(y);
	if (f[x1]!=f[y1])
		f[x1]=f[y1];
}
inline dfs(int u,int father) {
	for (Fsqint i=h[u]; i!=-1; i=edge[i].u) {
		int v=edge[i].v;
		if(! vis[v] && v!=father && c[v]==c[u]) {
			Add(v,u);
			vis[v]=1;
			dfs(v,u);
		}
	}
}
inline Dfs(int Dep,int u,int father) {
	if (Dep>Max) {
		Max=Dep;
		Maxid=u;
	}
	for (Fsqint i=head[u]; i!=-1; i=Edge[i].u) {
		int v=Edge[i].v;
		if (v!=father)
			Dfs(Dep+1,v,u);
	}
}
int main() {
	memset(h,-1,sizeof(h));
	memset(head,-1,sizeof(head));
	read(n);
	for (Fsqint i=1; i<=n; i++) {
		read(c[i]);
		f[i]=i;
	}
	for (Fsqint i=1; i<n; i++) {
		read(l[i]);
		read(r[i]);
		add(l[i],r[i]);
		add(r[i],l[i]);
	}
	for(Fsqint i=1; i<=n; i++)
		if (! vis[i])
			dfs(i,0);
	cnt=0;
	for (Fsqint i=1; i<n; i++)
		if (f[l[i]]!=f[r[i]]) {
			EdgeAdd(f[l[i]],f[r[i]]);
			EdgeAdd(f[r[i]],f[l[i]]);
		}
	Dfs(0,1,0);
	Dfs(0,Maxid,0);
	printf("%d",(Max+1)>>1);
	return 0;
}
