#include<cstdio>
#include<algorithm>
int a[100001],l[100001],r[100001],d[100001],f[100001];
bool died[100001];
bool cmp(int x,int y)
{
	if(a[x]==a[y]) return x>y;
	return a[x]>a[y];
}
void swap(int &x,int &y)
{
	std::swap(x,y);
}
int merge(int x,int y)
{
	if(x==0||y==0) return x|y;
	if(cmp(x,y)) swap(x,y);
	r[x]=merge(r[x],y);
	f[r[x]]=x;
	if(d[r[x]]>d[l[x]]) swap(l[x],r[x]);
	d[x]=d[r[x]]+1;
	return x;
}
int find(int x)
{
    while(f[x])
	{
		x=f[x];
	}
    return x;
}
void die(int rt)
{
	died[rt]=1;
	f[rt]=0;
	f[l[rt]]=0;
	f[r[rt]]=0;
	d[rt]=0;
}
int main()
{
	d[0]=-1;
	int n,m;
	scanf("%d%d",&n,&m);
	int i;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	int k,x,y;
	for(i=1;i<=m;i++)
	{
		scanf("%d",&k);
		if(k==1)
		{
			scanf("%d%d",&x,&y);
			if(died[x]||died[y]) continue;
			x=find(x);
			y=find(y);
			if(x==y) continue;
			merge(x,y);
		}
		else
		{
			scanf("%d",&x);
			if(died[x])
			{
				printf("-1\n");
				continue;
			}
			x=find(x);
			printf("%d\n",a[x]);
			die(x);
			merge(l[x],r[x]);
		}
	}
	return 0;
}

