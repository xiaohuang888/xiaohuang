// luogu-judger-enable-o2
// hello I'am fsq
#include<bits/stdc++.h>
#define fsq register
#define Temp template<typename T>
using namespace std;
const int maxn=1e5+5;
int n,m;
long long block,val[maxn],mul[maxn],add[maxn],z,ans,p,a[maxn];
int belong[maxn],l[maxn],r[maxn],opt,x,y;
inline void reset(int x) {
	for(fsq int i=l[x]; i<=r[x]; i++)
		a[i]=(a[i]*mul[x]+add[x])%p;
	mul[x]=1,add[x]=0;
}
Temp inline void read(T &x) {
	x=0;
	T w=1,ch=getchar();
	while(!isdigit(ch)&&ch!='-') ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
	x*=w;
}
int main() {
	read(n);
	read(m);
	read(p);
	block=sqrt(n);
	for(fsq int i=1; i<=n; i++)
		belong[i]=i/block;
	for(fsq int i=n; i>=1; i--)
		l[belong[i]]=i;
	for(fsq int i=1; i<=n; i++)
		r[belong[i]]=i;
	for(fsq int i=1; i<=n; i++) {
		scanf("%lld",&a[i]);
		val[belong[i]]+=a[i];
	}
	for (fsq int i=belong[1]; i<=belong[n]; i++)
		mul[i]=1;
	while (m--) {
		read(opt);
		read(x);
		read(y);
		if (opt==1) {
			read(z);
			reset(belong[x]);
			for (fsq int i=x; i<=min(y,r[belong[x]]); i++)
				val[belong[x]]+=(z-1)*a[i]%p,a[i]=a[i]*z%p;
			if (belong[x]!=belong[y]) {
				reset(belong[y]);
				for (fsq int i=y; i>=l[belong[y]]; i--)
					val[belong[y]]+=(z-1)*a[i]%p,a[i]=a[i]*z%p;
			}
			for (fsq int i=belong[x]+1; i<=belong[y]-1; i++)
				mul[i]=mul[i]*z%p,add[i]=add[i]*z%p,val[i]=val[i]*z%p;
		} else if (opt==2) {
			read(z);
			reset(belong[x]);
			val[belong[x]]=(val[belong[x]]+(min(y,r[belong[x]])-x+1)*z)%p;
			for (fsq int i=x; i<=min(y,r[belong[x]]); i++)
				a[i]+=z;
			if (belong[x]!=belong[y]) {
				reset(belong[y]);
				val[belong[y]]=(val[belong[y]]+((y-l[belong[y]]+1)*z))%p;
				for(fsq int i=y; i>=l[belong[y]]; i--)
					a[i]+=z;
				for(fsq int i=belong[x]+1; i<=belong[y]-1; i++)
					add[i]+=z,val[i]=(val[i]+block*z)%p;
			}
		} else {
			ans=0;
			for(fsq int i=x; i<=min(y,r[belong[x]]); i++)
				ans+=(a[i]*mul[belong[x]]+add[belong[x]])%p;
			if(belong[x]!=belong[y]) {
				for(fsq int i=y; i>=l[belong[y]]; i--)
					ans+=(a[i]*mul[belong[y]]+add[belong[y]])%p;
				for(fsq int i=belong[x]+1; i<=belong[y]-1; i++)
					ans+=val[i],ans=ans%p;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
