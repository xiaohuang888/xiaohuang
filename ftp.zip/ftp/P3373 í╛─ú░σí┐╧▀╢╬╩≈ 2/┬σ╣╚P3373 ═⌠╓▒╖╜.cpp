#include <cstdio>
#include <cstring>
#include <algorithm>
#define _max_n 100000
using namespace std;
#define max_node ((max_n-1) << 2)
#define begin 1,1,n
int p;
template <typename T,int max_n,T *a = new(int[max_n+1])> struct segment_tree{
    T tree[max_node+1],add[max_node+1],times[max_node+1];
    inline segment_tree(){
        memset(tree,0,sizeof(tree));
        memset(add,0,sizeof(add));
        for(register int i = 0; i <= max_node; i ++)
            times[i] = 1;
    }
    inline void push_up(int now,int left_tree,int right_tree){
        tree[now] = (tree[left_tree] + tree[right_tree])%p;
    }
    inline void push_down(int now,int left_tree,int right_tree,int l,int mid,int r){
        add[left_tree] *= times[now];
        times[left_tree] *= times[now];
        add[right_tree] *= times[now];
        times[right_tree] *= times[now];
        add[left_tree] += add[now];
        add[right_tree] += add[now];
        tree[left_tree] = (tree[left_tree] * times[now] + add[now] * (mid-l+1))%p;
        tree[right_tree] = (tree[right_tree] * times[now] + add[now] * (r-mid))%p;
        add[left_tree] %= p;
        add[right_tree] %= p;
        times[left_tree] %= p;
        times[right_tree] %= p;
        add[now] = 0;
        times[now] = 1;
    }
    inline void build(int now,int l,int r){
        if(l == r){
            tree[now] = a[l]%p;
            return;
        }
        int mid = (l+r)>>1,left_tree=now<<1,right_tree=left_tree|1;
        build(left_tree,l,mid);
        build(right_tree,mid+1,r);
        push_up(now,left_tree,right_tree);
    }
    inline void update_key(int pos,int key,int now,int l,int r){
        if(l > pos || r < pos)
            return;
        if(l == r){
            tree[now] = a[l] = key%p;
            add[now] = 0;
            times[now] = 1;
            return;
        }
        int mid = (l+r)>>1,left_tree=now<<1,right_tree=left_tree|1;
        push_down(now,left_tree,right_tree,l,mid,r);
        update_key(pos,key,left_tree,l,mid);
        update_key(pos,key,right_tree,mid+1,r);
        push_up(now,left_tree,right_tree);
    }
    inline void update_plus(int left,int right,T plus,int now,int l,int r){
        if(l > right || r < left)
            return;
        if(l == r){
            tree[now] += plus;
            tree[now] %= p;
            a[l] = tree[now];
            add[now] = 0;
            times[now] = 1;
            return;
        }
        if(left <= l && r <= right){
            add[now] += plus;
            tree[now] += plus * (r-l+1);
            return;
        }
        int mid = (l+r)>>1,left_tree=now<<1,right_tree=left_tree|1;
        push_down(now,left_tree,right_tree,l,mid,r);
        update_plus(left,right,plus,left_tree,l,mid);
        update_plus(left,right,plus,right_tree,mid+1,r);
        push_up(now,left_tree,right_tree);
    }
    inline void update_times(int left,int right,T _times,int now,int l,int r){
        if(l > right || r < left)
            return;
        if(l == r){
            tree[now] *= _times;
            tree[now] %= p;
            a[l] = tree[now];
            add[now] = 0;
            times[now] = 1;
            return;
        }
        if(left <= l && r <= right){
            add[now] *= _times;
            times[now] *= _times;
            times[now] %= p;
            tree[now] *= _times%p;
            tree[now] %= p;
            return;
        }
        int mid = (l+r)>>1,left_tree=now<<1,right_tree=left_tree|1;
        push_down(now,left_tree,right_tree,l,mid,r);
        update_times(left,right,_times,left_tree,l,mid);
        update_times(left,right,_times,right_tree,mid+1,r);
        push_up(now,left_tree,right_tree);
    }
    inline T query(int left,int right,int now,int l,int r){
        if(l > right || r < left)
            return 0;
        if(left <= l && r <= right)
            return tree[now];
        int mid = (l+r)>>1,left_tree=now<<1,right_tree=left_tree|1;
        push_down(now,left_tree,right_tree,l,mid,r);
        T ret=query(left,right,left_tree,l,mid)+query(left,right,right_tree,mid+1,r);
        push_up(now,left_tree,right_tree);
        return ret%p;
    }
};
long long a[_max_n+1];
segment_tree <long long,_max_n,a> tr;
int main(){
    int n,k,i,op,x,y,z;
    scanf("%d%d%d",& n,& k,& p);
    for(i = 1; i <= n; i ++)
        scanf("%lld",a+i);
    tr.build(begin);
    for(i = 1; i <= k; i ++){
        scanf("%d",& op);
        switch(op){
            case 1:
                scanf("%d%d%d",& x,& y,& z);
                tr.update_times(x,y,z,begin);
                break;
            case 2:
                scanf("%d%d%d",& x,& y,& z);
                tr.update_plus(x,y,z,begin);
                break;
            default:
                scanf("%d%d",& x,& y);
                printf("%lld\n",tr.query(x,y,begin));
        }
    }
    return 0;
}
