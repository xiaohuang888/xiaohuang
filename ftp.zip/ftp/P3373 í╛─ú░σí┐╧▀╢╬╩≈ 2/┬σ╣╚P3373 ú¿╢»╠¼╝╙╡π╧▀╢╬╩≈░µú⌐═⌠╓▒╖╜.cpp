#include <cstdio>
#include <cstring>
#include <algorithm>
#define _max_n 100000
using namespace std;
#define max_node ((max_n-1) << 2)
template <typename T,int max_n,T *a = new(int[max_n+1])> struct segment_tree {
	T tree[max_node+1],add[max_node+1],times[max_node+1];
	int l[max_node+1],r[max_node+1];
	int cnt;
	inline segment_tree() {
		cnt=0;
		memset(tree,0,sizeof(tree));
		memset(add,0,sizeof(add));
		memset(l,0,sizeof(l));
		memset(r,0,sizeof(r));
		for(register int i = 0; i <= max_node; i ++)
			times[i] = 1;
	}
	inline void push_up(int now,int left_tree,int right_tree) {
		tree[now] = tree[left_tree] + tree[right_tree];
	}
	inline void push_down(int now,int left_tree,int right_tree,int l,int mid,int r) {
		add[left_tree] *= times[now];
		times[left_tree] *= times[now];
		add[left_tree] += add[now];
		tree[left_tree] = (tree[left_tree] * times[now] + add[now] * (mid-l+1));
		add[right_tree] *= times[now];
		times[right_tree] *= times[now];
		add[right_tree] += add[now];
		tree[right_tree] = (tree[right_tree] * times[now] + add[now] * (r-mid));
		add[now] = 0;
		times[now] = 1;
	}
	inline int build(int _l,int _r) {
		if(_l == _r) {
			if(!a[_l])
				return 0;
			int now = ++cnt;
			tree[now] = a[_l];
			return now;
		}
		int mid = (_l+_r)>>1,left_tree=build(_l,mid),right_tree=build(mid+1,_r);
		if(left_tree|right_tree) {
			int now = ++cnt;
			l[now] = left_tree,r[now] = right_tree;
			push_up(now,left_tree,right_tree);
			return now;
		}
	}
	inline void update_key(int pos,T key,int now,int _l,int _r) {
		if(_l > pos || _r < pos)
			return;
		if(!now)
			now=++cnt;
		if(_l == _r) {
			tree[now] = a[_l] = key;
			add[now] = 0;
			times[now] = 1;
			return;
		}
		int mid = (_l+_r)>>1,left_tree=l[now],right_tree=r[now];
		if(!left_tree)
			left_tree = l[now] = ++cnt;
		if(!right_tree)
			right_tree = r[now] = ++cnt;
		push_down(now,left_tree,right_tree,_l,mid,_r);
		update_key(pos,key,left_tree,_l,mid);
		update_key(pos,key,right_tree,mid+1,_r);
		push_up(now,left_tree,right_tree);
	}
	inline void update_plus(int left,int right,T plus,int now,int _l,int _r) {
		if(_l > right || _r < left)
			return;
		if(!now)
			now=++cnt;
		if(_l == _r) {
			tree[now] += plus;
			a[_l] = tree[now];
			add[now] = 0;
			times[now] = 1;
			return;
		}
		if(left <= _l && _r <= right) {
			add[now] += plus;
			tree[now] += plus * (_r-_l+1);
			return;
		}
		int mid = (_l+_r)>>1,left_tree=l[now],right_tree=r[now];
		if(!left_tree)
			left_tree = l[now] = ++cnt;
		if(!right_tree)
			right_tree = r[now] = ++cnt;
		push_down(now,left_tree,right_tree,_l,mid,_r);
		update_plus(left,right,plus,left_tree,_l,mid);
		update_plus(left,right,plus,right_tree,mid+1,_r);
		push_up(now,left_tree,right_tree);
	}
	inline void update_times(int left,int right,T _times,int now,int _l,int _r) {
		if(_l > right || _r < left)
			return;
		if(!now)
			now=++cnt;
		if(_l == _r) {
			tree[now] *= _times;
			a[_l] = tree[now];
			add[now] = 0;
			times[now] = 1;
			return;
		}
		if(left <= _l && _r <= right) {
			add[now] *= _times;
			times[now] *= _times;
			tree[now] *= _times;
			return;
		}
		int mid = (_l+_r)>>1,left_tree=l[now],right_tree=r[now];
		if(!left_tree)
			left_tree = l[now] = ++cnt;
		if(!right_tree)
			right_tree = r[now] = ++cnt;
		push_down(now,left_tree,right_tree,_l,mid,_r);
		update_times(left,right,_times,left_tree,_l,mid);
		update_times(left,right,_times,right_tree,mid+1,_r);
		push_up(now,left_tree,right_tree);
	}
	inline T query(int left,int right,int now,int _l,int _r) {
		if(_l > right || _r < left)
			return 0;
		if(!now)
			return 0;
		if(left <= _l && _r <= right)
			return tree[now];
		int mid = (_l+_r)>>1,left_tree=l[now],right_tree=r[now];
		push_down(now,left_tree,right_tree,_l,mid,_r);
		T ret=query(left,right,left_tree,_l,mid)+query(left,right,right_tree,mid+1,_r);
		push_up(now,left_tree,right_tree);
		return ret;
	}
};
long long a[_max_n+1];
segment_tree <long long,_max_n,a> tr;
int main() {
	int n,k,i,op,x,y,z;
	scanf("%d%d",& n,& k);
	for(i = 1; i <= n; i ++)
		scanf("%lld",a+i);
	int rt=tr.build(1,n);
	for(i = 1; i <= k; i ++) {
		scanf("%d",& op);
		switch(op) {
			case 1:
				scanf("%d%d%d",& x,& y,& z);
				tr.update_times(x,y,z,rt,1,n);
				break;
			case 2:
				scanf("%d%d%d",& x,& y,& z);
				tr.update_plus(x,y,z,rt,1,n);
				break;
			default:
				scanf("%d%d",& x,& y);
				printf("%lld\n",tr.query(x,y,rt,1,n));
		}
	}
	return 0;
}
