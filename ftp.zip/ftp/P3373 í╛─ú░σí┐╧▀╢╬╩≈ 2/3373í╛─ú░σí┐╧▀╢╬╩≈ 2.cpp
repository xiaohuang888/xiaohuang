// luogu-judger-enable-o2
#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>

using namespace std;

typedef long long LL;
const int MAXN=500005;
int n, m, num, mod, q, kuai, belong[MAXN], l[MAXN], r[MAXN];
LL x, p, y, z, a[MAXN], add[MAXN], mul[MAXN], d[MAXN];
inline int read() {
    int f=1, x=0;
    char s=getchar();
    while (s<'0' || s>'9') {
        if(s=='-') f=-1;
        s=getchar();
    }
    while (s>='0' && s<='9') {
        x=x*10+s-'0';
        s=getchar();
    }
    return x*f;
}
inline void build() {
    kuai=sqrt(n);
    num=n/kuai;
    if (n%kuai) num++;
    for (int i=1; i<=num; i++)
        l[i]=(i-1)*kuai+1,r[i]=i*kuai,mul[i]=1;
    for (int i=1; i<=n; i++)
        belong[i]=(i-1)/kuai+1;
    for (int i=1; i<=n; i++)
        d[belong[i]]+=a[i];
}
inline void Add(int L, int R, LL x) {
    int left=belong[L], right=belong[R];
    if (left==right) {
        if (add[left] || mul[left]!=1) {
            for (int i=l[left]; i<=r[left]; i++)
                a[i]=(a[i]*mul[left]+add[left])%mod;
            d[left]=(d[left]*mul[left]+add[left]*kuai)%mod;
            add[left]=0;
            mul[left]=1;
        }
        for (int i=L; i<=R; i++)
            a[i]+=x;
        d[left]=(d[left]+(R-L+1)*x)%mod;
        return ;
    }
    if (add[left] || mul[left]!=1) {
        for (int i=l[left]; i<=r[left]; i++)
            a[i]=(a[i]*mul[left]+add[left])%mod;
        d[left]=(d[left]*mul[left]+add[left]*kuai)%mod;
        add[left]=0;
        mul[left]=1;
    }
    for (int i=L; i<=r[left]; i++)
        a[i]=(a[i]+x)%mod;
    d[left]=(d[left]+(r[left]-L+1)*x)%mod;
    if (add[right] || mul[right]!=1) {
        for (int i=l[right]; i<=r[right]; i++)
            a[i]=(a[i]*mul[right]+add[right])%mod;
        d[right]=(d[right]*mul[right]+add[right]*kuai)%mod;
        add[right]=0;
        mul[right]=1;
    }
    for (int i=l[right]; i<=R; i++)
        a[i]=(a[i]+x)%mod;
    d[right]=(d[right]+(R-l[right]+1)*x)%mod;
    for (int i=left+1; i<right; i++)
        add[i]=(add[i]+x)%mod;
}
inline void Mul(int L, int R, LL x) {
    int left=belong[L], right=belong[R];
    if (left==right) {
        if (add[left] || mul[left]!=1) {
            for (int i=l[left]; i<=r[left]; i++)
                a[i]=(a[i]*mul[left]+add[left])%mod;
            d[left]=(d[left]*mul[left]+add[left]*kuai)%mod;
            add[left]=0;
            mul[left]=1;
        }
        int s=0;
        for (int i=L;i<=R;i++)
            s=(s+a[i]*(x-1))%mod,a[i]=(a[i]*x)%mod;
        d[left]=(d[left]+s)%mod;
        return ;
    }
    if (add[left] || mul[left]!=1) {
        for (int i=l[left]; i<=r[left]; i++)
            a[i]=(a[i]*mul[left]+add[left])%mod;
        d[left]=(d[left]*mul[left]+add[left]*kuai)%mod;
        add[left]=0;
        mul[left]=1;
    }
    int s=0;
    for (int i=L; i<=r[left]; i++) {
        s=(s+a[i]*(x-1))%mod;
        a[i]=(a[i]*x)%mod;
    }
    d[left]=(d[left]+s)%mod;
    if (add[right] || mul[right]!=1) {
        for (int i=l[right]; i<=r[right]; i++)
            a[i]=(a[i]*mul[right]+add[right])%mod;
        d[right]=(d[right]*mul[right]+add[right]*kuai)%mod;
        add[right]=0;
        mul[right]=1;
    }
    s=0;
    for (int i=l[right]; i<=R; i++) {
        s=(s+a[i]*(x-1))%mod;
        a[i]=(a[i]*x)%mod;
    }
    d[right]=(d[right]+s)%mod;
    for (int i=left+1; i<right; i++) {
        mul[i]=(mul[i]*x)%mod;
        add[i]=(add[i]*x)%mod;
    }
}
inline void query(int L, int R) {
    LL ans=0;
    int left=belong[L], right=belong[R];
    if (left==right) {
        for (int i=1; i<=n; i++)
            ans=(ans+a[i])%mod;
        printf("%d\n",(ans*mul[left]+(R-L+1)*(add[left])%mod));
        return ;
    }
    for (int i=L; i<=r[left]; i++)
        ans=(ans+a[i])%mod;
    ans=(ans*mul[left]+(r[left]-L+1)*add[left])%mod;
    int tmp=0;
    for (int i=l[right]; i<=R; i++)
        tmp=(tmp+a[i])%mod;
    tmp=(tmp*mul[right]+(R-l[right]+1)*add[right])%mod;
    ans=(ans+tmp)%mod;
    for (int i=left+1; i<right; i++)
        ans=(ans+d[i]*mul[i]+add[i]*kuai)%mod;
    printf("%lld\n",ans);
}
int main() {
    n=read(); q=read(); mod=read();
    for (int i=1; i<=n; i++)
        a[i]=read();
    build();
    for (int i=1; i<=q; i++) {
        p=read(); x=read(); y=read();
        if (p==3) query(x,y); else
        if (p==1) {
            z=read();
            Mul(x,y,z);
        } else {
            z=read();
            Add(x,y,z);
        }
    }
    return 0;
}