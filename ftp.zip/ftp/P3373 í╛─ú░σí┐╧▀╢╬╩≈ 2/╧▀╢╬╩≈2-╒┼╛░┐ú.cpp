#include <iostream>
#include <cstdio>
#define Rint register int
#define Temp template<typename T>
using namespace std;
typedef long long ll;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&(ch!='-')) ch=getchar();
    if(ch=='-') w=-1;
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w; 
}
#define mid ((l+r)>>1)
#define lson rt<<1,l,mid
#define rson rt<<1|1,mid+1,r
#define len (r-l+1)
const int maxn=2e5+10;
int n,m;
ll c[maxn];
ll a[maxn<<2],lazy[maxn<<2],mul[maxn<<2],mod;
ll res=0;
inline void pushdown(int rt,int l,int r,int mid_,int ls,int rs) {
    mul[ls]=(mul[ls]*mul[rt])%mod;
    mul[rs]=(mul[rs]*mul[rt])%mod;
    lazy[ls]=(lazy[ls]*mul[rt])%mod;
    lazy[rs]=(lazy[rs]*mul[rt])%mod;
    a[ls]=(a[ls]*mul[rt])%mod;
    a[rs]=(a[rs]*mul[rt])%mod;
    mul[rt]=1;
    lazy[ls]=(lazy[rt]+lazy[ls])%mod;
    lazy[rs]=(lazy[rs]+lazy[rt])%mod;
    a[ls]=(a[ls]+(mid_-l+1)*lazy[rt])%mod;
    a[rs]=(a[rs]+(r-mid_)*lazy[rt])%mod;
    lazy[rt]=0;
}
inline void build(int rt,int l,int r) {
    lazy[rt]=0;
    mul[rt]=1;
    if(l==r) {
    	mul[rt]=1;
        a[rt]=c[l];
        a[rt]%=mod;
        return ;
    }
    build(lson);
    build(rson);
    a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
}
inline void query(int rt,int l,int r,int L,int R) {
    if((L<=l)&&(r<=R)) {
        res+=a[rt];
        res%=mod;
        return ;
    }
    else {
        if(lazy[rt]||mul[rt]!=1) pushdown(rt,l,r,mid,rt<<1,rt<<1|1);
        if(L<=mid) query(lson,L,R);
        if(R>mid) query(rson,L,R);
    }
}
inline void updateadd(int rt,int l,int r,int L,int R,ll k) {
    if((L<=l)&&(r<=R)) {
        lazy[rt]+=k;
        lazy[rt]%=mod;
        a[rt]+=(k*len);
        a[rt]%=mod;
        return ;
    }
    else {
        if(lazy[rt]||mul[rt]!=1) pushdown(rt,l,r,mid,rt<<1,rt<<1|1);
        if(L<=mid) updateadd(lson,L,R,k);
        if(R>mid) updateadd(rson,L,R,k);
        a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
    }
}
inline void updatemul(int rt,int l,int r,int L,int R,ll k) {
    if((L<=l)&&(r<=R)) {
        mul[rt]=(mul[rt]*k)%mod;
        lazy[rt]=(lazy[rt]*k)%mod;
        a[rt]=(a[rt]*k)%mod;
        return ;
    }
    else {
        if(lazy[rt]||mul[rt]!=1) pushdown(rt,l,r,mid,rt<<1,rt<<1|1);
        if(L<=mid) updatemul(lson,L,R,k);
        if(R>mid) updatemul(rson,L,R,k);
        a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
    }
}

int main() {
    read(n);read(m);read(mod);
    for (int i=1;i<=n;++i) read(c[i]);
    build(1,1,n);
    for (int i=1;i<=m;++i) {
        int k,x,y;
        ll z;
        read(k);
        if(k==1) {
            read(x);read(y);read(z);
            updatemul(1,1,n,x,y,z);
        }
        if(k==2) {
            read(x);read(y);read(z);
            updateadd(1,1,n,x,y,z);
        }
        if(k==3) {
            res=0;
            read(x);read(y);
            query(1,1,n,x,y);
            printf("%lld\n",res%mod);
        }
    }
    return 0;
}
