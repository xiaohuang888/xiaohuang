#include <iostream>
#include <cstdio>
#include <algorithm>
#define Rint register int
#define Temp template<typename T>
using namespace std;
Temp inline void read(T &x) {
    x=0;T w=1,ch=getchar();
    while(!isdigit(ch)&&(ch!='-')) ch=getchar();
    if(ch=='-') w=-1;
    while(isdigit(ch)) x=x*10+ch-'0',ch=getchar();
    x*=w; 
}
inline void write(int x) {
	if (x<0) putchar('-'),x=-x;
	if (x>=10) write(x/10);
	putchar(x%10+'0');
}
const int maxn=2e5+10;
struct Edge{
    int to,nxt;
}e[maxn];
struct righ{
	int flag,id,val;
}r1[maxn];
int n,m,mod=201314;
int head[maxn],w[maxn],wt[maxn],sum=0,rid[maxn];
int a[maxn<<2],lazy[maxn<<2];
int son[maxn],top[maxn],siz[maxn],id[maxn],father[maxn],dep[maxn],cnt;
int res=0;
int res1[maxn];
inline void addedge(int x,int y) {
    sum++;
    e[sum].to=y;
    e[sum].nxt=head[x];
    head[x]=sum;
}
inline void pushdown(int rt,int lenn) {
    lazy[rt<<1]+=lazy[rt];
    lazy[rt<<1|1]+=lazy[rt];
    a[rt<<1]+=(lazy[rt]*(lenn-(lenn>>1)));
    a[rt<<1|1]+=(lazy[rt]*(lenn>>1));
    a[rt<<1]%=mod;
    a[rt<<1|1]%=mod;
    lazy[rt]=0;
}
inline void build(int rt,int l,int r) {
	int mid=(l+r)>>1;
    if(l==r) {
        a[rt]=wt[l];
        a[rt]%=mod;
        return ;
    }
    build(rt<<1,l,mid);
    build(rt<<1|1,mid+1,r);
    a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
}
inline void query(int rt,int l,int r,int L,int R) {
	int mid=(l+r)>>1;
    if((L<=l)&&(r<=R)) {
        res+=a[rt];
        res%=mod;
        return ;
    }
    else {
        if(lazy[rt]) pushdown(rt,(r-l+1));
        if(L<=mid) query(rt<<1,l,mid,L,R);
        if(R>mid) query(rt<<1|1,mid+1,r,L,R);
    }
}
inline void update(int rt,int l,int r,int L,int R,int k) {
	int mid=(l+r)>>1;
    if((L<=l)&&(r<=R)) {
        lazy[rt]+=k;
        a[rt]+=(k*(r-l+1));
        return ;
    }
    else {
        if(lazy[rt]) pushdown(rt,(r-l+1));
        if(L<=mid) update(rt<<1,l,mid,L,R,k);
        if(R>mid) update(rt<<1|1,mid+1,r,L,R,k);
        a[rt]=(a[rt<<1]+a[rt<<1|1])%mod;
    }
}
inline int qrange(int x) {
    int ans=0,s=x;
    while(s) {
    	res=0;
    	query(1,1,n,id[top[s]],id[s]);
    	res%=mod;
    	ans+=res;
    	ans%=mod;
    	s=father[top[s]];
	}
    return ans%mod;
}

inline void updrange(int x) {
	int s=x;
    while(s) {
    	update(1,1,n,id[top[s]],id[s],1);
    	s=father[top[s]];
	}
    return ;
}

inline void dfs(int rt,int f,int deep) {
    dep[rt]=deep;
    father[rt]=f;
    siz[rt]=1;
    int maxson=-1;
    for (Rint i=head[rt];~i;i=e[i].nxt) {
        int y=e[i].to;
        if(y==f) continue;
        dfs(y,rt,deep+1);
        siz[rt]+=siz[y];
        if(siz[rt]>maxson) son[rt]=y,maxson=siz[rt];
    }
}

inline void solve(int rt,int topf) {
    id[rt]=++cnt;
    wt[cnt]=w[rt];
    top[rt]=topf;
    if(!son[rt]) return ;
    solve(son[rt],topf);
    for (Rint i=head[rt];~i;i=e[i].nxt) {
        int y=e[i].to;
        if((y==father[rt])||(y==son[rt])) continue;
        solve(y,y);
    }
}

bool cmp(righ a,righ b) {
	return a.val<b.val;
}

int main() {
    read(n);read(m);
    for (Rint i=1;i<=n+1;i++) head[i]=-1;
    for (Rint i=1;i<=n;++i) w[i]=0;
    for (Rint i=2;i<=n;++i) {
        int a;
        read(a);
        a++;
        addedge(a,i);
        addedge(i,a);
    }
    int tot=0;
    for (Rint i=1;i<=m;++i) {
    	int l,r,x;read(l);read(r);read(x);
    	++l;++r;++x;
    	tot++;
    	rid[i]=x;
    	r1[tot].flag=-1;r1[tot].id=i;r1[tot].val=l-1;
    	tot++;
    	r1[tot].flag=1;r1[tot].id=i;r1[tot].val=r;
	}
	dfs(1,0,1);
    solve(1,1);
    build(1,1,n);
    stable_sort(r1+1,r1+1+tot,cmp);
    int nt=1;
    while(!r1[nt].val) nt++;
    for (int i=1;i<=n;++i) {
    	updrange(i);
    	while(r1[nt].val==i) {
    		res1[r1[nt].id]+=(qrange(rid[r1[nt].id])*r1[nt].flag+mod);
    		res1[r1[nt].id]%=mod;
    		nt++;
		}
	}
	for (int i=1;i<=m;++i) {
		write(res1[i]);
		putchar('\n');
	}
    return 0;
}
