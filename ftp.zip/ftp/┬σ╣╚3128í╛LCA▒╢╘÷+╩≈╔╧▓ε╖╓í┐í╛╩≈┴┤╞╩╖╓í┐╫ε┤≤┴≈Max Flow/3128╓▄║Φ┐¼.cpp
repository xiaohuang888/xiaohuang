#include<cstdio>
#include<cmath>
#include<algorithm>
#define N 50005
int n,k,x,y,cnt,f[N][20],dep[N],sum[N],ans;
int first[N];
struct NODE
{
    int nxt,to;
} node[N*2];
using namespace std;
void add(int from,int to)
{
    node[++cnt].nxt=first[from];
    node[cnt].to=to;
    first[from]=cnt;
}
void dfs(int now,int father)
{
    f[now][0]=father;
    dep[now]=dep[father]+1;
    for (int i=first[now]; i; i=node[i].nxt)
    {
        int k=node[i].to;
        if (k==father) continue;
        dfs(k,now);
    }
}
void lca(int x,int y)
{
    sum[x]++;
    sum[y]++;
    if (dep[x]<dep[y]) swap(x,y);
    for (int i=log(n)/log(2); i>=0; i--)
        if (dep[f[x][i]]>=dep[y]) x=f[x][i];
    if (x==y)
    {
        sum[x]--;
        sum[f[x][0]]--;
    }
    else
    {
        for (int i=log(n)/log(2); i>=0; i--)
            if (f[x][i]!=f[y][i]) x=f[x][i],y=f[y][i];
        sum[f[x][0]]--;
        sum[f[f[x][0]][0]]--;
    }
}
void get_sum(int now,int father)
{
    for (int i=first[now]; i; i=node[i].nxt)
    {
        int k=node[i].to;
        if (k==father) continue;
        get_sum(k,now);
        sum[now]+=sum[k];
    }
    ans=max(ans,sum[now]);
}
int read();
int main()
{
    n=read(),k=read();
    for (int i=1; i<n; i++)
    {
        x=read(),y=read();
        add(x,y);
        add(y,x);
    }
    dfs(1,0);
    for (int j=1; j<=log(n)/log(2); j++)
        for (int i=1; i<=n; i++) f[i][j]=f[f[i][j-1]][j-1];
    for (int i=1; i<=k; i++)
    {
        x=read(),y=read();
        lca(x,y);
    }
    get_sum(1,0);
    printf("%d\n",ans);
    return 0;
}
inline int read()
{
    int f=1,x=0;
    char ch=getchar();
    while (ch<'0'||ch>'9')
    {
        if (ch=='-') f=-1;
        ch=getchar();
    }
    while (ch>='0'&&ch<='9')
    {
        x=x*10+ch-48;
        ch=getchar();
    }
    return f*x;
}
